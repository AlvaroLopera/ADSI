
window.feedback = 'True';
window.indexPageDir = 'entrega2.html';
window.index_page_json = {
  "title": "Demo",
  "path": "",
  "html_panel": [
    {
      "title": "",
      "html": "\u003cdiv style\u003d\u0027margin-top:300px; text-align: center; width: 100%; color: rgb(0, 60, 120);font-size: 20px;\u0027\u003e\u003ch1\u003eYou are using Software Engineering Portal Demo version\u003c/h1\u003e\u003cp\u003eDemo version displays only the limited number of elements per each view.\u003c/p\u003e\u003cp\u003eWith MagicDraw Enterprise Edition, you can get the Complete Software Engineering Portal version. \u003ca href\u003d\u0027http://www.nomagic.com/products/magicdraw.html\u0027 target\u003d\u0027_blank\u0027\u003eRead more...\u003ca\u003e \u003c/p\u003e\u003c/div\u003e",
      "collapsible": false
    }
  ],
  "grid_panel": [],
  "image_panel": []
};
window.navigation_json = [
  {
    "data": [
      {
        "text": "Documentacion del Proyecto Entrega 2",
        "qtitle": "Package___19_0_4_7c8024c_1608491267549_161671_7569",
        "icon": "images/icon_4.png",
        "children": [
          {
            "text": "2. Glosario",
            "qtitle": "Package___19_0_4_65b021b_1608502989614_109664_7440",
            "icon": "images/icon_4.png",
            "children": [
              {
                "text": "Alumno",
                "qtitle": "Glossary___19_0_4_65b021b_1608501810045_588967_7396",
                "icon": "images/icon_25.png",
                "leaf": true,
                "expanded": false
              },
              {
                "text": "Calendario",
                "qtitle": "Glossary___19_0_4_65b021b_1608503037273_207154_7461",
                "icon": "images/icon_25.png",
                "leaf": true,
                "expanded": false
              },
              {
                "text": "Clase grabada",
                "qtitle": "Glossary___19_0_4_65b021b_1608503622712_178899_7486",
                "icon": "images/icon_25.png",
                "leaf": true,
                "expanded": false
              },
              {
                "text": "Curso",
                "qtitle": "Glossary___19_0_4_65b021b_1608502518889_106459_7435",
                "icon": "images/icon_25.png",
                "leaf": true,
                "expanded": false
              },
              {
                "text": "Mensaje",
                "qtitle": "Glossary___19_0_4_65b021b_1608503171947_946887_7466",
                "icon": "images/icon_25.png",
                "leaf": true,
                "expanded": false
              },
              {
                "text": "ONG",
                "qtitle": "Glossary___19_0_4_65b021b_1608502085567_68231_7406",
                "icon": "images/icon_25.png",
                "leaf": true,
                "expanded": false
              },
              {
                "text": "Profesor",
                "qtitle": "Glossary___19_0_4_65b021b_1608502034739_934366_7401",
                "icon": "images/icon_25.png",
                "leaf": true,
                "expanded": false
              },
              {
                "text": "Seminario online",
                "qtitle": "Glossary___19_0_4_65b021b_1608503345921_285444_7481",
                "icon": "images/icon_25.png",
                "leaf": true,
                "expanded": false
              },
              {
                "text": "Tema",
                "qtitle": "Glossary___19_0_4_65b021b_1608503285310_207417_7476",
                "icon": "images/icon_25.png",
                "leaf": true,
                "expanded": false
              },
              {
                "text": "Usuario",
                "qtitle": "Glossary___19_0_4_65b021b_1608501577265_885294_7386",
                "icon": "images/icon_25.png",
                "leaf": true,
                "expanded": false
              }
            ],
            "leaf": false,
            "expanded": false
          }
        ],
        "leaf": false,
        "expanded": false
      }
    ],
    "title": "Glossary",
    "type": "glossary"
  },
  {
    "data": [
      {
        "text": "Casos de uso",
        "qtitle": "Package___19_0_3_59501f0_1605898693468_780946_4813",
        "icon": "images/icon_4.png",
        "children": [
          {
            "text": "Actores",
            "qtitle": "Package___19_0_4_7c8024c_1606045670559_892273_6448",
            "icon": "images/icon_4.png",
            "children": [
              {
                "text": "",
                "qtitle": "Requirement___19_0_4_7c8024c_1606044881570_420167_5379",
                "icon": "images/icon_5.png",
                "leaf": true,
                "expanded": false
              },
              {
                "text": "UMA",
                "qtitle": "Requirement___19_0_4_7c8024c_1605992040306_840570_5282",
                "icon": "images/icon_5.png",
                "leaf": true,
                "expanded": false
              }
            ],
            "leaf": false,
            "expanded": false
          },
          {
            "text": "Subsistema Actividades",
            "qtitle": "Package___19_0_4_7c8024c_1605993744465_299768_6146",
            "icon": "images/icon_4.png",
            "children": [
              {
                "text": "Descargar Archivos",
                "qtitle": "Requirement___19_0_3_59501f0_1605901657237_602297_5524",
                "icon": "images/icon_6.png",
                "leaf": true,
                "expanded": false
              },
              {
                "text": "Ver actividad",
                "qtitle": "Requirement___19_0_4_8cb0287_1606043062428_844297_5553",
                "icon": "images/icon_6.png",
                "leaf": true,
                "expanded": false
              }
            ],
            "leaf": false,
            "expanded": false
          },
          {
            "text": "Subsistema Curso",
            "qtitle": "Package___19_0_4_7c8024c_1606045080271_940524_6239",
            "icon": "images/icon_4.png",
            "children": [
              {
                "text": "Crud de ONG",
                "qtitle": "Requirement___19_0_4_7c8024c_1605544934734_89990_5051",
                "icon": "images/icon_6.png",
                "leaf": true,
                "expanded": false
              },
              {
                "text": "CUD calificaciones opcionales",
                "qtitle": "Requirement___19_0_4_7c8024c_1606044881556_666481_5369",
                "icon": "images/icon_6.png",
                "leaf": true,
                "expanded": false
              },
              {
                "text": "Visualizar clases grabadas",
                "qtitle": "Requirement___19_0_4_7c8024c_1606044881557_892467_5370",
                "icon": "images/icon_6.png",
                "leaf": true,
                "expanded": false
              }
            ],
            "leaf": false,
            "expanded": false
          },
          {
            "text": "Subsistema Foro",
            "qtitle": "Package___19_0_4_7c8024c_1605975887729_200757_5237",
            "icon": "images/icon_4.png",
            "children": [
              {
                "text": "Crear POST",
                "qtitle": "Requirement___19_0_3_5c401fe_1605960554152_674012_5202",
                "icon": "images/icon_6.png",
                "leaf": true,
                "expanded": false
              }
            ],
            "leaf": false,
            "expanded": false
          },
          {
            "text": "Subsistema Identificación",
            "qtitle": "Package___19_0_4_7c8024c_1605991759147_968139_5028",
            "icon": "images/icon_4.png",
            "children": [
              {
                "text": "Recordar Contraseña",
                "qtitle": "Requirement___19_0_3_59501f0_1605900716718_322105_5130",
                "icon": "images/icon_6.png",
                "leaf": true,
                "expanded": false
              },
              {
                "text": "Validar Acceso",
                "qtitle": "Requirement___19_0_3_59501f0_1605899611767_786078_4829",
                "icon": "images/icon_6.png",
                "leaf": true,
                "expanded": false
              }
            ],
            "leaf": false,
            "expanded": false
          }
        ],
        "leaf": false,
        "expanded": false
      }
    ],
    "title": "Requirement",
    "type": "requirement"
  },
  {
    "data": [
      {
        "text": "Casos de uso",
        "qtitle": "Package___19_0_3_59501f0_1605898693468_780946_4813",
        "icon": "images/icon_4.png",
        "children": [
          {
            "text": "Subsistema Curso",
            "qtitle": "Package___19_0_4_7c8024c_1606045080271_940524_6239",
            "icon": "images/icon_4.png",
            "children": [
              {
                "text": "Crud Alumnos",
                "qtitle": "EmptyContent___19_0_4_7c8024c_1605544888603_669246_5036",
                "icon": "images/icon_6.png",
                "children": [
                  {
                    "text": "Crud Alumnos-CREAR-ALTERNATIVO-2",
                    "qtitle": "Architecture___19_0_4_7c8024c_1608233830258_399547_6406",
                    "icon": "images/icon_7.png",
                    "leaf": true,
                    "expanded": false
                  }
                ],
                "leaf": false,
                "expanded": false
              },
              {
                "text": "Crud de ONG",
                "qtitle": "EmptyContent___19_0_4_7c8024c_1605544934734_89990_5051",
                "icon": "images/icon_6.png",
                "children": [
                  {
                    "text": "Crud de ONG",
                    "qtitle": "Architecture___19_0_4_7c8024c_1608378644162_795769_6414",
                    "icon": "images/icon_7.png",
                    "leaf": true,
                    "expanded": false
                  }
                ],
                "leaf": false,
                "expanded": false
              },
              {
                "text": "Mensajeria Interna",
                "qtitle": "EmptyContent___19_0_3_5c401fe_1605962882995_512132_5475",
                "icon": "images/icon_6.png",
                "children": [
                  {
                    "text": "Enviar correo interno",
                    "qtitle": "Architecture___19_0_3_59501f0_1608294205699_944159_8820",
                    "icon": "images/icon_7.png",
                    "leaf": true,
                    "expanded": false
                  }
                ],
                "leaf": false,
                "expanded": false
              }
            ],
            "leaf": false,
            "expanded": false
          },
          {
            "text": "Subsistema Identificación",
            "qtitle": "Package___19_0_4_7c8024c_1605991759147_968139_5028",
            "icon": "images/icon_4.png",
            "children": [
              {
                "text": "Recordar Contraseña",
                "qtitle": "EmptyContent___19_0_3_59501f0_1605900716718_322105_5130",
                "icon": "images/icon_6.png",
                "children": [
                  {
                    "text": "Recordar Contraseña",
                    "qtitle": "Architecture___19_0_3_59501f0_1608289624419_295501_6582",
                    "icon": "images/icon_7.png",
                    "leaf": true,
                    "expanded": false
                  },
                  {
                    "text": "Recordar Contraseña-ALTERNATIVO",
                    "qtitle": "Architecture___19_0_3_59501f0_1608291630127_209026_7223",
                    "icon": "images/icon_7.png",
                    "leaf": true,
                    "expanded": false
                  }
                ],
                "leaf": false,
                "expanded": false
              },
              {
                "text": "Registro",
                "qtitle": "EmptyContent___19_0_3_5c401fe_1605961577356_539243_4912",
                "icon": "images/icon_6.png",
                "children": [
                  {
                    "text": "Registro usuarios Alter",
                    "qtitle": "Architecture___19_0_3_5c401fe_1608572688415_5055_8478",
                    "icon": "images/icon_7.png",
                    "leaf": true,
                    "expanded": false
                  }
                ],
                "leaf": false,
                "expanded": false
              }
            ],
            "leaf": false,
            "expanded": false
          }
        ],
        "leaf": false,
        "expanded": false
      },
      {
        "text": "Estructura",
        "qtitle": "Package___19_0_4_7c8024c_1606752452637_33243_5229",
        "icon": "images/icon_4.png",
        "children": [
          {
            "text": "Control",
            "qtitle": "Package___19_0_4_7c8024c_1608218571669_136949_5237",
            "icon": "images/icon_4.png",
            "children": [
              {
                "text": "CtrCurso",
                "qtitle": "Architecture___19_0_4_7c8024c_1608227601648_553345_5484",
                "icon": "images/icon_26.png",
                "leaf": true,
                "expanded": false
              },
              {
                "text": "CtrForo",
                "qtitle": "Architecture___19_0_4_7c8024c_1608227611466_747776_5510",
                "icon": "images/icon_26.png",
                "leaf": true,
                "expanded": false
              },
              {
                "text": "CtrTarea",
                "qtitle": "Architecture___19_0_4_7c8024c_1608227664966_121960_5640",
                "icon": "images/icon_26.png",
                "leaf": true,
                "expanded": false
              }
            ],
            "leaf": false,
            "expanded": false
          },
          {
            "text": "Interfaz",
            "qtitle": "Package___19_0_4_7c8024c_1608218581306_512639_5238",
            "icon": "images/icon_4.png",
            "children": [
              {
                "text": "ViewCalendario",
                "qtitle": "Architecture___19_0_4_5b201fd_1608472146728_379966_9598",
                "icon": "images/icon_27.png",
                "leaf": true,
                "expanded": false
              }
            ],
            "leaf": false,
            "expanded": false
          }
        ],
        "leaf": false,
        "expanded": false
      }
    ],
    "title": "Architecture",
    "type": "architecture"
  },
  {
    "data": [
      {
        "text": "Documentacion del Proyecto Entrega 1",
        "qtitle": "Package___19_0_4_7c8024c_1605542700510_677406_4795",
        "icon": "images/icon_4.png",
        "children": [
          {
            "text": "1.Introduccion",
            "qtitle": "Implementation___19_0_4_7c8024c_1606060622302_113766_5116",
            "icon": "images/icon_15.png",
            "leaf": true,
            "expanded": false
          },
          {
            "text": "10.Entorno Tecnológico",
            "qtitle": "Implementation___19_0_4_7c8024c_1606060528605_322680_5112",
            "icon": "images/icon_15.png",
            "leaf": true,
            "expanded": false
          },
          {
            "text": "11.Estrategia de Implantación",
            "qtitle": "Implementation___19_0_4_7c8024c_1606060584140_87899_5113",
            "icon": "images/icon_15.png",
            "leaf": true,
            "expanded": false
          },
          {
            "text": "4.Catálogo de Requisitos",
            "qtitle": "Implementation___19_0_4_7c8024c_1606060419638_663731_5107",
            "icon": "images/icon_15.png",
            "leaf": true,
            "expanded": false
          },
          {
            "text": "7.Descomposicion en Subsistemas",
            "qtitle": "Implementation___19_0_4_7c8024c_1606060493989_308786_5110",
            "icon": "images/icon_15.png",
            "leaf": true,
            "expanded": false
          }
        ],
        "leaf": false,
        "expanded": false
      },
      {
        "text": "Documentacion del Proyecto Entrega 2",
        "qtitle": "Package___19_0_4_7c8024c_1608491267549_161671_7569",
        "icon": "images/icon_4.png",
        "children": [
          {
            "text": "1.Introducción",
            "qtitle": "Implementation___19_0_4_7c8024c_1608491329083_791211_7570",
            "icon": "images/icon_15.png",
            "leaf": true,
            "expanded": false
          },
          {
            "text": "11.Descripcion de Integración de subsistemas",
            "qtitle": "Implementation___19_0_4_7c8024c_1608491706642_526918_7610",
            "icon": "images/icon_15.png",
            "leaf": true,
            "expanded": false
          },
          {
            "text": "14.Formatos de Pantalla",
            "qtitle": "Implementation___19_0_4_7c8024c_1608540241429_745140_8986",
            "icon": "images/icon_15.png",
            "leaf": true,
            "expanded": false
          },
          {
            "text": "5.Catalogo de Requisitos",
            "qtitle": "Implementation___19_0_4_7c8024c_1608491390629_320446_7573",
            "icon": "images/icon_15.png",
            "leaf": true,
            "expanded": false
          },
          {
            "text": "7.Catalogo de Usuarios",
            "qtitle": "Implementation___19_0_4_7c8024c_1608491599000_508114_7604",
            "icon": "images/icon_15.png",
            "leaf": true,
            "expanded": false
          }
        ],
        "leaf": false,
        "expanded": false
      }
    ],
    "title": "Implementation",
    "type": "implementation"
  },
  {
    "data": [
      {
        "text": "Casos de uso",
        "qtitle": "Package___19_0_3_59501f0_1605898693468_780946_4813",
        "icon": "images/icon_4.png",
        "children": [
          {
            "text": "Subsistema Actividades",
            "qtitle": "Package___19_0_4_7c8024c_1605993744465_299768_6146",
            "icon": "images/icon_4.png",
            "children": [
              {
                "text": "Descargar Archivos",
                "qtitle": "EmptyContent___19_0_3_59501f0_1605901657237_602297_5524",
                "icon": "images/icon_6.png",
                "children": [
                  {
                    "text": "Descargar Archivos",
                    "qtitle": "EmptyContent___19_0_3_59501f0_1605901673435_41536_5538",
                    "icon": "images/icon_17.png",
                    "children": [
                      {
                        "text": "Descargar Archivos_imported",
                        "qtitle": "Diagrams___19_0_4_7c8024c_1608378644436_339003_7256",
                        "icon": "images/icon_16.png",
                        "leaf": true,
                        "expanded": false
                      },
                      {
                        "text": "Descargar Archivos_imported_imported",
                        "qtitle": "Diagrams___19_0_4_7c8024c_1608397299659_722793_8955",
                        "icon": "images/icon_16.png",
                        "leaf": true,
                        "expanded": false
                      }
                    ],
                    "leaf": false,
                    "expanded": false
                  }
                ],
                "leaf": false,
                "expanded": false
              },
              {
                "text": "Subir Documento",
                "qtitle": "EmptyContent___19_0_4_7c8024c_1605979033648_450401_5796",
                "icon": "images/icon_6.png",
                "children": [
                  {
                    "text": "Entregar Actividad",
                    "qtitle": "EmptyContent___19_0_4_7c8024c_1605983074405_93964_7342",
                    "icon": "images/icon_17.png",
                    "children": [
                      {
                        "text": "Entregar Actividad_imported",
                        "qtitle": "Diagrams___19_0_4_7c8024c_1608378644466_1178_7326",
                        "icon": "images/icon_16.png",
                        "leaf": true,
                        "expanded": false
                      }
                    ],
                    "leaf": false,
                    "expanded": false
                  }
                ],
                "leaf": false,
                "expanded": false
              }
            ],
            "leaf": false,
            "expanded": false
          },
          {
            "text": "Subsistema Curso",
            "qtitle": "Package___19_0_4_7c8024c_1606045080271_940524_6239",
            "icon": "images/icon_4.png",
            "children": [
              {
                "text": "Aceptar Invitacion  Curso",
                "qtitle": "EmptyContent___19_0_4_7c8024c_1608384972544_746497_5858",
                "icon": "images/icon_6.png",
                "children": [
                  {
                    "text": "Aceptar Invitacion  Curso",
                    "qtitle": "EmptyContent___19_0_4_7c8024c_1608385184925_923481_5923",
                    "icon": "images/icon_17.png",
                    "children": [
                      {
                        "text": "Aceptar Invitacion  Curso_imported",
                        "qtitle": "Diagrams___19_0_4_7c8024c_1608464479043_18374_13440",
                        "icon": "images/icon_16.png",
                        "leaf": true,
                        "expanded": false
                      }
                    ],
                    "leaf": false,
                    "expanded": false
                  }
                ],
                "leaf": false,
                "expanded": false
              }
            ],
            "leaf": false,
            "expanded": false
          },
          {
            "text": "Subsistema Foro",
            "qtitle": "Package___19_0_4_7c8024c_1605975887729_200757_5237",
            "icon": "images/icon_4.png",
            "children": [
              {
                "text": "Mirar POST",
                "qtitle": "EmptyContent___19_0_3_5c401fe_1605959803088_991088_4871",
                "icon": "images/icon_6.png",
                "children": [
                  {
                    "text": "Mirar POST",
                    "qtitle": "EmptyContent___19_0_3_5c401fe_1605960673783_419218_5276",
                    "icon": "images/icon_17.png",
                    "children": [
                      {
                        "text": "Mirar POST_imported2",
                        "qtitle": "Diagrams___19_0_4_7c8024c_1608464477782_544977_9517",
                        "icon": "images/icon_16.png",
                        "leaf": true,
                        "expanded": false
                      }
                    ],
                    "leaf": false,
                    "expanded": false
                  }
                ],
                "leaf": false,
                "expanded": false
              },
              {
                "text": "Reportar",
                "qtitle": "EmptyContent___19_0_3_5c401fe_1605960559088_714923_5217",
                "icon": "images/icon_6.png",
                "children": [
                  {
                    "text": "Reportar",
                    "qtitle": "EmptyContent___19_0_3_5c401fe_1605961280981_952124_5371",
                    "icon": "images/icon_17.png",
                    "children": [
                      {
                        "text": "Reportar",
                        "qtitle": "Diagrams___19_0_3_5c401fe_1605961280982_806754_5372",
                        "icon": "images/icon_16.png",
                        "leaf": true,
                        "expanded": false
                      }
                    ],
                    "leaf": false,
                    "expanded": false
                  }
                ],
                "leaf": false,
                "expanded": false
              }
            ],
            "leaf": false,
            "expanded": false
          },
          {
            "text": "Subsistema Identificación",
            "qtitle": "Package___19_0_4_7c8024c_1605991759147_968139_5028",
            "icon": "images/icon_4.png",
            "children": [
              {
                "text": "Autoregistro",
                "qtitle": "EmptyContent___19_0_3_5c401fe_1605961577354_733757_4911",
                "icon": "images/icon_6.png",
                "children": [
                  {
                    "text": "AutoregistroAlter",
                    "qtitle": "EmptyContent___19_0_4_7c8024c_1608397299065_376454_7237",
                    "icon": "images/icon_7.png",
                    "children": [
                      {
                        "text": "AutoregistroAlter",
                        "qtitle": "Diagrams___19_0_4_7c8024c_1608397299611_104126_8854",
                        "icon": "images/icon_18.png",
                        "leaf": true,
                        "expanded": false
                      }
                    ],
                    "leaf": false,
                    "expanded": false
                  }
                ],
                "leaf": false,
                "expanded": false
              },
              {
                "text": "Registro",
                "qtitle": "EmptyContent___19_0_3_5c401fe_1605961577356_539243_4912",
                "icon": "images/icon_6.png",
                "children": [
                  {
                    "text": "Registro usuarios externos-ALTERNATIVO",
                    "qtitle": "EmptyContent___19_0_3_59501f0_1608294026196_663096_8569",
                    "icon": "images/icon_7.png",
                    "children": [
                      {
                        "text": "Registro usuarios externos-ALTERNATIVO",
                        "qtitle": "Diagrams___19_0_3_59501f0_1608294026196_162693_8568",
                        "icon": "images/icon_18.png",
                        "leaf": true,
                        "expanded": false
                      }
                    ],
                    "leaf": false,
                    "expanded": false
                  }
                ],
                "leaf": false,
                "expanded": false
              }
            ],
            "leaf": false,
            "expanded": false
          },
          {
            "text": "Subsistema Tareas",
            "qtitle": "Package___19_0_4_7c8024c_1608419403729_110276_7054",
            "icon": "images/icon_4.png",
            "children": [
              {
                "text": "Entregar Tarea",
                "qtitle": "EmptyContent___19_0_4_8cb0287_1606038280480_854501_5064",
                "icon": "images/icon_6.png",
                "children": [
                  {
                    "text": "Entregar tarea",
                    "qtitle": "EmptyContent___19_0_4_7c8024c_1608241970817_986305_8998",
                    "icon": "images/icon_7.png",
                    "children": [
                      {
                        "text": "Entregar tarea",
                        "qtitle": "Diagrams___19_0_4_7c8024c_1608241970816_286440_8997",
                        "icon": "images/icon_18.png",
                        "leaf": true,
                        "expanded": false
                      }
                    ],
                    "leaf": false,
                    "expanded": false
                  },
                  {
                    "text": "Entregar Tarea",
                    "qtitle": "EmptyContent___19_0_4_7c8024c_1608399403657_841613_6685",
                    "icon": "images/icon_17.png",
                    "children": [
                      {
                        "text": "Entregar Tarea",
                        "qtitle": "Diagrams___19_0_4_7c8024c_1608399403661_45434_6686",
                        "icon": "images/icon_16.png",
                        "leaf": true,
                        "expanded": false
                      }
                    ],
                    "leaf": false,
                    "expanded": false
                  }
                ],
                "leaf": false,
                "expanded": false
              }
            ],
            "leaf": false,
            "expanded": false
          }
        ],
        "leaf": false,
        "expanded": false
      }
    ],
    "title": "Diagrams",
    "type": "diagrams"
  }
];
window.content_data_json = {
  "Requirement___19_0_4_7c8024c_1606044881570_420167_5379": {
    "title": "",
    "path": "\u003cdiv title\u003d\"Casos de uso\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_3_59501f0_1605898693468_780946_4813\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_3_59501f0_1605898693468_780946_4813\u0027);return false;\"\u003eCasos de uso\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Actores\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1606045670559_892273_6448\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1606045670559_892273_6448\u0027);return false;\"\u003eActores\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1606044881570_420167_5379\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_5.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1606044881570_420167_5379\u0027);return false;\"\u003e\u003ca\u003e\u003c/div\u003e",
    "html_panel": [],
    "grid_panel": [
      {
        "title": "Characteristics ",
        "hideHeaders": true,
        "data_store": {
          "fields": [
            "col0",
            "col1"
          ],
          "data": [
            {
              "col0": "Name ",
              "col1": "\u003cdiv title\u003d\"\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1606044881570_420167_5379\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_5.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1606044881570_420167_5379\u0027);return false;\"\u003e\u003ca\u003e\u003c/div\u003e"
            }
          ]
        },
        "columns": [
          {
            "text": "col0",
            "dataIndex": "col0",
            "flex": 0,
            "width": 192
          },
          {
            "text": "col1",
            "dataIndex": "col1",
            "flex": 1,
            "width": -1
          }
        ],
        "collapsible": false
      }
    ],
    "image_panel": []
  },
  "Implementation___19_0_4_7c8024c_1606060622302_113766_5116": {
    "title": "1.Introduccion",
    "path": "\u003cdiv title\u003d\"Documentacion del Proyecto Entrega 1\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1605542700510_677406_4795\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1605542700510_677406_4795\u0027);return false;\"\u003eDocumentacion del Proyecto Entrega 1\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"1.Introduccion\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Implementation___19_0_4_7c8024c_1606060622302_113766_5116\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_15.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Implementation___19_0_4_7c8024c_1606060622302_113766_5116\u0027);return false;\"\u003e1.Introduccion\u003ca\u003e\u003c/div\u003e",
    "html_panel": [],
    "grid_panel": [
      {
        "title": "Characteristics ",
        "hideHeaders": true,
        "data_store": {
          "fields": [
            "col0",
            "col1"
          ],
          "data": [
            {
              "col0": "Name ",
              "col1": "\u003cdiv title\u003d\"1.Introduccion\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Implementation___19_0_4_7c8024c_1606060622302_113766_5116\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_15.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Implementation___19_0_4_7c8024c_1606060622302_113766_5116\u0027);return false;\"\u003e1.Introduccion\u003ca\u003e\u003c/div\u003e"
            }
          ]
        },
        "columns": [
          {
            "text": "col0",
            "dataIndex": "col0",
            "flex": 0,
            "width": 192
          },
          {
            "text": "col1",
            "dataIndex": "col1",
            "flex": 1,
            "width": -1
          }
        ],
        "collapsible": false
      }
    ],
    "image_panel": []
  },
  "Implementation___19_0_4_7c8024c_1608491329083_791211_7570": {
    "title": "1.Introducción",
    "path": "\u003cdiv title\u003d\"Documentacion del Proyecto Entrega 2\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1608491267549_161671_7569\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1608491267549_161671_7569\u0027);return false;\"\u003eDocumentacion del Proyecto Entrega 2\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"1.Introducción\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Implementation___19_0_4_7c8024c_1608491329083_791211_7570\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_15.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Implementation___19_0_4_7c8024c_1608491329083_791211_7570\u0027);return false;\"\u003e1.Introducción\u003ca\u003e\u003c/div\u003e",
    "html_panel": [],
    "grid_panel": [
      {
        "title": "Characteristics ",
        "hideHeaders": true,
        "data_store": {
          "fields": [
            "col0",
            "col1"
          ],
          "data": [
            {
              "col0": "Name ",
              "col1": "\u003cdiv title\u003d\"1.Introducción\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Implementation___19_0_4_7c8024c_1608491329083_791211_7570\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_15.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Implementation___19_0_4_7c8024c_1608491329083_791211_7570\u0027);return false;\"\u003e1.Introducción\u003ca\u003e\u003c/div\u003e"
            }
          ]
        },
        "columns": [
          {
            "text": "col0",
            "dataIndex": "col0",
            "flex": 0,
            "width": 192
          },
          {
            "text": "col1",
            "dataIndex": "col1",
            "flex": 1,
            "width": -1
          }
        ],
        "collapsible": false
      }
    ],
    "image_panel": []
  },
  "Implementation___19_0_4_7c8024c_1606060528605_322680_5112": {
    "title": "10.Entorno Tecnológico",
    "path": "\u003cdiv title\u003d\"Documentacion del Proyecto Entrega 1\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1605542700510_677406_4795\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1605542700510_677406_4795\u0027);return false;\"\u003eDocumentacion del Proyecto Entrega 1\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"10.Entorno Tecnológico\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Implementation___19_0_4_7c8024c_1606060528605_322680_5112\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_15.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Implementation___19_0_4_7c8024c_1606060528605_322680_5112\u0027);return false;\"\u003e10.Entorno Tecnológico\u003ca\u003e\u003c/div\u003e",
    "html_panel": [],
    "grid_panel": [
      {
        "title": "Characteristics ",
        "hideHeaders": true,
        "data_store": {
          "fields": [
            "col0",
            "col1"
          ],
          "data": [
            {
              "col0": "Name ",
              "col1": "\u003cdiv title\u003d\"10.Entorno Tecnológico\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Implementation___19_0_4_7c8024c_1606060528605_322680_5112\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_15.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Implementation___19_0_4_7c8024c_1606060528605_322680_5112\u0027);return false;\"\u003e10.Entorno Tecnológico\u003ca\u003e\u003c/div\u003e"
            }
          ]
        },
        "columns": [
          {
            "text": "col0",
            "dataIndex": "col0",
            "flex": 0,
            "width": 192
          },
          {
            "text": "col1",
            "dataIndex": "col1",
            "flex": 1,
            "width": -1
          }
        ],
        "collapsible": false
      }
    ],
    "image_panel": []
  },
  "Implementation___19_0_4_7c8024c_1608491706642_526918_7610": {
    "title": "11.Descripcion de Integración de subsistemas",
    "path": "\u003cdiv title\u003d\"Documentacion del Proyecto Entrega 2\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1608491267549_161671_7569\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1608491267549_161671_7569\u0027);return false;\"\u003eDocumentacion del Proyecto Entrega 2\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"11.Descripcion de Integración de subsistemas\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Implementation___19_0_4_7c8024c_1608491706642_526918_7610\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_15.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Implementation___19_0_4_7c8024c_1608491706642_526918_7610\u0027);return false;\"\u003e11.Descripcion de Integración de subsistemas\u003ca\u003e\u003c/div\u003e",
    "html_panel": [],
    "grid_panel": [
      {
        "title": "Characteristics ",
        "hideHeaders": true,
        "data_store": {
          "fields": [
            "col0",
            "col1"
          ],
          "data": [
            {
              "col0": "Name ",
              "col1": "\u003cdiv title\u003d\"11.Descripcion de Integración de subsistemas\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Implementation___19_0_4_7c8024c_1608491706642_526918_7610\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_15.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Implementation___19_0_4_7c8024c_1608491706642_526918_7610\u0027);return false;\"\u003e11.Descripcion de Integración de subsistemas\u003ca\u003e\u003c/div\u003e"
            }
          ]
        },
        "columns": [
          {
            "text": "col0",
            "dataIndex": "col0",
            "flex": 0,
            "width": 192
          },
          {
            "text": "col1",
            "dataIndex": "col1",
            "flex": 1,
            "width": -1
          }
        ],
        "collapsible": false
      }
    ],
    "image_panel": []
  },
  "Implementation___19_0_4_7c8024c_1606060584140_87899_5113": {
    "title": "11.Estrategia de Implantación",
    "path": "\u003cdiv title\u003d\"Documentacion del Proyecto Entrega 1\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1605542700510_677406_4795\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1605542700510_677406_4795\u0027);return false;\"\u003eDocumentacion del Proyecto Entrega 1\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"11.Estrategia de Implantación\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Implementation___19_0_4_7c8024c_1606060584140_87899_5113\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_15.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Implementation___19_0_4_7c8024c_1606060584140_87899_5113\u0027);return false;\"\u003e11.Estrategia de Implantación\u003ca\u003e\u003c/div\u003e",
    "html_panel": [],
    "grid_panel": [
      {
        "title": "Characteristics ",
        "hideHeaders": true,
        "data_store": {
          "fields": [
            "col0",
            "col1"
          ],
          "data": [
            {
              "col0": "Name ",
              "col1": "\u003cdiv title\u003d\"11.Estrategia de Implantación\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Implementation___19_0_4_7c8024c_1606060584140_87899_5113\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_15.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Implementation___19_0_4_7c8024c_1606060584140_87899_5113\u0027);return false;\"\u003e11.Estrategia de Implantación\u003ca\u003e\u003c/div\u003e"
            }
          ]
        },
        "columns": [
          {
            "text": "col0",
            "dataIndex": "col0",
            "flex": 0,
            "width": 192
          },
          {
            "text": "col1",
            "dataIndex": "col1",
            "flex": 1,
            "width": -1
          }
        ],
        "collapsible": false
      }
    ],
    "image_panel": []
  },
  "Implementation___19_0_4_7c8024c_1608540241429_745140_8986": {
    "title": "14.Formatos de Pantalla",
    "path": "\u003cdiv title\u003d\"Documentacion del Proyecto Entrega 2\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1608491267549_161671_7569\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1608491267549_161671_7569\u0027);return false;\"\u003eDocumentacion del Proyecto Entrega 2\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"14.Formatos de Pantalla\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Implementation___19_0_4_7c8024c_1608540241429_745140_8986\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_15.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Implementation___19_0_4_7c8024c_1608540241429_745140_8986\u0027);return false;\"\u003e14.Formatos de Pantalla\u003ca\u003e\u003c/div\u003e",
    "html_panel": [],
    "grid_panel": [
      {
        "title": "Characteristics ",
        "hideHeaders": true,
        "data_store": {
          "fields": [
            "col0",
            "col1"
          ],
          "data": [
            {
              "col0": "Name ",
              "col1": "\u003cdiv title\u003d\"14.Formatos de Pantalla\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Implementation___19_0_4_7c8024c_1608540241429_745140_8986\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_15.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Implementation___19_0_4_7c8024c_1608540241429_745140_8986\u0027);return false;\"\u003e14.Formatos de Pantalla\u003ca\u003e\u003c/div\u003e"
            }
          ]
        },
        "columns": [
          {
            "text": "col0",
            "dataIndex": "col0",
            "flex": 0,
            "width": 192
          },
          {
            "text": "col1",
            "dataIndex": "col1",
            "flex": 1,
            "width": -1
          }
        ],
        "collapsible": false
      }
    ],
    "image_panel": []
  },
  "Package___19_0_4_65b021b_1608502989614_109664_7440": {
    "title": "2. Glosario",
    "path": "\u003cdiv title\u003d\"Documentacion del Proyecto Entrega 2\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1608491267549_161671_7569\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1608491267549_161671_7569\u0027);return false;\"\u003eDocumentacion del Proyecto Entrega 2\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"2. Glosario\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_65b021b_1608502989614_109664_7440\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_65b021b_1608502989614_109664_7440\u0027);return false;\"\u003e2. Glosario\u003ca\u003e\u003c/div\u003e",
    "html_panel": [],
    "grid_panel": [],
    "image_panel": []
  },
  "Implementation___19_0_4_7c8024c_1606060419638_663731_5107": {
    "title": "4.Catálogo de Requisitos",
    "path": "\u003cdiv title\u003d\"Documentacion del Proyecto Entrega 1\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1605542700510_677406_4795\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1605542700510_677406_4795\u0027);return false;\"\u003eDocumentacion del Proyecto Entrega 1\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"4.Catálogo de Requisitos\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Implementation___19_0_4_7c8024c_1606060419638_663731_5107\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_15.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Implementation___19_0_4_7c8024c_1606060419638_663731_5107\u0027);return false;\"\u003e4.Catálogo de Requisitos\u003ca\u003e\u003c/div\u003e",
    "html_panel": [],
    "grid_panel": [
      {
        "title": "Characteristics ",
        "hideHeaders": true,
        "data_store": {
          "fields": [
            "col0",
            "col1"
          ],
          "data": [
            {
              "col0": "Name ",
              "col1": "\u003cdiv title\u003d\"4.Catálogo de Requisitos\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Implementation___19_0_4_7c8024c_1606060419638_663731_5107\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_15.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Implementation___19_0_4_7c8024c_1606060419638_663731_5107\u0027);return false;\"\u003e4.Catálogo de Requisitos\u003ca\u003e\u003c/div\u003e"
            }
          ]
        },
        "columns": [
          {
            "text": "col0",
            "dataIndex": "col0",
            "flex": 0,
            "width": 192
          },
          {
            "text": "col1",
            "dataIndex": "col1",
            "flex": 1,
            "width": -1
          }
        ],
        "collapsible": false
      }
    ],
    "image_panel": []
  },
  "Implementation___19_0_4_7c8024c_1608491390629_320446_7573": {
    "title": "5.Catalogo de Requisitos",
    "path": "\u003cdiv title\u003d\"Documentacion del Proyecto Entrega 2\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1608491267549_161671_7569\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1608491267549_161671_7569\u0027);return false;\"\u003eDocumentacion del Proyecto Entrega 2\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"5.Catalogo de Requisitos\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Implementation___19_0_4_7c8024c_1608491390629_320446_7573\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_15.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Implementation___19_0_4_7c8024c_1608491390629_320446_7573\u0027);return false;\"\u003e5.Catalogo de Requisitos\u003ca\u003e\u003c/div\u003e",
    "html_panel": [],
    "grid_panel": [
      {
        "title": "Characteristics ",
        "hideHeaders": true,
        "data_store": {
          "fields": [
            "col0",
            "col1"
          ],
          "data": [
            {
              "col0": "Name ",
              "col1": "\u003cdiv title\u003d\"5.Catalogo de Requisitos\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Implementation___19_0_4_7c8024c_1608491390629_320446_7573\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_15.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Implementation___19_0_4_7c8024c_1608491390629_320446_7573\u0027);return false;\"\u003e5.Catalogo de Requisitos\u003ca\u003e\u003c/div\u003e"
            }
          ]
        },
        "columns": [
          {
            "text": "col0",
            "dataIndex": "col0",
            "flex": 0,
            "width": 192
          },
          {
            "text": "col1",
            "dataIndex": "col1",
            "flex": 1,
            "width": -1
          }
        ],
        "collapsible": false
      }
    ],
    "image_panel": []
  },
  "Implementation___19_0_4_7c8024c_1608491599000_508114_7604": {
    "title": "7.Catalogo de Usuarios",
    "path": "\u003cdiv title\u003d\"Documentacion del Proyecto Entrega 2\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1608491267549_161671_7569\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1608491267549_161671_7569\u0027);return false;\"\u003eDocumentacion del Proyecto Entrega 2\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"7.Catalogo de Usuarios\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Implementation___19_0_4_7c8024c_1608491599000_508114_7604\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_15.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Implementation___19_0_4_7c8024c_1608491599000_508114_7604\u0027);return false;\"\u003e7.Catalogo de Usuarios\u003ca\u003e\u003c/div\u003e",
    "html_panel": [],
    "grid_panel": [
      {
        "title": "Characteristics ",
        "hideHeaders": true,
        "data_store": {
          "fields": [
            "col0",
            "col1"
          ],
          "data": [
            {
              "col0": "Name ",
              "col1": "\u003cdiv title\u003d\"7.Catalogo de Usuarios\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Implementation___19_0_4_7c8024c_1608491599000_508114_7604\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_15.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Implementation___19_0_4_7c8024c_1608491599000_508114_7604\u0027);return false;\"\u003e7.Catalogo de Usuarios\u003ca\u003e\u003c/div\u003e"
            }
          ]
        },
        "columns": [
          {
            "text": "col0",
            "dataIndex": "col0",
            "flex": 0,
            "width": 192
          },
          {
            "text": "col1",
            "dataIndex": "col1",
            "flex": 1,
            "width": -1
          }
        ],
        "collapsible": false
      }
    ],
    "image_panel": []
  },
  "Implementation___19_0_4_7c8024c_1606060493989_308786_5110": {
    "title": "7.Descomposicion en Subsistemas",
    "path": "\u003cdiv title\u003d\"Documentacion del Proyecto Entrega 1\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1605542700510_677406_4795\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1605542700510_677406_4795\u0027);return false;\"\u003eDocumentacion del Proyecto Entrega 1\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"7.Descomposicion en Subsistemas\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Implementation___19_0_4_7c8024c_1606060493989_308786_5110\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_15.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Implementation___19_0_4_7c8024c_1606060493989_308786_5110\u0027);return false;\"\u003e7.Descomposicion en Subsistemas\u003ca\u003e\u003c/div\u003e",
    "html_panel": [],
    "grid_panel": [
      {
        "title": "Characteristics ",
        "hideHeaders": true,
        "data_store": {
          "fields": [
            "col0",
            "col1"
          ],
          "data": [
            {
              "col0": "Name ",
              "col1": "\u003cdiv title\u003d\"7.Descomposicion en Subsistemas\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Implementation___19_0_4_7c8024c_1606060493989_308786_5110\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_15.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Implementation___19_0_4_7c8024c_1606060493989_308786_5110\u0027);return false;\"\u003e7.Descomposicion en Subsistemas\u003ca\u003e\u003c/div\u003e"
            }
          ]
        },
        "columns": [
          {
            "text": "col0",
            "dataIndex": "col0",
            "flex": 0,
            "width": 192
          },
          {
            "text": "col1",
            "dataIndex": "col1",
            "flex": 1,
            "width": -1
          }
        ],
        "collapsible": false
      }
    ],
    "image_panel": []
  },
  "EmptyContent___19_0_4_7c8024c_1608385184925_923481_5923": {
    "title": "Aceptar Invitacion  Curso",
    "path": "\u003cdiv title\u003d\"Casos de uso\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_3_59501f0_1605898693468_780946_4813\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_3_59501f0_1605898693468_780946_4813\u0027);return false;\"\u003eCasos de uso\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Subsistema Curso\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1606045080271_940524_6239\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1606045080271_940524_6239\u0027);return false;\"\u003eSubsistema Curso\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Aceptar Invitacion  Curso\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1608384972544_746497_5858\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_6.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1608384972544_746497_5858\u0027);return false;\"\u003eAceptar Invitacion  Curso\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Aceptar Invitacion  Curso\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1608385184925_923481_5923\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_17.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1608385184925_923481_5923\u0027);return false;\"\u003eAceptar Invitacion  Curso\u003ca\u003e\u003c/div\u003e",
    "html_panel": [],
    "grid_panel": [],
    "image_panel": []
  },
  "EmptyContent___19_0_4_7c8024c_1608384972544_746497_5858": {
    "title": "Aceptar Invitacion  Curso",
    "path": "\u003cdiv title\u003d\"Casos de uso\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_3_59501f0_1605898693468_780946_4813\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_3_59501f0_1605898693468_780946_4813\u0027);return false;\"\u003eCasos de uso\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Subsistema Curso\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1606045080271_940524_6239\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1606045080271_940524_6239\u0027);return false;\"\u003eSubsistema Curso\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Aceptar Invitacion  Curso\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1608384972544_746497_5858\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_6.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1608384972544_746497_5858\u0027);return false;\"\u003eAceptar Invitacion  Curso\u003ca\u003e\u003c/div\u003e",
    "html_panel": [],
    "grid_panel": [],
    "image_panel": []
  },
  "Diagrams___19_0_4_7c8024c_1608464479043_18374_13440": {
    "title": "Aceptar Invitacion  Curso_imported",
    "path": "\u003cdiv title\u003d\"Casos de uso\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_3_59501f0_1605898693468_780946_4813\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_3_59501f0_1605898693468_780946_4813\u0027);return false;\"\u003eCasos de uso\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Subsistema Curso\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1606045080271_940524_6239\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1606045080271_940524_6239\u0027);return false;\"\u003eSubsistema Curso\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Aceptar Invitacion  Curso\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1608384972544_746497_5858\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_6.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1608384972544_746497_5858\u0027);return false;\"\u003eAceptar Invitacion  Curso\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Aceptar Invitacion  Curso\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1608385184925_923481_5923\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_17.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1608385184925_923481_5923\u0027);return false;\"\u003eAceptar Invitacion  Curso\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Aceptar Invitacion  Curso_imported\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Diagrams___19_0_4_7c8024c_1608464479043_18374_13440\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_16.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Diagrams___19_0_4_7c8024c_1608464479043_18374_13440\u0027);return false;\"\u003eAceptar Invitacion  Curso_imported\u003ca\u003e\u003c/div\u003e",
    "html_panel": [],
    "grid_panel": [],
    "image_panel": [
      {
        "title": "",
        "image": "diagrams/diagram_Diagrams___19_0_4_7c8024c_1608464479051_623815_13460.png",
        "width": 458,
        "height": 750,
        "collapsible": false,
        "map": {}
      }
    ]
  },
  "Package___19_0_4_7c8024c_1606045670559_892273_6448": {
    "title": "Actores",
    "path": "\u003cdiv title\u003d\"Casos de uso\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_3_59501f0_1605898693468_780946_4813\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_3_59501f0_1605898693468_780946_4813\u0027);return false;\"\u003eCasos de uso\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Actores\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1606045670559_892273_6448\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1606045670559_892273_6448\u0027);return false;\"\u003eActores\u003ca\u003e\u003c/div\u003e",
    "html_panel": [],
    "grid_panel": [],
    "image_panel": []
  },
  "Glossary___19_0_4_65b021b_1608501810045_588967_7396": {
    "title": "Alumno",
    "path": "\u003cdiv title\u003d\"Documentacion del Proyecto Entrega 2\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1608491267549_161671_7569\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1608491267549_161671_7569\u0027);return false;\"\u003eDocumentacion del Proyecto Entrega 2\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"2. Glosario\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_65b021b_1608502989614_109664_7440\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_65b021b_1608502989614_109664_7440\u0027);return false;\"\u003e2. Glosario\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Alumno\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Glossary___19_0_4_65b021b_1608501810045_588967_7396\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_25.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Glossary___19_0_4_65b021b_1608501810045_588967_7396\u0027);return false;\"\u003eAlumno\u003ca\u003e\u003c/div\u003e",
    "html_panel": [],
    "grid_panel": [
      {
        "title": "Characteristics ",
        "hideHeaders": true,
        "data_store": {
          "fields": [
            "col0",
            "col1"
          ],
          "data": [
            {
              "col0": "Term ",
              "col1": "\u003cdiv title\u003d\"Alumno\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Glossary___19_0_4_65b021b_1608501810045_588967_7396\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_25.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Glossary___19_0_4_65b021b_1608501810045_588967_7396\u0027);return false;\"\u003eAlumno\u003ca\u003e\u003c/div\u003e"
            },
            {
              "col0": "Description ",
              "col1": "Pueden visualizar y realizar tareas, cursos, talleres. Además pueden interactuar con otros usuarios.  "
            }
          ]
        },
        "columns": [
          {
            "text": "col0",
            "dataIndex": "col0",
            "flex": 0,
            "width": 192
          },
          {
            "text": "col1",
            "dataIndex": "col1",
            "flex": 1,
            "width": -1
          }
        ],
        "collapsible": false
      }
    ],
    "image_panel": []
  },
  "EmptyContent___19_0_3_5c401fe_1605961577354_733757_4911": {
    "title": "Autoregistro",
    "path": "\u003cdiv title\u003d\"Casos de uso\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_3_59501f0_1605898693468_780946_4813\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_3_59501f0_1605898693468_780946_4813\u0027);return false;\"\u003eCasos de uso\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Subsistema Identificación\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1605991759147_968139_5028\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1605991759147_968139_5028\u0027);return false;\"\u003eSubsistema Identificación\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Autoregistro\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_3_5c401fe_1605961577354_733757_4911\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_6.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_3_5c401fe_1605961577354_733757_4911\u0027);return false;\"\u003eAutoregistro\u003ca\u003e\u003c/div\u003e",
    "html_panel": [],
    "grid_panel": [],
    "image_panel": []
  },
  "Diagrams___19_0_4_7c8024c_1608397299611_104126_8854": {
    "title": "AutoregistroAlter",
    "path": "\u003cdiv title\u003d\"Casos de uso\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_3_59501f0_1605898693468_780946_4813\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_3_59501f0_1605898693468_780946_4813\u0027);return false;\"\u003eCasos de uso\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Subsistema Identificación\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1605991759147_968139_5028\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1605991759147_968139_5028\u0027);return false;\"\u003eSubsistema Identificación\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Autoregistro\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_3_5c401fe_1605961577354_733757_4911\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_6.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_3_5c401fe_1605961577354_733757_4911\u0027);return false;\"\u003eAutoregistro\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"AutoregistroAlter\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1608397299065_376454_7237\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_7.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1608397299065_376454_7237\u0027);return false;\"\u003eAutoregistroAlter\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"AutoregistroAlter\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Diagrams___19_0_4_7c8024c_1608397299611_104126_8854\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_18.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Diagrams___19_0_4_7c8024c_1608397299611_104126_8854\u0027);return false;\"\u003eAutoregistroAlter\u003ca\u003e\u003c/div\u003e",
    "html_panel": [],
    "grid_panel": [],
    "image_panel": [
      {
        "title": "",
        "image": "diagrams/diagram_Diagrams___19_0_4_7c8024c_1608397299620_874918_8874.png",
        "width": 958,
        "height": 678,
        "collapsible": false,
        "map": {}
      }
    ]
  },
  "EmptyContent___19_0_4_7c8024c_1608397299065_376454_7237": {
    "title": "AutoregistroAlter",
    "path": "\u003cdiv title\u003d\"Casos de uso\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_3_59501f0_1605898693468_780946_4813\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_3_59501f0_1605898693468_780946_4813\u0027);return false;\"\u003eCasos de uso\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Subsistema Identificación\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1605991759147_968139_5028\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1605991759147_968139_5028\u0027);return false;\"\u003eSubsistema Identificación\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Autoregistro\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_3_5c401fe_1605961577354_733757_4911\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_6.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_3_5c401fe_1605961577354_733757_4911\u0027);return false;\"\u003eAutoregistro\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"AutoregistroAlter\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1608397299065_376454_7237\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_7.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1608397299065_376454_7237\u0027);return false;\"\u003eAutoregistroAlter\u003ca\u003e\u003c/div\u003e",
    "html_panel": [],
    "grid_panel": [],
    "image_panel": []
  },
  "Requirement___19_0_4_7c8024c_1606044881556_666481_5369": {
    "title": "CUD calificaciones opcionales",
    "path": "\u003cdiv title\u003d\"Casos de uso\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_3_59501f0_1605898693468_780946_4813\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_3_59501f0_1605898693468_780946_4813\u0027);return false;\"\u003eCasos de uso\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Subsistema Curso\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1606045080271_940524_6239\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1606045080271_940524_6239\u0027);return false;\"\u003eSubsistema Curso\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"CUD calificaciones opcionales\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1606044881556_666481_5369\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_6.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1606044881556_666481_5369\u0027);return false;\"\u003eCUD calificaciones opcionales\u003ca\u003e\u003c/div\u003e",
    "html_panel": [],
    "grid_panel": [
      {
        "title": "Characteristics ",
        "hideHeaders": true,
        "data_store": {
          "fields": [
            "col0",
            "col1"
          ],
          "data": [
            {
              "col0": "Name ",
              "col1": "\u003cdiv title\u003d\"CUD calificaciones opcionales\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1606044881556_666481_5369\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_6.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1606044881556_666481_5369\u0027);return false;\"\u003eCUD calificaciones opcionales\u003ca\u003e\u003c/div\u003e"
            },
            {
              "col0": "Documentation ",
              "col1": "\u003chtml\u003e  \u003chead\u003e\t\t\u003cstyle\u003e\t\t\tp {padding:0px; margin:0px;}\t\t\u003c/style\u003e\t\u003c/head\u003e  \u003cbody\u003e    \u003cp\u003e\u003cb\u003e1. Crear calificaci\u0026oacute;n\u003c/b\u003e    \u003c/p\u003e    \u003cp\u003e1. A Escenario basico    \u003c/p\u003e    \u003cp\u003e\u0026#160;    \u003c/p\u003e    \u003cp style\u003d\"margin-left:20.0px;\"\u003e1. El usuario con permisos accede a la actividad de otro usuario (alumno)    \u003c/p\u003e    \u003cp style\u003d\"margin-left:20.0px;\"\u003e2. El sistema muestra la informaci\u0026oacute;n de la actividad y de lo que haya hecho el alumno    \u003c/p\u003e    \u003cp style\u003d\"margin-left:20.0px;\"\u003e3. El usuario escribe una calificaci\u0026oacute;n en la actividad    \u003c/p\u003e    \u003cp style\u003d\"margin-left:20.0px;\"\u003e4. El sistema guarda la calificaci\u0026oacute;n y la muestra en la actividad al alumno    \u003c/p\u003e    \u003cp\u003e\u0026#160;    \u003c/p\u003e    \u003cp\u003e1.B Escenario alternativo    \u003c/p\u003e    \u003cp\u003e\u0026#160;3b1: El usuario no escribe una calificaci\u0026oacute;n    \u003c/p\u003e    \u003cp\u003e3b2:\u0026#160;El sistema no hace cambios en la actividad    \u003c/p\u003e    \u003cp\u003e\u0026#160;\u0026#160;    \u003c/p\u003e    \u003cp\u003e\u003cb\u003e2. Modificar calificaci\u0026oacute;n\u003c/b\u003e    \u003c/p\u003e    \u003cp\u003e2. A Escenario basico    \u003c/p\u003e    \u003cp\u003e\u0026#160;    \u003c/p\u003e    \u003cp style\u003d\"margin-left:20.0px;\"\u003e1. El usuario con permisos accede a la actividad de otro usuario (alumno)    \u003c/p\u003e    \u003cp style\u003d\"margin-left:20.0px;\"\u003e2. El sistema muestra la informaci\u0026oacute;n de la actividad y de lo que haya hecho el alumno    \u003c/p\u003e    \u003cp style\u003d\"margin-left:20.0px;\"\u003e3. El usuario escribe una nueva calificaci\u0026oacute;n en la actividad    \u003c/p\u003e    \u003cp style\u003d\"margin-left:20.0px;\"\u003e4. El sistema reescribe la calificaci\u0026oacute;n y la muestra en la actividad al alumno    \u003c/p\u003e    \u003cp\u003e\u0026#160;    \u003c/p\u003e    \u003cp\u003e2.B Escenario alternativo    \u003c/p\u003e    \u003cp\u003e\u0026#160;4b1: Hay un problema al actualizar la nota    \u003c/p\u003e    \u003cp\u003e4b2:\u0026#160;El sistema no realiza cambios en la nota    \u003c/p\u003e    \u003cp\u003e\u0026#160;    \u003c/p\u003e    \u003cp\u003e\u0026#160;    \u003c/p\u003e    \u003cp\u003e\u003cb\u003e3. Eliminar calificaci\u0026oacute;n\u003c/b\u003e    \u003c/p\u003e    \u003cp\u003e3. A Escenario basico    \u003c/p\u003e    \u003cp\u003e\u0026#160;    \u003c/p\u003e    \u003cp style\u003d\"margin-left:20.0px;\"\u003e1. El usuario con permisos accede a la actividad de otro usuario (alumno)    \u003c/p\u003e    \u003cp style\u003d\"margin-left:20.0px;\"\u003e2. El sistema muestra la informaci\u0026oacute;n de la actividad y de lo que haya hecho el alumno    \u003c/p\u003e    \u003cp style\u003d\"margin-left:20.0px;\"\u003e3. El usuario borra la calificacion de la actividad    \u003c/p\u003e    \u003cp style\u003d\"margin-left:20.0px;\"\u003e4. El sistema quita la calificaci\u0026oacute;n de la actividad    \u003c/p\u003e    \u003cp\u003e\u0026#160;    \u003c/p\u003e    \u003cp\u003e3.B Escenario alternativo    \u003c/p\u003e    \u003cp\u003e\u0026#160;4b1: Hay un problema al actualizar la nota    \u003c/p\u003e    \u003cp\u003e4b2:\u0026#160;El sistema no realiza cambios en la nota\u0026#160;    \u003c/p\u003e\u003c/body\u003e\u003c/html\u003e "
            }
          ]
        },
        "columns": [
          {
            "text": "col0",
            "dataIndex": "col0",
            "flex": 0,
            "width": 192
          },
          {
            "text": "col1",
            "dataIndex": "col1",
            "flex": 1,
            "width": -1
          }
        ],
        "collapsible": true
      },
      {
        "title": "Actors",
        "hideHeaders": false,
        "data_store": {
          "fields": [
            "col0",
            "col1",
            "col2"
          ],
          "data": [
            {
              "col0": "1 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\"Administrador\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1606046179164_726532_6549\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_5.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1606046179164_726532_6549\u0027);return false;\"\u003eAdministrador\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col2": " \u003c/br\u003e"
            },
            {
              "col0": "2 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\"Organizacion\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1605993976012_561063_6365\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_5.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1605993976012_561063_6365\u0027);return false;\"\u003eOrganizacion\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col2": " \u003c/br\u003e"
            },
            {
              "col0": "3 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\"instructor\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1608378644060_454646_6215\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_5.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1608378644060_454646_6215\u0027);return false;\"\u003einstructor\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col2": " \u003c/br\u003e"
            },
            {
              "col0": "4 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\"Responsable\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1606044881567_954768_5376\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_5.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1606044881567_954768_5376\u0027);return false;\"\u003eResponsable\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col2": " \u003c/br\u003e"
            },
            {
              "col0": "5 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\"Instructor\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1605993976013_127053_6366\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_5.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1605993976013_127053_6366\u0027);return false;\"\u003eInstructor\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col2": " \u003c/br\u003e"
            },
            {
              "col0": "6 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\"Alumno\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1605993976012_184874_6364\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_5.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1605993976012_184874_6364\u0027);return false;\"\u003eAlumno\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col2": " \u003c/br\u003e"
            },
            {
              "col0": "7 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\"UMA\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1605992040306_840570_5282\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_5.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1605992040306_840570_5282\u0027);return false;\"\u003eUMA\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col2": " \u003c/br\u003e"
            },
            {
              "col0": "8 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\"\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1606044881570_420167_5379\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_5.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1606044881570_420167_5379\u0027);return false;\"\u003e\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col2": " \u003c/br\u003e"
            }
          ]
        },
        "columns": [
          {
            "text": "# ",
            "dataIndex": "col0",
            "flex": 0,
            "width": 84
          },
          {
            "text": "Name ",
            "dataIndex": "col1",
            "flex": 0,
            "width": 300
          },
          {
            "text": "Documentation ",
            "dataIndex": "col2",
            "flex": 1,
            "width": -1
          }
        ],
        "collapsible": true
      },
      {
        "title": "Owned Behaviors",
        "hideHeaders": false,
        "data_store": {
          "fields": [
            "col0",
            "col1",
            "col2"
          ],
          "data": [
            {
              "col0": "1 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\"Sec. modificar calificaciones opcionales\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_5b201fd_1608474910092_740995_9709\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_7.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_5b201fd_1608474910092_740995_9709\u0027);return false;\"\u003eSec. modificar calificaciones opcionales\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col2": " \u003c/br\u003e"
            },
            {
              "col0": "2 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\"Sec. modificar calificaciones opcionales alternativo\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_5b201fd_1608480046746_671379_10401\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_7.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_5b201fd_1608480046746_671379_10401\u0027);return false;\"\u003eSec. modificar calificaciones opcionales alternativo\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col2": " \u003c/br\u003e"
            }
          ]
        },
        "columns": [
          {
            "text": "# ",
            "dataIndex": "col0",
            "flex": 0,
            "width": 84
          },
          {
            "text": "Name ",
            "dataIndex": "col1",
            "flex": 0,
            "width": 300
          },
          {
            "text": "Documentation ",
            "dataIndex": "col2",
            "flex": 1,
            "width": -1
          }
        ],
        "collapsible": true
      }
    ],
    "image_panel": []
  },
  "Glossary___19_0_4_65b021b_1608503037273_207154_7461": {
    "title": "Calendario",
    "path": "\u003cdiv title\u003d\"Documentacion del Proyecto Entrega 2\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1608491267549_161671_7569\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1608491267549_161671_7569\u0027);return false;\"\u003eDocumentacion del Proyecto Entrega 2\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"2. Glosario\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_65b021b_1608502989614_109664_7440\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_65b021b_1608502989614_109664_7440\u0027);return false;\"\u003e2. Glosario\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Calendario\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Glossary___19_0_4_65b021b_1608503037273_207154_7461\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_25.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Glossary___19_0_4_65b021b_1608503037273_207154_7461\u0027);return false;\"\u003eCalendario\u003ca\u003e\u003c/div\u003e",
    "html_panel": [],
    "grid_panel": [
      {
        "title": "Characteristics ",
        "hideHeaders": true,
        "data_store": {
          "fields": [
            "col0",
            "col1"
          ],
          "data": [
            {
              "col0": "Term ",
              "col1": "\u003cdiv title\u003d\"Calendario\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Glossary___19_0_4_65b021b_1608503037273_207154_7461\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_25.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Glossary___19_0_4_65b021b_1608503037273_207154_7461\u0027);return false;\"\u003eCalendario\u003ca\u003e\u003c/div\u003e"
            },
            {
              "col0": "Description ",
              "col1": "En el se muestra la fecha de entrega de las tareas. "
            }
          ]
        },
        "columns": [
          {
            "text": "col0",
            "dataIndex": "col0",
            "flex": 0,
            "width": 192
          },
          {
            "text": "col1",
            "dataIndex": "col1",
            "flex": 1,
            "width": -1
          }
        ],
        "collapsible": false
      }
    ],
    "image_panel": []
  },
  "Package___19_0_3_59501f0_1605898693468_780946_4813": {
    "title": "Casos de uso",
    "path": "\u003cdiv title\u003d\"Casos de uso\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_3_59501f0_1605898693468_780946_4813\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_3_59501f0_1605898693468_780946_4813\u0027);return false;\"\u003eCasos de uso\u003ca\u003e\u003c/div\u003e",
    "html_panel": [],
    "grid_panel": [],
    "image_panel": []
  },
  "Glossary___19_0_4_65b021b_1608503622712_178899_7486": {
    "title": "Clase grabada",
    "path": "\u003cdiv title\u003d\"Documentacion del Proyecto Entrega 2\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1608491267549_161671_7569\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1608491267549_161671_7569\u0027);return false;\"\u003eDocumentacion del Proyecto Entrega 2\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"2. Glosario\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_65b021b_1608502989614_109664_7440\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_65b021b_1608502989614_109664_7440\u0027);return false;\"\u003e2. Glosario\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Clase grabada\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Glossary___19_0_4_65b021b_1608503622712_178899_7486\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_25.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Glossary___19_0_4_65b021b_1608503622712_178899_7486\u0027);return false;\"\u003eClase grabada\u003ca\u003e\u003c/div\u003e",
    "html_panel": [],
    "grid_panel": [
      {
        "title": "Characteristics ",
        "hideHeaders": true,
        "data_store": {
          "fields": [
            "col0",
            "col1"
          ],
          "data": [
            {
              "col0": "Term ",
              "col1": "\u003cdiv title\u003d\"Clase grabada\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Glossary___19_0_4_65b021b_1608503622712_178899_7486\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_25.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Glossary___19_0_4_65b021b_1608503622712_178899_7486\u0027);return false;\"\u003eClase grabada\u003ca\u003e\u003c/div\u003e"
            },
            {
              "col0": "Description ",
              "col1": "Son seminarios online que han sido guardados para poder visualizarse en otro momento. "
            }
          ]
        },
        "columns": [
          {
            "text": "col0",
            "dataIndex": "col0",
            "flex": 0,
            "width": 192
          },
          {
            "text": "col1",
            "dataIndex": "col1",
            "flex": 1,
            "width": -1
          }
        ],
        "collapsible": false
      }
    ],
    "image_panel": []
  },
  "Package___19_0_4_7c8024c_1608218571669_136949_5237": {
    "title": "Control",
    "path": "\u003cdiv title\u003d\"Estructura\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1606752452637_33243_5229\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1606752452637_33243_5229\u0027);return false;\"\u003eEstructura\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Control\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1608218571669_136949_5237\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1608218571669_136949_5237\u0027);return false;\"\u003eControl\u003ca\u003e\u003c/div\u003e",
    "html_panel": [],
    "grid_panel": [],
    "image_panel": []
  },
  "Requirement___19_0_3_5c401fe_1605960554152_674012_5202": {
    "title": "Crear POST",
    "path": "\u003cdiv title\u003d\"Casos de uso\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_3_59501f0_1605898693468_780946_4813\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_3_59501f0_1605898693468_780946_4813\u0027);return false;\"\u003eCasos de uso\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Subsistema Foro\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1605975887729_200757_5237\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1605975887729_200757_5237\u0027);return false;\"\u003eSubsistema Foro\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Crear POST\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_3_5c401fe_1605960554152_674012_5202\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_6.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_3_5c401fe_1605960554152_674012_5202\u0027);return false;\"\u003eCrear POST\u003ca\u003e\u003c/div\u003e",
    "html_panel": [],
    "grid_panel": [
      {
        "title": "Characteristics ",
        "hideHeaders": true,
        "data_store": {
          "fields": [
            "col0",
            "col1"
          ],
          "data": [
            {
              "col0": "Name ",
              "col1": "\u003cdiv title\u003d\"Crear POST\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_3_5c401fe_1605960554152_674012_5202\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_6.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_3_5c401fe_1605960554152_674012_5202\u0027);return false;\"\u003eCrear POST\u003ca\u003e\u003c/div\u003e"
            }
          ]
        },
        "columns": [
          {
            "text": "col0",
            "dataIndex": "col0",
            "flex": 0,
            "width": 192
          },
          {
            "text": "col1",
            "dataIndex": "col1",
            "flex": 1,
            "width": -1
          }
        ],
        "collapsible": true
      },
      {
        "title": "Actors",
        "hideHeaders": false,
        "data_store": {
          "fields": [
            "col0",
            "col1",
            "col2"
          ],
          "data": [
            {
              "col0": "1 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\"Administrador\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1606046179164_726532_6549\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_5.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1606046179164_726532_6549\u0027);return false;\"\u003eAdministrador\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col2": " \u003c/br\u003e"
            },
            {
              "col0": "2 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\"Organizacion\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1605993976012_561063_6365\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_5.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1605993976012_561063_6365\u0027);return false;\"\u003eOrganizacion\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col2": " \u003c/br\u003e"
            },
            {
              "col0": "3 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\"instructor\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1608378644060_454646_6215\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_5.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1608378644060_454646_6215\u0027);return false;\"\u003einstructor\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col2": " \u003c/br\u003e"
            },
            {
              "col0": "4 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\"Alumno\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1605993976012_184874_6364\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_5.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1605993976012_184874_6364\u0027);return false;\"\u003eAlumno\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col2": " \u003c/br\u003e"
            },
            {
              "col0": "5 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\"Instructor\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1605993976013_127053_6366\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_5.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1605993976013_127053_6366\u0027);return false;\"\u003eInstructor\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col2": " \u003c/br\u003e"
            },
            {
              "col0": "6 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\"UMA\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1605992040306_840570_5282\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_5.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1605992040306_840570_5282\u0027);return false;\"\u003eUMA\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col2": " \u003c/br\u003e"
            }
          ]
        },
        "columns": [
          {
            "text": "# ",
            "dataIndex": "col0",
            "flex": 0,
            "width": 84
          },
          {
            "text": "Name ",
            "dataIndex": "col1",
            "flex": 0,
            "width": 300
          },
          {
            "text": "Documentation ",
            "dataIndex": "col2",
            "flex": 1,
            "width": -1
          }
        ],
        "collapsible": true
      },
      {
        "title": "Owned Behaviors",
        "hideHeaders": false,
        "data_store": {
          "fields": [
            "col0",
            "col1",
            "col2"
          ],
          "data": [
            {
              "col0": "1 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\"Crear POST\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_3_5c401fe_1605961084958_564954_5325\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_17.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_3_5c401fe_1605961084958_564954_5325\u0027);return false;\"\u003eCrear POST\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col2": " \u003c/br\u003e"
            },
            {
              "col0": "2 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\"Crear POST\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1608378644127_40994_6359\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_7.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1608378644127_40994_6359\u0027);return false;\"\u003eCrear POST\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col2": " \u003c/br\u003e"
            },
            {
              "col0": "3 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\"Crear POSTAlter\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1608397299044_54493_7217\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_7.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1608397299044_54493_7217\u0027);return false;\"\u003eCrear POSTAlter\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col2": " \u003c/br\u003e"
            }
          ]
        },
        "columns": [
          {
            "text": "# ",
            "dataIndex": "col0",
            "flex": 0,
            "width": 84
          },
          {
            "text": "Name ",
            "dataIndex": "col1",
            "flex": 0,
            "width": 300
          },
          {
            "text": "Documentation ",
            "dataIndex": "col2",
            "flex": 1,
            "width": -1
          }
        ],
        "collapsible": true
      },
      {
        "title": "Scenario - Basic Flow ",
        "hideHeaders": true,
        "data_store": {
          "fields": [
            "col0"
          ],
          "data": [
            {
              "col0": "1. El usuario puede crear un POST atraves de un boton habilitado en la pantalla "
            },
            {
              "col0": "2. Para que el POST pueda ser creado se debera cumplir unas normas comunitarias y de creacion, en concreto, poner un titulo y contenido minimo en el post. "
            },
            {
              "col0": "3. Se podra utilizar tools para añadir hypervinculos, alterar la caligrafia etc. Tambien se podra mencionar a otros participantes del foro. "
            }
          ]
        },
        "columns": [
          {
            "text": "col0",
            "dataIndex": "col0",
            "flex": 1,
            "width": -1
          }
        ],
        "collapsible": true
      }
    ],
    "image_panel": []
  },
  "EmptyContent___19_0_4_7c8024c_1605544888603_669246_5036": {
    "title": "Crud Alumnos",
    "path": "\u003cdiv title\u003d\"Casos de uso\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_3_59501f0_1605898693468_780946_4813\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_3_59501f0_1605898693468_780946_4813\u0027);return false;\"\u003eCasos de uso\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Subsistema Curso\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1606045080271_940524_6239\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1606045080271_940524_6239\u0027);return false;\"\u003eSubsistema Curso\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Crud Alumnos\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1605544888603_669246_5036\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_6.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1605544888603_669246_5036\u0027);return false;\"\u003eCrud Alumnos\u003ca\u003e\u003c/div\u003e",
    "html_panel": [],
    "grid_panel": [],
    "image_panel": []
  },
  "Architecture___19_0_4_7c8024c_1608233830258_399547_6406": {
    "title": "Crud Alumnos-CREAR-ALTERNATIVO-2",
    "path": "\u003cdiv title\u003d\"Casos de uso\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_3_59501f0_1605898693468_780946_4813\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_3_59501f0_1605898693468_780946_4813\u0027);return false;\"\u003eCasos de uso\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Subsistema Curso\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1606045080271_940524_6239\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1606045080271_940524_6239\u0027);return false;\"\u003eSubsistema Curso\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Crud Alumnos\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1605544888603_669246_5036\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_6.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1605544888603_669246_5036\u0027);return false;\"\u003eCrud Alumnos\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Crud Alumnos-CREAR-ALTERNATIVO-2\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1608233830258_399547_6406\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_7.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1608233830258_399547_6406\u0027);return false;\"\u003eCrud Alumnos-CREAR-ALTERNATIVO-2\u003ca\u003e\u003c/div\u003e",
    "html_panel": [],
    "grid_panel": [
      {
        "title": "Characteristics ",
        "hideHeaders": true,
        "data_store": {
          "fields": [
            "col0",
            "col1"
          ],
          "data": [
            {
              "col0": "Name ",
              "col1": "\u003cdiv title\u003d\"Crud Alumnos-CREAR-ALTERNATIVO-2\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1608233830258_399547_6406\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_7.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1608233830258_399547_6406\u0027);return false;\"\u003eCrud Alumnos-CREAR-ALTERNATIVO-2\u003ca\u003e\u003c/div\u003e"
            }
          ]
        },
        "columns": [
          {
            "text": "col0",
            "dataIndex": "col0",
            "flex": 0,
            "width": 192
          },
          {
            "text": "col1",
            "dataIndex": "col1",
            "flex": 1,
            "width": -1
          }
        ],
        "collapsible": true
      },
      {
        "title": "Attributes",
        "hideHeaders": false,
        "data_store": {
          "fields": [
            "col0",
            "col1",
            "col2",
            "col3",
            "col4",
            "col5"
          ],
          "data": [
            {
              "col0": "1 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\": Administrador\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_19.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e : Administrador\u003c/div\u003e\u003c/br\u003e",
              "col2": "\u003cdiv title\u003d\"Administrador\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1606046179164_726532_6549\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_5.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1606046179164_726532_6549\u0027);return false;\"\u003eAdministrador\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col3": " \u003c/br\u003e",
              "col4": " \u003c/br\u003e",
              "col5": " \u003c/br\u003e"
            },
            {
              "col0": "2 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\": ViewCrearAlumno\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_19.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e : ViewCrearAlumno\u003c/div\u003e\u003c/br\u003e",
              "col2": "\u003cdiv title\u003d\"ViewCrearAlumno\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_4_7c8024c_1608540943918_129963_9018\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_27.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_4_7c8024c_1608540943918_129963_9018\u0027);return false;\"\u003eViewCrearAlumno\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col3": " \u003c/br\u003e",
              "col4": " \u003c/br\u003e",
              "col5": " \u003c/br\u003e"
            },
            {
              "col0": "3 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\": CtrAlumno\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_19.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e : CtrAlumno\u003c/div\u003e\u003c/br\u003e",
              "col2": "\u003cdiv title\u003d\"CtrAlumno\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_4_7c8024c_1608227571310_586942_5406\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_26.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_4_7c8024c_1608227571310_586942_5406\u0027);return false;\"\u003eCtrAlumno\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col3": " \u003c/br\u003e",
              "col4": " \u003c/br\u003e",
              "col5": " \u003c/br\u003e"
            },
            {
              "col0": "4 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\"todos : Alumno\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_19.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e todos : Alumno\u003c/div\u003e\u003c/br\u003e",
              "col2": "\u003cdiv title\u003d\"Alumno\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_4_7c8024c_1606752667095_524856_5295\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_28.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_4_7c8024c_1606752667095_524856_5295\u0027);return false;\"\u003eAlumno\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col3": " \u003c/br\u003e",
              "col4": " \u003c/br\u003e",
              "col5": " \u003c/br\u003e"
            },
            {
              "col0": "5 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\": Administrador\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_19.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e : Administrador\u003c/div\u003e\u003c/br\u003e",
              "col2": "\u003cdiv title\u003d\"Administrador\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1606046179164_726532_6549\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_5.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1606046179164_726532_6549\u0027);return false;\"\u003eAdministrador\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col3": " \u003c/br\u003e",
              "col4": " \u003c/br\u003e",
              "col5": " \u003c/br\u003e"
            },
            {
              "col0": "6 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\": ViewUnAlumno\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_19.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e : ViewUnAlumno\u003c/div\u003e\u003c/br\u003e",
              "col2": "\u003cdiv title\u003d\"ViewUnAlumno\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_4_7c8024c_1608229988440_92985_5870\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_27.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_4_7c8024c_1608229988440_92985_5870\u0027);return false;\"\u003eViewUnAlumno\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col3": " \u003c/br\u003e",
              "col4": " \u003c/br\u003e",
              "col5": " \u003c/br\u003e"
            },
            {
              "col0": "7 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\": CtrAlumno\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_19.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e : CtrAlumno\u003c/div\u003e\u003c/br\u003e",
              "col2": "\u003cdiv title\u003d\"CtrAlumno\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_4_7c8024c_1608227571310_586942_5406\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_26.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_4_7c8024c_1608227571310_586942_5406\u0027);return false;\"\u003eCtrAlumno\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col3": " \u003c/br\u003e",
              "col4": " \u003c/br\u003e",
              "col5": " \u003c/br\u003e"
            },
            {
              "col0": "8 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\": Administrador\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_19.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e : Administrador\u003c/div\u003e\u003c/br\u003e",
              "col2": "\u003cdiv title\u003d\"Administrador\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1606046179164_726532_6549\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_5.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1606046179164_726532_6549\u0027);return false;\"\u003eAdministrador\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col3": " \u003c/br\u003e",
              "col4": " \u003c/br\u003e",
              "col5": " \u003c/br\u003e"
            },
            {
              "col0": "9 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\": ViewUnAlumno\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_19.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e : ViewUnAlumno\u003c/div\u003e\u003c/br\u003e",
              "col2": "\u003cdiv title\u003d\"ViewUnAlumno\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_4_7c8024c_1608229988440_92985_5870\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_27.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_4_7c8024c_1608229988440_92985_5870\u0027);return false;\"\u003eViewUnAlumno\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col3": " \u003c/br\u003e",
              "col4": " \u003c/br\u003e",
              "col5": " \u003c/br\u003e"
            },
            {
              "col0": "10 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\": CtrAlumno\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_19.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e : CtrAlumno\u003c/div\u003e\u003c/br\u003e",
              "col2": "\u003cdiv title\u003d\"CtrAlumno\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_4_7c8024c_1608227571310_586942_5406\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_26.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_4_7c8024c_1608227571310_586942_5406\u0027);return false;\"\u003eCtrAlumno\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col3": " \u003c/br\u003e",
              "col4": " \u003c/br\u003e",
              "col5": " \u003c/br\u003e"
            }
          ]
        },
        "columns": [
          {
            "text": "# ",
            "dataIndex": "col0",
            "flex": 0,
            "width": 96
          },
          {
            "text": "Name ",
            "dataIndex": "col1",
            "flex": 0,
            "width": 300
          },
          {
            "text": "Type ",
            "dataIndex": "col2",
            "flex": 0,
            "width": 300
          },
          {
            "text": "Multiplicity ",
            "dataIndex": "col3",
            "flex": 0,
            "width": 156
          },
          {
            "text": "Default value ",
            "dataIndex": "col4",
            "flex": 0,
            "width": 168
          },
          {
            "text": "Documentation ",
            "dataIndex": "col5",
            "flex": 1,
            "width": -1
          }
        ],
        "collapsible": true
      }
    ],
    "image_panel": [
      {
        "title": "Crud Alumnos-CREAR-ALTERNATIVO-2",
        "image": "diagrams/diagram_Architecture___19_0_4_7c8024c_1608233830267_930921_6427.png",
        "width": 1186,
        "height": 757,
        "collapsible": true,
        "map": {}
      },
      {
        "title": "Crud Alumnos-CREAR-ALTERNATIVO-2_imported",
        "image": "diagrams/diagram_Architecture___19_0_4_7c8024c_1608397299968_302499_9922.png",
        "width": 1186,
        "height": 757,
        "collapsible": true,
        "map": {}
      },
      {
        "title": "Crud Alumnos-CREAR-ALTERNATIVO-2_imported1",
        "image": "diagrams/diagram_Architecture___19_0_4_7c8024c_1608464478574_906653_11787.png",
        "width": 1186,
        "height": 757,
        "collapsible": true,
        "map": {}
      }
    ]
  },
  "Requirement___19_0_4_7c8024c_1605544934734_89990_5051": {
    "title": "Crud de ONG",
    "path": "\u003cdiv title\u003d\"Casos de uso\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_3_59501f0_1605898693468_780946_4813\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_3_59501f0_1605898693468_780946_4813\u0027);return false;\"\u003eCasos de uso\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Subsistema Curso\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1606045080271_940524_6239\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1606045080271_940524_6239\u0027);return false;\"\u003eSubsistema Curso\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Crud de ONG\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1605544934734_89990_5051\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_6.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1605544934734_89990_5051\u0027);return false;\"\u003eCrud de ONG\u003ca\u003e\u003c/div\u003e",
    "html_panel": [],
    "grid_panel": [
      {
        "title": "Characteristics ",
        "hideHeaders": true,
        "data_store": {
          "fields": [
            "col0",
            "col1"
          ],
          "data": [
            {
              "col0": "Name ",
              "col1": "\u003cdiv title\u003d\"Crud de ONG\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1605544934734_89990_5051\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_6.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1605544934734_89990_5051\u0027);return false;\"\u003eCrud de ONG\u003ca\u003e\u003c/div\u003e"
            },
            {
              "col0": "Documentation ",
              "col1": "\u003chtml\u003e  \u003chead\u003e\t\t\u003cstyle\u003e\t\t\tp {padding:0px; margin:0px;}\t\t\u003c/style\u003e\t\u003c/head\u003e  \u003cbody\u003e    \u003cp\u003e\u003cb\u003eCrear ONG:\u003c/b\u003e    \u003c/p\u003e    \u003cul\u003e      \u003cli\u003eCaso base:      \u003c/li\u003e    \u003c/ul\u003e    \u003col\u003e      \u003cli\u003eEl usuario solicita crear nueva ONG.      \u003c/li\u003e      \u003cli\u003eEl sistema solicita los datos necesarios.      \u003c/li\u003e      \u003cli\u003eEl usuario introduce los datos.      \u003c/li\u003e      \u003cli\u003eEl sistema comprueba que los datos sean correctos y a\u0026ntilde;ade la nueva ONG.      \u003c/li\u003e    \u003c/ol\u003e    \u003cul\u003e      \u003cli\u003eCaso Alternativo:      \u003c/li\u003e    \u003c/ul\u003e    \u003col\u003e      \u003cli\u003eEl usuario solicita crear una nueva ONG.      \u003c/li\u003e      \u003cli\u003eEl sistema solicita los datos necesarios.      \u003c/li\u003e      \u003cli\u003eEl usuario introduce los datos.      \u003c/li\u003e      \u003cli\u003eEl sistema comprueba que los datos sean correctos.      \u003c/li\u003e      \u003cli\u003eEl sistema envia un mensaje \u0026quot;Faltan datos obligatorios\u0026quot; o un mensaje de error detallando el problema.      \u003c/li\u003e    \u003c/ol\u003e    \u003cp\u003e\u003cb\u003eModificar ONG:\u003c/b\u003e    \u003c/p\u003e    \u003cul\u003e      \u003cli\u003eCaso base:      \u003c/li\u003e    \u003c/ul\u003e    \u003col\u003e      \u003cli\u003eEl usuario solicita modificar una ONG.      \u003c/li\u003e      \u003cli\u003eEl sistema muestra una lista de las ONG.      \u003c/li\u003e      \u003cli\u003eEl usuario selecciona a la ONG que desea modificar.      \u003c/li\u003e      \u003cli\u003eEl sistema solicita los datos necesarios.      \u003c/li\u003e      \u003cli\u003eEl usuario introduce los datos.      \u003c/li\u003e      \u003cli\u003eEl sistema comprueba que los datos sean correctos y modifica los datos de la ONG.      \u003c/li\u003e    \u003c/ol\u003e    \u003cul\u003e      \u003cli\u003eCaso Alternativo:      \u003c/li\u003e    \u003c/ul\u003e    \u003col\u003e      \u003cli\u003eEl usuario solicita modificar una ONG.      \u003c/li\u003e      \u003cli\u003eEl sistema muestra una lista de las ONG.      \u003c/li\u003e      \u003cli\u003eEl usuario selecciona la ONG que desea modificar.      \u003c/li\u003e      \u003cli\u003eEl sistema solicita los datos necesarios.      \u003c/li\u003e      \u003cli\u003eEl usuario introduce los datos.      \u003c/li\u003e      \u003cli\u003eEl sistema comprueba que los datos sean correctos.      \u003c/li\u003e      \u003cli\u003eEl sistema envia un mensaje \u0026quot;Faltan datos obligatorios\u0026quot; o un mensaje de error detallando el problema.      \u003c/li\u003e    \u003c/ol\u003e    \u003cp\u003e\u003cb\u003eConsultar ONG:\u003c/b\u003e    \u003c/p\u003e    \u003col\u003e      \u003cli\u003eEl usuario solicita consultar una ONG.      \u003c/li\u003e      \u003cli\u003eEl sistema muestra una lista de las ONG.      \u003c/li\u003e      \u003cli\u003eEl usuario selecciona la ONG que desea consultar.      \u003c/li\u003e      \u003cli\u003eEl sistema muestra los datos de la ONG seleccionado.      \u003c/li\u003e    \u003c/ol\u003e    \u003cp\u003e\u003cb\u003eEliminar ONG:\u003c/b\u003e    \u003c/p\u003e    \u003cul\u003e      \u003cli\u003eCaso base:      \u003c/li\u003e    \u003c/ul\u003e    \u003col\u003e      \u003cli\u003eEl usuario solicita eliminar una ONG.      \u003c/li\u003e      \u003cli\u003eEl sistema muestra una lista de las ONG.      \u003c/li\u003e      \u003cli\u003eEl usuario selecciona la ONG que desea eliminar.      \u003c/li\u003e      \u003cli\u003eEl sistema elimina los datos de la ONG.      \u003c/li\u003e    \u003c/ol\u003e\u003c/body\u003e\u003c/html\u003e "
            }
          ]
        },
        "columns": [
          {
            "text": "col0",
            "dataIndex": "col0",
            "flex": 0,
            "width": 192
          },
          {
            "text": "col1",
            "dataIndex": "col1",
            "flex": 1,
            "width": -1
          }
        ],
        "collapsible": true
      },
      {
        "title": "Actors",
        "hideHeaders": false,
        "data_store": {
          "fields": [
            "col0",
            "col1",
            "col2"
          ],
          "data": [
            {
              "col0": "1 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\"Administrador\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1606046179164_726532_6549\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_5.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1606046179164_726532_6549\u0027);return false;\"\u003eAdministrador\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col2": " \u003c/br\u003e"
            },
            {
              "col0": "2 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\"Organizacion\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1605993976012_561063_6365\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_5.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1605993976012_561063_6365\u0027);return false;\"\u003eOrganizacion\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col2": " \u003c/br\u003e"
            },
            {
              "col0": "3 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\"instructor\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1608378644060_454646_6215\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_5.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1608378644060_454646_6215\u0027);return false;\"\u003einstructor\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col2": " \u003c/br\u003e"
            },
            {
              "col0": "4 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\"Instructor\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1605993976013_127053_6366\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_5.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1605993976013_127053_6366\u0027);return false;\"\u003eInstructor\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col2": " \u003c/br\u003e"
            },
            {
              "col0": "5 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\"Alumno\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1605993976012_184874_6364\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_5.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1605993976012_184874_6364\u0027);return false;\"\u003eAlumno\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col2": " \u003c/br\u003e"
            },
            {
              "col0": "6 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\"UMA\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1605992040306_840570_5282\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_5.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1605992040306_840570_5282\u0027);return false;\"\u003eUMA\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col2": " \u003c/br\u003e"
            }
          ]
        },
        "columns": [
          {
            "text": "# ",
            "dataIndex": "col0",
            "flex": 0,
            "width": 84
          },
          {
            "text": "Name ",
            "dataIndex": "col1",
            "flex": 0,
            "width": 300
          },
          {
            "text": "Documentation ",
            "dataIndex": "col2",
            "flex": 1,
            "width": -1
          }
        ],
        "collapsible": true
      },
      {
        "title": "Owned Behaviors",
        "hideHeaders": false,
        "data_store": {
          "fields": [
            "col0",
            "col1",
            "col2"
          ],
          "data": [
            {
              "col0": "1 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\"Crud de ONG\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1608378644162_795769_6414\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_7.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1608378644162_795769_6414\u0027);return false;\"\u003eCrud de ONG\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col2": " \u003c/br\u003e"
            }
          ]
        },
        "columns": [
          {
            "text": "# ",
            "dataIndex": "col0",
            "flex": 0,
            "width": 84
          },
          {
            "text": "Name ",
            "dataIndex": "col1",
            "flex": 0,
            "width": 300
          },
          {
            "text": "Documentation ",
            "dataIndex": "col2",
            "flex": 1,
            "width": -1
          }
        ],
        "collapsible": true
      }
    ],
    "image_panel": []
  },
  "Architecture___19_0_4_7c8024c_1608378644162_795769_6414": {
    "title": "Crud de ONG",
    "path": "\u003cdiv title\u003d\"Casos de uso\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_3_59501f0_1605898693468_780946_4813\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_3_59501f0_1605898693468_780946_4813\u0027);return false;\"\u003eCasos de uso\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Subsistema Curso\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1606045080271_940524_6239\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1606045080271_940524_6239\u0027);return false;\"\u003eSubsistema Curso\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Crud de ONG\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1605544934734_89990_5051\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_6.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1605544934734_89990_5051\u0027);return false;\"\u003eCrud de ONG\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Crud de ONG\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1608378644162_795769_6414\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_7.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1608378644162_795769_6414\u0027);return false;\"\u003eCrud de ONG\u003ca\u003e\u003c/div\u003e",
    "html_panel": [],
    "grid_panel": [
      {
        "title": "Characteristics ",
        "hideHeaders": true,
        "data_store": {
          "fields": [
            "col0",
            "col1"
          ],
          "data": [
            {
              "col0": "Name ",
              "col1": "\u003cdiv title\u003d\"Crud de ONG\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1608378644162_795769_6414\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_7.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1608378644162_795769_6414\u0027);return false;\"\u003eCrud de ONG\u003ca\u003e\u003c/div\u003e"
            }
          ]
        },
        "columns": [
          {
            "text": "col0",
            "dataIndex": "col0",
            "flex": 0,
            "width": 192
          },
          {
            "text": "col1",
            "dataIndex": "col1",
            "flex": 1,
            "width": -1
          }
        ],
        "collapsible": true
      },
      {
        "title": "Attributes",
        "hideHeaders": false,
        "data_store": {
          "fields": [
            "col0",
            "col1",
            "col2",
            "col3",
            "col4",
            "col5"
          ],
          "data": [
            {
              "col0": "1 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\"ONG\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_19.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e ONG\u003c/div\u003e\u003c/br\u003e",
              "col2": " \u003c/br\u003e",
              "col3": " \u003c/br\u003e",
              "col4": " \u003c/br\u003e",
              "col5": " \u003c/br\u003e"
            },
            {
              "col0": "2 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\"Administrador : Profesor_Ong\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_19.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e Administrador : Profesor_Ong\u003c/div\u003e\u003c/br\u003e",
              "col2": "\u003cdiv title\u003d\"Profesor_Ong\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_4_7c8024c_1606753403888_871350_5454\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_28.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_4_7c8024c_1606753403888_871350_5454\u0027);return false;\"\u003eProfesor_Ong\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col3": " \u003c/br\u003e",
              "col4": " \u003c/br\u003e",
              "col5": " \u003c/br\u003e"
            },
            {
              "col0": "3 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\"Curso : Curso\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_19.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e Curso : Curso\u003c/div\u003e\u003c/br\u003e",
              "col2": "\u003cdiv title\u003d\"Curso\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_4_7c8024c_1606753429820_880590_5480\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_28.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_4_7c8024c_1606753429820_880590_5480\u0027);return false;\"\u003eCurso\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col3": " \u003c/br\u003e",
              "col4": " \u003c/br\u003e",
              "col5": " \u003c/br\u003e"
            },
            {
              "col0": "4 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\"Procesos App\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_19.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e Procesos App\u003c/div\u003e\u003c/br\u003e",
              "col2": " \u003c/br\u003e",
              "col3": " \u003c/br\u003e",
              "col4": " \u003c/br\u003e",
              "col5": " \u003c/br\u003e"
            },
            {
              "col0": "5 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\"Administrador BD\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_19.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e Administrador BD\u003c/div\u003e\u003c/br\u003e",
              "col2": " \u003c/br\u003e",
              "col3": " \u003c/br\u003e",
              "col4": " \u003c/br\u003e",
              "col5": " \u003c/br\u003e"
            },
            {
              "col0": "6 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\"Institucion\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_19.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e Institucion\u003c/div\u003e\u003c/br\u003e",
              "col2": " \u003c/br\u003e",
              "col3": " \u003c/br\u003e",
              "col4": " \u003c/br\u003e",
              "col5": " \u003c/br\u003e"
            }
          ]
        },
        "columns": [
          {
            "text": "# ",
            "dataIndex": "col0",
            "flex": 0,
            "width": 84
          },
          {
            "text": "Name ",
            "dataIndex": "col1",
            "flex": 0,
            "width": 300
          },
          {
            "text": "Type ",
            "dataIndex": "col2",
            "flex": 0,
            "width": 300
          },
          {
            "text": "Multiplicity ",
            "dataIndex": "col3",
            "flex": 0,
            "width": 156
          },
          {
            "text": "Default value ",
            "dataIndex": "col4",
            "flex": 0,
            "width": 168
          },
          {
            "text": "Documentation ",
            "dataIndex": "col5",
            "flex": 1,
            "width": -1
          }
        ],
        "collapsible": true
      }
    ],
    "image_panel": [
      {
        "title": "Crud de ONG",
        "image": "diagrams/diagram_Architecture___19_0_4_7c8024c_1608378644666_801706_7939.png",
        "width": 2105,
        "height": 1315,
        "collapsible": true,
        "map": {}
      },
      {
        "title": "Crud de ONG_imported",
        "image": "diagrams/diagram_Architecture___19_0_4_7c8024c_1608397300078_709912_10347.png",
        "width": 2105,
        "height": 1391,
        "collapsible": true,
        "map": {}
      },
      {
        "title": "Crud de ONG_imported1",
        "image": "diagrams/diagram_Architecture___19_0_4_7c8024c_1608464478743_981878_12399.png",
        "width": 2105,
        "height": 1269,
        "collapsible": true,
        "map": {}
      }
    ]
  },
  "EmptyContent___19_0_4_7c8024c_1605544934734_89990_5051": {
    "title": "Crud de ONG",
    "path": "\u003cdiv title\u003d\"Casos de uso\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_3_59501f0_1605898693468_780946_4813\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_3_59501f0_1605898693468_780946_4813\u0027);return false;\"\u003eCasos de uso\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Subsistema Curso\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1606045080271_940524_6239\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1606045080271_940524_6239\u0027);return false;\"\u003eSubsistema Curso\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Crud de ONG\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1605544934734_89990_5051\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_6.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1605544934734_89990_5051\u0027);return false;\"\u003eCrud de ONG\u003ca\u003e\u003c/div\u003e",
    "html_panel": [],
    "grid_panel": [],
    "image_panel": []
  },
  "Architecture___19_0_4_7c8024c_1608227601648_553345_5484": {
    "title": "CtrCurso",
    "path": "\u003cdiv title\u003d\"Estructura\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1606752452637_33243_5229\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1606752452637_33243_5229\u0027);return false;\"\u003eEstructura\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Control\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1608218571669_136949_5237\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1608218571669_136949_5237\u0027);return false;\"\u003eControl\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"CtrCurso\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_4_7c8024c_1608227601648_553345_5484\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_29.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_4_7c8024c_1608227601648_553345_5484\u0027);return false;\"\u003eCtrCurso\u003ca\u003e\u003c/div\u003e",
    "html_panel": [],
    "grid_panel": [
      {
        "title": "Characteristics ",
        "hideHeaders": true,
        "data_store": {
          "fields": [
            "col0",
            "col1"
          ],
          "data": [
            {
              "col0": "Name ",
              "col1": "\u003cdiv title\u003d\"CtrCurso\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_4_7c8024c_1608227601648_553345_5484\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_29.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_4_7c8024c_1608227601648_553345_5484\u0027);return false;\"\u003eCtrCurso\u003ca\u003e\u003c/div\u003e"
            }
          ]
        },
        "columns": [
          {
            "text": "col0",
            "dataIndex": "col0",
            "flex": 0,
            "width": 192
          },
          {
            "text": "col1",
            "dataIndex": "col1",
            "flex": 1,
            "width": -1
          }
        ],
        "collapsible": true
      },
      {
        "title": "Operations",
        "hideHeaders": false,
        "data_store": {
          "fields": [
            "col0",
            "col1",
            "col2",
            "col3",
            "col4"
          ],
          "data": [
            {
              "col0": "1 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\"AñadirActividad\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_24.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e AñadirActividad\u003c/div\u003e\u003c/br\u003e",
              "col2": " \u003c/br\u003e",
              "col3": "",
              "col4": " \u003c/br\u003e"
            },
            {
              "col0": "2 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\"invitaJoinCurso\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_24.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e invitaJoinCurso\u003c/div\u003e\u003c/br\u003e",
              "col2": " \u003c/br\u003e",
              "col3": "\u003cdiv title\u003d\"unnamed1\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_30.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e unnamed1\u003c/div\u003e\u003c/br\u003e \u003c/br\u003e",
              "col4": " \u003c/br\u003e"
            },
            {
              "col0": "3 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\"invitaJoinCurso\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_24.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e invitaJoinCurso\u003c/div\u003e\u003c/br\u003e",
              "col2": " \u003c/br\u003e",
              "col3": "\u003cdiv title\u003d\"\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_30.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e \u003c/div\u003e\u003c/br\u003e \u003c/br\u003e",
              "col4": " \u003c/br\u003e"
            },
            {
              "col0": "4 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\"getTareasCurso\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_24.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e getTareasCurso\u003c/div\u003e\u003c/br\u003e",
              "col2": " \u003c/br\u003e",
              "col3": "\u003cdiv title\u003d\"CursoId\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_30.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e CursoId\u003c/div\u003e\u003c/br\u003e \u003c/br\u003e",
              "col4": " \u003c/br\u003e"
            },
            {
              "col0": "5 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\"unnamed1\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_24.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e unnamed1\u003c/div\u003e\u003c/br\u003e",
              "col2": " \u003c/br\u003e",
              "col3": "",
              "col4": " \u003c/br\u003e"
            },
            {
              "col0": "6 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\"invitaJoinCurso_imported1\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_24.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e invitaJoinCurso_imported1\u003c/div\u003e\u003c/br\u003e",
              "col2": " \u003c/br\u003e",
              "col3": "",
              "col4": " \u003c/br\u003e"
            },
            {
              "col0": "7 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\"invitaJoinCurso_imported\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_24.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e invitaJoinCurso_imported\u003c/div\u003e\u003c/br\u003e",
              "col2": " \u003c/br\u003e",
              "col3": "",
              "col4": " \u003c/br\u003e"
            },
            {
              "col0": "8 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\"salirCurso\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_24.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e salirCurso\u003c/div\u003e\u003c/br\u003e",
              "col2": " \u003c/br\u003e",
              "col3": "\u003cdiv title\u003d\"CursoId\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_30.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e CursoId\u003c/div\u003e\u003c/br\u003e \u003c/br\u003e",
              "col4": " \u003c/br\u003e"
            },
            {
              "col0": "9 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\"SeleccionarCurso\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_24.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e SeleccionarCurso\u003c/div\u003e\u003c/br\u003e",
              "col2": " \u003c/br\u003e",
              "col3": "\u003cdiv title\u003d\"CursoId\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_30.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e CursoId\u003c/div\u003e\u003c/br\u003e \u003c/br\u003e",
              "col4": " \u003c/br\u003e"
            },
            {
              "col0": "10 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\"getCursosUsuario\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_24.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e getCursosUsuario\u003c/div\u003e\u003c/br\u003e",
              "col2": " \u003c/br\u003e",
              "col3": "\u003cdiv title\u003d\"email\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_30.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e email\u003c/div\u003e\u003c/br\u003e \u003c/br\u003e",
              "col4": " \u003c/br\u003e"
            },
            {
              "col0": "11 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\"cursosEnLosqueEsteElUsuario\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_24.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e cursosEnLosqueEsteElUsuario\u003c/div\u003e\u003c/br\u003e",
              "col2": " \u003c/br\u003e",
              "col3": "\u003cdiv title\u003d\"email\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_30.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e email\u003c/div\u003e\u003c/br\u003e \u003c/br\u003e",
              "col4": " \u003c/br\u003e"
            },
            {
              "col0": "12 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\"agrandarCalendario\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_24.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e agrandarCalendario\u003c/div\u003e\u003c/br\u003e",
              "col2": " \u003c/br\u003e",
              "col3": "",
              "col4": " \u003c/br\u003e"
            },
            {
              "col0": "13 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\"abrirTarea\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_24.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e abrirTarea\u003c/div\u003e\u003c/br\u003e",
              "col2": " \u003c/br\u003e",
              "col3": "\u003cdiv title\u003d\"tareaID\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_30.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e tareaID\u003c/div\u003e\u003c/br\u003e \u003c/br\u003e",
              "col4": " \u003c/br\u003e"
            }
          ]
        },
        "columns": [
          {
            "text": "# ",
            "dataIndex": "col0",
            "flex": 0,
            "width": 96
          },
          {
            "text": "Name ",
            "dataIndex": "col1",
            "flex": 0,
            "width": 300
          },
          {
            "text": "Type ",
            "dataIndex": "col2",
            "flex": 0,
            "width": 72
          },
          {
            "text": "Parameters ",
            "dataIndex": "col3",
            "flex": 0,
            "width": 300
          },
          {
            "text": "Documentation ",
            "dataIndex": "col4",
            "flex": 1,
            "width": -1
          }
        ],
        "collapsible": true
      }
    ],
    "image_panel": []
  },
  "Architecture___19_0_4_7c8024c_1608227611466_747776_5510": {
    "title": "CtrForo",
    "path": "\u003cdiv title\u003d\"Estructura\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1606752452637_33243_5229\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1606752452637_33243_5229\u0027);return false;\"\u003eEstructura\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Control\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1608218571669_136949_5237\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1608218571669_136949_5237\u0027);return false;\"\u003eControl\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"CtrForo\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_4_7c8024c_1608227611466_747776_5510\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_29.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_4_7c8024c_1608227611466_747776_5510\u0027);return false;\"\u003eCtrForo\u003ca\u003e\u003c/div\u003e",
    "html_panel": [],
    "grid_panel": [
      {
        "title": "Characteristics ",
        "hideHeaders": true,
        "data_store": {
          "fields": [
            "col0",
            "col1"
          ],
          "data": [
            {
              "col0": "Name ",
              "col1": "\u003cdiv title\u003d\"CtrForo\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_4_7c8024c_1608227611466_747776_5510\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_29.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_4_7c8024c_1608227611466_747776_5510\u0027);return false;\"\u003eCtrForo\u003ca\u003e\u003c/div\u003e"
            }
          ]
        },
        "columns": [
          {
            "text": "col0",
            "dataIndex": "col0",
            "flex": 0,
            "width": 192
          },
          {
            "text": "col1",
            "dataIndex": "col1",
            "flex": 1,
            "width": -1
          }
        ],
        "collapsible": true
      },
      {
        "title": "Operations",
        "hideHeaders": false,
        "data_store": {
          "fields": [
            "col0",
            "col1",
            "col2",
            "col3",
            "col4"
          ],
          "data": [
            {
              "col0": "1 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\"unnamed1\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_24.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e unnamed1\u003c/div\u003e\u003c/br\u003e",
              "col2": " \u003c/br\u003e",
              "col3": "",
              "col4": " \u003c/br\u003e"
            }
          ]
        },
        "columns": [
          {
            "text": "# ",
            "dataIndex": "col0",
            "flex": 0,
            "width": 84
          },
          {
            "text": "Name ",
            "dataIndex": "col1",
            "flex": 0,
            "width": 300
          },
          {
            "text": "Type ",
            "dataIndex": "col2",
            "flex": 0,
            "width": 72
          },
          {
            "text": "Parameters ",
            "dataIndex": "col3",
            "flex": 0,
            "width": 132
          },
          {
            "text": "Documentation ",
            "dataIndex": "col4",
            "flex": 1,
            "width": -1
          }
        ],
        "collapsible": true
      }
    ],
    "image_panel": []
  },
  "Architecture___19_0_4_7c8024c_1608227664966_121960_5640": {
    "title": "CtrTarea",
    "path": "\u003cdiv title\u003d\"Estructura\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1606752452637_33243_5229\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1606752452637_33243_5229\u0027);return false;\"\u003eEstructura\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Control\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1608218571669_136949_5237\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1608218571669_136949_5237\u0027);return false;\"\u003eControl\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"CtrTarea\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_4_7c8024c_1608227664966_121960_5640\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_29.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_4_7c8024c_1608227664966_121960_5640\u0027);return false;\"\u003eCtrTarea\u003ca\u003e\u003c/div\u003e",
    "html_panel": [],
    "grid_panel": [
      {
        "title": "Characteristics ",
        "hideHeaders": true,
        "data_store": {
          "fields": [
            "col0",
            "col1"
          ],
          "data": [
            {
              "col0": "Name ",
              "col1": "\u003cdiv title\u003d\"CtrTarea\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_4_7c8024c_1608227664966_121960_5640\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_29.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_4_7c8024c_1608227664966_121960_5640\u0027);return false;\"\u003eCtrTarea\u003ca\u003e\u003c/div\u003e"
            }
          ]
        },
        "columns": [
          {
            "text": "col0",
            "dataIndex": "col0",
            "flex": 0,
            "width": 192
          },
          {
            "text": "col1",
            "dataIndex": "col1",
            "flex": 1,
            "width": -1
          }
        ],
        "collapsible": true
      },
      {
        "title": "Operations",
        "hideHeaders": false,
        "data_store": {
          "fields": [
            "col0",
            "col1",
            "col2",
            "col3",
            "col4"
          ],
          "data": [
            {
              "col0": "1 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\"SubirTarea\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_24.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e SubirTarea\u003c/div\u003e\u003c/br\u003e",
              "col2": " \u003c/br\u003e",
              "col3": "\u003cdiv title\u003d\"Archivo\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_30.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e Archivo\u003c/div\u003e\u003c/br\u003e \u003c/br\u003e",
              "col4": " \u003c/br\u003e"
            },
            {
              "col0": "2 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\"unnamed1\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_24.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e unnamed1\u003c/div\u003e\u003c/br\u003e",
              "col2": " \u003c/br\u003e",
              "col3": "",
              "col4": " \u003c/br\u003e"
            },
            {
              "col0": "3 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\"MostrarTarea\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_24.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e MostrarTarea\u003c/div\u003e\u003c/br\u003e",
              "col2": " \u003c/br\u003e",
              "col3": "",
              "col4": " \u003c/br\u003e"
            },
            {
              "col0": "4 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\"abrirTarea\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_24.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e abrirTarea\u003c/div\u003e\u003c/br\u003e",
              "col2": " \u003c/br\u003e",
              "col3": "\u003cdiv title\u003d\"TareaID\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_30.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e TareaID\u003c/div\u003e\u003c/br\u003e \u003c/br\u003e",
              "col4": " \u003c/br\u003e"
            },
            {
              "col0": "5 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\"editarCalificacion\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_24.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e editarCalificacion\u003c/div\u003e\u003c/br\u003e",
              "col2": " \u003c/br\u003e",
              "col3": "",
              "col4": " \u003c/br\u003e"
            },
            {
              "col0": "6 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\"editarCalificacion\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_24.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e editarCalificacion\u003c/div\u003e\u003c/br\u003e",
              "col2": " \u003c/br\u003e",
              "col3": "\u003cdiv title\u003d\"TareaID\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_30.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e TareaID\u003c/div\u003e\u003c/br\u003e \u003c/br\u003e\u003cdiv title\u003d\"email\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_30.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e email\u003c/div\u003e\u003c/br\u003e \u003c/br\u003e",
              "col4": " \u003c/br\u003e"
            },
            {
              "col0": "7 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\"editarCalificacion\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_24.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e editarCalificacion\u003c/div\u003e\u003c/br\u003e",
              "col2": " \u003c/br\u003e",
              "col3": "\u003cdiv title\u003d\"calificacion\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_30.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e calificacion\u003c/div\u003e\u003c/br\u003e \u003c/br\u003e",
              "col4": " \u003c/br\u003e"
            },
            {
              "col0": "8 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\"comprobarValor\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_24.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e comprobarValor\u003c/div\u003e\u003c/br\u003e",
              "col2": " \u003c/br\u003e",
              "col3": "\u003cdiv title\u003d\"calificacion\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_30.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e calificacion\u003c/div\u003e\u003c/br\u003e \u003c/br\u003e",
              "col4": " \u003c/br\u003e"
            }
          ]
        },
        "columns": [
          {
            "text": "# ",
            "dataIndex": "col0",
            "flex": 0,
            "width": 84
          },
          {
            "text": "Name ",
            "dataIndex": "col1",
            "flex": 0,
            "width": 300
          },
          {
            "text": "Type ",
            "dataIndex": "col2",
            "flex": 0,
            "width": 72
          },
          {
            "text": "Parameters ",
            "dataIndex": "col3",
            "flex": 0,
            "width": 300
          },
          {
            "text": "Documentation ",
            "dataIndex": "col4",
            "flex": 1,
            "width": -1
          }
        ],
        "collapsible": true
      }
    ],
    "image_panel": []
  },
  "Glossary___19_0_4_65b021b_1608502518889_106459_7435": {
    "title": "Curso",
    "path": "\u003cdiv title\u003d\"Documentacion del Proyecto Entrega 2\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1608491267549_161671_7569\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1608491267549_161671_7569\u0027);return false;\"\u003eDocumentacion del Proyecto Entrega 2\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"2. Glosario\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_65b021b_1608502989614_109664_7440\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_65b021b_1608502989614_109664_7440\u0027);return false;\"\u003e2. Glosario\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Curso\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Glossary___19_0_4_65b021b_1608502518889_106459_7435\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_31.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Glossary___19_0_4_65b021b_1608502518889_106459_7435\u0027);return false;\"\u003eCurso\u003ca\u003e\u003c/div\u003e",
    "html_panel": [],
    "grid_panel": [
      {
        "title": "Characteristics ",
        "hideHeaders": true,
        "data_store": {
          "fields": [
            "col0",
            "col1"
          ],
          "data": [
            {
              "col0": "Term ",
              "col1": "\u003cdiv title\u003d\"Curso\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Glossary___19_0_4_65b021b_1608502518889_106459_7435\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_31.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Glossary___19_0_4_65b021b_1608502518889_106459_7435\u0027);return false;\"\u003eCurso\u003ca\u003e\u003c/div\u003e"
            },
            {
              "col0": "Description ",
              "col1": "Estos estan formados por un grupo de alumnos y gestionados por unos o varios profesores o una ONG. Estos incluyen tareas, actividades, seminarios online, videos, etc. "
            }
          ]
        },
        "columns": [
          {
            "text": "col0",
            "dataIndex": "col0",
            "flex": 0,
            "width": 192
          },
          {
            "text": "col1",
            "dataIndex": "col1",
            "flex": 1,
            "width": -1
          }
        ],
        "collapsible": false
      }
    ],
    "image_panel": []
  },
  "Requirement___19_0_3_59501f0_1605901657237_602297_5524": {
    "title": "Descargar Archivos",
    "path": "\u003cdiv title\u003d\"Casos de uso\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_3_59501f0_1605898693468_780946_4813\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_3_59501f0_1605898693468_780946_4813\u0027);return false;\"\u003eCasos de uso\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Subsistema Actividades\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1605993744465_299768_6146\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1605993744465_299768_6146\u0027);return false;\"\u003eSubsistema Actividades\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Descargar Archivos\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_3_59501f0_1605901657237_602297_5524\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_6.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_3_59501f0_1605901657237_602297_5524\u0027);return false;\"\u003eDescargar Archivos\u003ca\u003e\u003c/div\u003e",
    "html_panel": [],
    "grid_panel": [
      {
        "title": "Characteristics ",
        "hideHeaders": true,
        "data_store": {
          "fields": [
            "col0",
            "col1"
          ],
          "data": [
            {
              "col0": "Name ",
              "col1": "\u003cdiv title\u003d\"Descargar Archivos\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_3_59501f0_1605901657237_602297_5524\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_6.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_3_59501f0_1605901657237_602297_5524\u0027);return false;\"\u003eDescargar Archivos\u003ca\u003e\u003c/div\u003e"
            }
          ]
        },
        "columns": [
          {
            "text": "col0",
            "dataIndex": "col0",
            "flex": 0,
            "width": 192
          },
          {
            "text": "col1",
            "dataIndex": "col1",
            "flex": 1,
            "width": -1
          }
        ],
        "collapsible": true
      },
      {
        "title": "Actors",
        "hideHeaders": false,
        "data_store": {
          "fields": [
            "col0",
            "col1",
            "col2"
          ],
          "data": [
            {
              "col0": "1 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\"Administrador\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1606046179164_726532_6549\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_5.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1606046179164_726532_6549\u0027);return false;\"\u003eAdministrador\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col2": " \u003c/br\u003e"
            },
            {
              "col0": "2 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\"Organizacion\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1605993976012_561063_6365\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_5.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1605993976012_561063_6365\u0027);return false;\"\u003eOrganizacion\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col2": " \u003c/br\u003e"
            },
            {
              "col0": "3 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\"instructor\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1608378644060_454646_6215\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_5.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1608378644060_454646_6215\u0027);return false;\"\u003einstructor\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col2": " \u003c/br\u003e"
            },
            {
              "col0": "4 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\"Alumno\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1605993976012_184874_6364\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_5.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1605993976012_184874_6364\u0027);return false;\"\u003eAlumno\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col2": " \u003c/br\u003e"
            },
            {
              "col0": "5 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\"Instructor\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1605993976013_127053_6366\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_5.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1605993976013_127053_6366\u0027);return false;\"\u003eInstructor\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col2": " \u003c/br\u003e"
            },
            {
              "col0": "6 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\"UMA\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1605992040306_840570_5282\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_5.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1605992040306_840570_5282\u0027);return false;\"\u003eUMA\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col2": " \u003c/br\u003e"
            }
          ]
        },
        "columns": [
          {
            "text": "# ",
            "dataIndex": "col0",
            "flex": 0,
            "width": 84
          },
          {
            "text": "Name ",
            "dataIndex": "col1",
            "flex": 0,
            "width": 300
          },
          {
            "text": "Documentation ",
            "dataIndex": "col2",
            "flex": 1,
            "width": -1
          }
        ],
        "collapsible": true
      },
      {
        "title": "Owned Behaviors",
        "hideHeaders": false,
        "data_store": {
          "fields": [
            "col0",
            "col1",
            "col2"
          ],
          "data": [
            {
              "col0": "1 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\"Descargar Archivos\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_3_59501f0_1605901673435_41536_5538\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_17.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_3_59501f0_1605901673435_41536_5538\u0027);return false;\"\u003eDescargar Archivos\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col2": " \u003c/br\u003e"
            },
            {
              "col0": "2 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\"Sec. Descargar archivos\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_5b201fd_1608470096739_711923_8786\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_7.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_5b201fd_1608470096739_711923_8786\u0027);return false;\"\u003eSec. Descargar archivos\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col2": " \u003c/br\u003e"
            },
            {
              "col0": "3 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\"Sec. Descargar archivos alternativo\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_5b201fd_1608471450987_559529_9094\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_7.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_5b201fd_1608471450987_559529_9094\u0027);return false;\"\u003eSec. Descargar archivos alternativo\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col2": " \u003c/br\u003e"
            }
          ]
        },
        "columns": [
          {
            "text": "# ",
            "dataIndex": "col0",
            "flex": 0,
            "width": 84
          },
          {
            "text": "Name ",
            "dataIndex": "col1",
            "flex": 0,
            "width": 300
          },
          {
            "text": "Documentation ",
            "dataIndex": "col2",
            "flex": 1,
            "width": -1
          }
        ],
        "collapsible": true
      },
      {
        "title": "Scenario - Basic Flow ",
        "hideHeaders": true,
        "data_store": {
          "fields": [
            "col0"
          ],
          "data": [
            {
              "col0": "1. El usuario busca el archivo que desea descargar y solicita descargarlo "
            },
            {
              "col0": "2. El sistema comprueba que los permisos sean correctos y que el archivo esté disponible "
            },
            {
              "col0": "3. El sistema muestra una ventana para comenzar la descarga "
            }
          ]
        },
        "columns": [
          {
            "text": "col0",
            "dataIndex": "col0",
            "flex": 1,
            "width": -1
          }
        ],
        "collapsible": true
      }
    ],
    "image_panel": []
  },
  "EmptyContent___19_0_3_59501f0_1605901657237_602297_5524": {
    "title": "Descargar Archivos",
    "path": "\u003cdiv title\u003d\"Casos de uso\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_3_59501f0_1605898693468_780946_4813\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_3_59501f0_1605898693468_780946_4813\u0027);return false;\"\u003eCasos de uso\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Subsistema Actividades\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1605993744465_299768_6146\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1605993744465_299768_6146\u0027);return false;\"\u003eSubsistema Actividades\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Descargar Archivos\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_3_59501f0_1605901657237_602297_5524\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_6.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_3_59501f0_1605901657237_602297_5524\u0027);return false;\"\u003eDescargar Archivos\u003ca\u003e\u003c/div\u003e",
    "html_panel": [],
    "grid_panel": [],
    "image_panel": []
  },
  "EmptyContent___19_0_3_59501f0_1605901673435_41536_5538": {
    "title": "Descargar Archivos",
    "path": "\u003cdiv title\u003d\"Casos de uso\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_3_59501f0_1605898693468_780946_4813\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_3_59501f0_1605898693468_780946_4813\u0027);return false;\"\u003eCasos de uso\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Subsistema Actividades\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1605993744465_299768_6146\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1605993744465_299768_6146\u0027);return false;\"\u003eSubsistema Actividades\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Descargar Archivos\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_3_59501f0_1605901657237_602297_5524\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_6.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_3_59501f0_1605901657237_602297_5524\u0027);return false;\"\u003eDescargar Archivos\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Descargar Archivos\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_3_59501f0_1605901673435_41536_5538\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_17.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_3_59501f0_1605901673435_41536_5538\u0027);return false;\"\u003eDescargar Archivos\u003ca\u003e\u003c/div\u003e",
    "html_panel": [],
    "grid_panel": [],
    "image_panel": []
  },
  "Diagrams___19_0_4_7c8024c_1608378644436_339003_7256": {
    "title": "Descargar Archivos_imported",
    "path": "\u003cdiv title\u003d\"Casos de uso\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_3_59501f0_1605898693468_780946_4813\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_3_59501f0_1605898693468_780946_4813\u0027);return false;\"\u003eCasos de uso\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Subsistema Actividades\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1605993744465_299768_6146\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1605993744465_299768_6146\u0027);return false;\"\u003eSubsistema Actividades\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Descargar Archivos\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_3_59501f0_1605901657237_602297_5524\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_6.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_3_59501f0_1605901657237_602297_5524\u0027);return false;\"\u003eDescargar Archivos\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Descargar Archivos\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_3_59501f0_1605901673435_41536_5538\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_17.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_3_59501f0_1605901673435_41536_5538\u0027);return false;\"\u003eDescargar Archivos\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Descargar Archivos_imported\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Diagrams___19_0_4_7c8024c_1608378644436_339003_7256\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_16.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Diagrams___19_0_4_7c8024c_1608378644436_339003_7256\u0027);return false;\"\u003eDescargar Archivos_imported\u003ca\u003e\u003c/div\u003e",
    "html_panel": [],
    "grid_panel": [],
    "image_panel": [
      {
        "title": "",
        "image": "diagrams/diagram_Diagrams___19_0_4_7c8024c_1608378644447_832334_7276.png",
        "width": 410,
        "height": 1009,
        "collapsible": false,
        "map": {}
      }
    ]
  },
  "Diagrams___19_0_4_7c8024c_1608397299659_722793_8955": {
    "title": "Descargar Archivos_imported_imported",
    "path": "\u003cdiv title\u003d\"Casos de uso\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_3_59501f0_1605898693468_780946_4813\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_3_59501f0_1605898693468_780946_4813\u0027);return false;\"\u003eCasos de uso\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Subsistema Actividades\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1605993744465_299768_6146\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1605993744465_299768_6146\u0027);return false;\"\u003eSubsistema Actividades\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Descargar Archivos\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_3_59501f0_1605901657237_602297_5524\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_6.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_3_59501f0_1605901657237_602297_5524\u0027);return false;\"\u003eDescargar Archivos\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Descargar Archivos\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_3_59501f0_1605901673435_41536_5538\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_17.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_3_59501f0_1605901673435_41536_5538\u0027);return false;\"\u003eDescargar Archivos\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Descargar Archivos_imported_imported\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Diagrams___19_0_4_7c8024c_1608397299659_722793_8955\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_16.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Diagrams___19_0_4_7c8024c_1608397299659_722793_8955\u0027);return false;\"\u003eDescargar Archivos_imported_imported\u003ca\u003e\u003c/div\u003e",
    "html_panel": [],
    "grid_panel": [],
    "image_panel": [
      {
        "title": "",
        "image": "diagrams/diagram_Diagrams___19_0_4_7c8024c_1608397299667_943734_8975.png",
        "width": 457,
        "height": 1009,
        "collapsible": false,
        "map": {}
      }
    ]
  },
  "Package___19_0_4_7c8024c_1605542700510_677406_4795": {
    "title": "Documentacion del Proyecto Entrega 1",
    "path": "\u003cdiv title\u003d\"Documentacion del Proyecto Entrega 1\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1605542700510_677406_4795\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1605542700510_677406_4795\u0027);return false;\"\u003eDocumentacion del Proyecto Entrega 1\u003ca\u003e\u003c/div\u003e",
    "html_panel": [],
    "grid_panel": [],
    "image_panel": []
  },
  "Package___19_0_4_7c8024c_1608491267549_161671_7569": {
    "title": "Documentacion del Proyecto Entrega 2",
    "path": "\u003cdiv title\u003d\"Documentacion del Proyecto Entrega 2\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1608491267549_161671_7569\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1608491267549_161671_7569\u0027);return false;\"\u003eDocumentacion del Proyecto Entrega 2\u003ca\u003e\u003c/div\u003e",
    "html_panel": [],
    "grid_panel": [],
    "image_panel": []
  },
  "EmptyContent___19_0_4_7c8024c_1605983074405_93964_7342": {
    "title": "Entregar Actividad",
    "path": "\u003cdiv title\u003d\"Casos de uso\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_3_59501f0_1605898693468_780946_4813\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_3_59501f0_1605898693468_780946_4813\u0027);return false;\"\u003eCasos de uso\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Subsistema Actividades\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1605993744465_299768_6146\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1605993744465_299768_6146\u0027);return false;\"\u003eSubsistema Actividades\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Subir Documento\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1605979033648_450401_5796\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_6.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1605979033648_450401_5796\u0027);return false;\"\u003eSubir Documento\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Entregar Actividad\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1605983074405_93964_7342\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_17.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1605983074405_93964_7342\u0027);return false;\"\u003eEntregar Actividad\u003ca\u003e\u003c/div\u003e",
    "html_panel": [],
    "grid_panel": [],
    "image_panel": []
  },
  "Diagrams___19_0_4_7c8024c_1608378644466_1178_7326": {
    "title": "Entregar Actividad_imported",
    "path": "\u003cdiv title\u003d\"Casos de uso\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_3_59501f0_1605898693468_780946_4813\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_3_59501f0_1605898693468_780946_4813\u0027);return false;\"\u003eCasos de uso\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Subsistema Actividades\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1605993744465_299768_6146\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1605993744465_299768_6146\u0027);return false;\"\u003eSubsistema Actividades\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Subir Documento\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1605979033648_450401_5796\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_6.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1605979033648_450401_5796\u0027);return false;\"\u003eSubir Documento\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Entregar Actividad\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1605983074405_93964_7342\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_17.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1605983074405_93964_7342\u0027);return false;\"\u003eEntregar Actividad\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Entregar Actividad_imported\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Diagrams___19_0_4_7c8024c_1608378644466_1178_7326\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_16.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Diagrams___19_0_4_7c8024c_1608378644466_1178_7326\u0027);return false;\"\u003eEntregar Actividad_imported\u003ca\u003e\u003c/div\u003e",
    "html_panel": [],
    "grid_panel": [],
    "image_panel": [
      {
        "title": "",
        "image": "diagrams/diagram_Diagrams___19_0_4_7c8024c_1608378644473_723981_7346.png",
        "width": 392,
        "height": 792,
        "collapsible": false,
        "map": {}
      }
    ]
  },
  "EmptyContent___19_0_4_8cb0287_1606038280480_854501_5064": {
    "title": "Entregar Tarea",
    "path": "\u003cdiv title\u003d\"Casos de uso\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_3_59501f0_1605898693468_780946_4813\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_3_59501f0_1605898693468_780946_4813\u0027);return false;\"\u003eCasos de uso\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Subsistema Tareas\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1608419403729_110276_7054\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1608419403729_110276_7054\u0027);return false;\"\u003eSubsistema Tareas\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Entregar Tarea\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_8cb0287_1606038280480_854501_5064\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_6.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_8cb0287_1606038280480_854501_5064\u0027);return false;\"\u003eEntregar Tarea\u003ca\u003e\u003c/div\u003e",
    "html_panel": [],
    "grid_panel": [],
    "image_panel": []
  },
  "EmptyContent___19_0_4_7c8024c_1608399403657_841613_6685": {
    "title": "Entregar Tarea",
    "path": "\u003cdiv title\u003d\"Casos de uso\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_3_59501f0_1605898693468_780946_4813\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_3_59501f0_1605898693468_780946_4813\u0027);return false;\"\u003eCasos de uso\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Subsistema Tareas\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1608419403729_110276_7054\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1608419403729_110276_7054\u0027);return false;\"\u003eSubsistema Tareas\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Entregar Tarea\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_8cb0287_1606038280480_854501_5064\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_6.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_8cb0287_1606038280480_854501_5064\u0027);return false;\"\u003eEntregar Tarea\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Entregar Tarea\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1608399403657_841613_6685\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_17.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1608399403657_841613_6685\u0027);return false;\"\u003eEntregar Tarea\u003ca\u003e\u003c/div\u003e",
    "html_panel": [],
    "grid_panel": [],
    "image_panel": []
  },
  "Diagrams___19_0_4_7c8024c_1608399403661_45434_6686": {
    "title": "Entregar Tarea",
    "path": "\u003cdiv title\u003d\"Casos de uso\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_3_59501f0_1605898693468_780946_4813\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_3_59501f0_1605898693468_780946_4813\u0027);return false;\"\u003eCasos de uso\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Subsistema Tareas\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1608419403729_110276_7054\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1608419403729_110276_7054\u0027);return false;\"\u003eSubsistema Tareas\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Entregar Tarea\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_8cb0287_1606038280480_854501_5064\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_6.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_8cb0287_1606038280480_854501_5064\u0027);return false;\"\u003eEntregar Tarea\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Entregar Tarea\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1608399403657_841613_6685\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_17.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1608399403657_841613_6685\u0027);return false;\"\u003eEntregar Tarea\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Entregar Tarea\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Diagrams___19_0_4_7c8024c_1608399403661_45434_6686\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_16.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Diagrams___19_0_4_7c8024c_1608399403661_45434_6686\u0027);return false;\"\u003eEntregar Tarea\u003ca\u003e\u003c/div\u003e",
    "html_panel": [],
    "grid_panel": [],
    "image_panel": [
      {
        "title": "",
        "image": "diagrams/diagram_Diagrams___19_0_4_7c8024c_1608399403671_809831_6706.png",
        "width": 409,
        "height": 813,
        "collapsible": false,
        "map": {}
      }
    ]
  },
  "Diagrams___19_0_4_7c8024c_1608241970816_286440_8997": {
    "title": "Entregar tarea",
    "path": "\u003cdiv title\u003d\"Casos de uso\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_3_59501f0_1605898693468_780946_4813\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_3_59501f0_1605898693468_780946_4813\u0027);return false;\"\u003eCasos de uso\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Subsistema Tareas\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1608419403729_110276_7054\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1608419403729_110276_7054\u0027);return false;\"\u003eSubsistema Tareas\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Entregar Tarea\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_8cb0287_1606038280480_854501_5064\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_6.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_8cb0287_1606038280480_854501_5064\u0027);return false;\"\u003eEntregar Tarea\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Entregar tarea\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1608241970817_986305_8998\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_7.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1608241970817_986305_8998\u0027);return false;\"\u003eEntregar tarea\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Entregar tarea\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Diagrams___19_0_4_7c8024c_1608241970816_286440_8997\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_18.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Diagrams___19_0_4_7c8024c_1608241970816_286440_8997\u0027);return false;\"\u003eEntregar tarea\u003ca\u003e\u003c/div\u003e",
    "html_panel": [],
    "grid_panel": [],
    "image_panel": [
      {
        "title": "",
        "image": "diagrams/diagram_Diagrams___19_0_4_7c8024c_1608241970826_882785_9018.png",
        "width": 2233,
        "height": 2236,
        "collapsible": false,
        "map": {}
      }
    ]
  },
  "EmptyContent___19_0_4_7c8024c_1608241970817_986305_8998": {
    "title": "Entregar tarea",
    "path": "\u003cdiv title\u003d\"Casos de uso\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_3_59501f0_1605898693468_780946_4813\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_3_59501f0_1605898693468_780946_4813\u0027);return false;\"\u003eCasos de uso\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Subsistema Tareas\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1608419403729_110276_7054\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1608419403729_110276_7054\u0027);return false;\"\u003eSubsistema Tareas\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Entregar Tarea\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_8cb0287_1606038280480_854501_5064\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_6.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_8cb0287_1606038280480_854501_5064\u0027);return false;\"\u003eEntregar Tarea\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Entregar tarea\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1608241970817_986305_8998\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_7.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1608241970817_986305_8998\u0027);return false;\"\u003eEntregar tarea\u003ca\u003e\u003c/div\u003e",
    "html_panel": [],
    "grid_panel": [],
    "image_panel": []
  },
  "Architecture___19_0_3_59501f0_1608294205699_944159_8820": {
    "title": "Enviar correo interno",
    "path": "\u003cdiv title\u003d\"Casos de uso\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_3_59501f0_1605898693468_780946_4813\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_3_59501f0_1605898693468_780946_4813\u0027);return false;\"\u003eCasos de uso\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Subsistema Curso\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1606045080271_940524_6239\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1606045080271_940524_6239\u0027);return false;\"\u003eSubsistema Curso\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Mensajeria Interna\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_3_5c401fe_1605962882995_512132_5475\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_6.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_3_5c401fe_1605962882995_512132_5475\u0027);return false;\"\u003eMensajeria Interna\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Enviar correo interno\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_3_59501f0_1608294205699_944159_8820\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_7.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_3_59501f0_1608294205699_944159_8820\u0027);return false;\"\u003eEnviar correo interno\u003ca\u003e\u003c/div\u003e",
    "html_panel": [],
    "grid_panel": [
      {
        "title": "Characteristics ",
        "hideHeaders": true,
        "data_store": {
          "fields": [
            "col0",
            "col1"
          ],
          "data": [
            {
              "col0": "Name ",
              "col1": "\u003cdiv title\u003d\"Enviar correo interno\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_3_59501f0_1608294205699_944159_8820\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_7.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_3_59501f0_1608294205699_944159_8820\u0027);return false;\"\u003eEnviar correo interno\u003ca\u003e\u003c/div\u003e"
            }
          ]
        },
        "columns": [
          {
            "text": "col0",
            "dataIndex": "col0",
            "flex": 0,
            "width": 192
          },
          {
            "text": "col1",
            "dataIndex": "col1",
            "flex": 1,
            "width": -1
          }
        ],
        "collapsible": true
      },
      {
        "title": "Attributes",
        "hideHeaders": false,
        "data_store": {
          "fields": [
            "col0",
            "col1",
            "col2",
            "col3",
            "col4",
            "col5"
          ],
          "data": [
            {
              "col0": "1 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\": Alumno\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_19.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e : Alumno\u003c/div\u003e\u003c/br\u003e",
              "col2": "\u003cdiv title\u003d\"Alumno\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1605993976012_184874_6364\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_5.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1605993976012_184874_6364\u0027);return false;\"\u003eAlumno\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col3": " \u003c/br\u003e",
              "col4": " \u003c/br\u003e",
              "col5": " \u003c/br\u003e"
            },
            {
              "col0": "2 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\": ViewBaseDeDatos\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_19.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e : ViewBaseDeDatos\u003c/div\u003e\u003c/br\u003e",
              "col2": "\u003cdiv title\u003d\"ViewBaseDeDatos\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_4_7c8024c_1608227786905_953485_5708\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_32.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_4_7c8024c_1608227786905_953485_5708\u0027);return false;\"\u003eViewBaseDeDatos\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col3": " \u003c/br\u003e",
              "col4": " \u003c/br\u003e",
              "col5": " \u003c/br\u003e"
            },
            {
              "col0": "3 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\": CtrPrincipal\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_19.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e : CtrPrincipal\u003c/div\u003e\u003c/br\u003e",
              "col2": "\u003cdiv title\u003d\"CtrPrincipal\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_3_59501f0_1608294284249_809723_8879\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_29.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_3_59501f0_1608294284249_809723_8879\u0027);return false;\"\u003eCtrPrincipal\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col3": " \u003c/br\u003e",
              "col4": " \u003c/br\u003e",
              "col5": " \u003c/br\u003e"
            },
            {
              "col0": "4 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\": viewMensaje\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_19.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e : viewMensaje\u003c/div\u003e\u003c/br\u003e",
              "col2": "\u003cdiv title\u003d\"viewMensaje\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_3_59501f0_1608294420136_269451_9002\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_32.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_3_59501f0_1608294420136_269451_9002\u0027);return false;\"\u003eviewMensaje\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col3": " \u003c/br\u003e",
              "col4": " \u003c/br\u003e",
              "col5": " \u003c/br\u003e"
            },
            {
              "col0": "5 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\": CtrMensaje\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_19.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e : CtrMensaje\u003c/div\u003e\u003c/br\u003e",
              "col2": "\u003cdiv title\u003d\"CtrMensaje\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_4_7c8024c_1608227626997_320282_5562\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_29.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_4_7c8024c_1608227626997_320282_5562\u0027);return false;\"\u003eCtrMensaje\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col3": " \u003c/br\u003e",
              "col4": " \u003c/br\u003e",
              "col5": " \u003c/br\u003e"
            },
            {
              "col0": "6 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\": Alumno\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_19.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e : Alumno\u003c/div\u003e\u003c/br\u003e",
              "col2": "\u003cdiv title\u003d\"Alumno\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1605993976012_184874_6364\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_5.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1605993976012_184874_6364\u0027);return false;\"\u003eAlumno\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col3": " \u003c/br\u003e",
              "col4": " \u003c/br\u003e",
              "col5": " \u003c/br\u003e"
            },
            {
              "col0": "7 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\": ViewBaseDeDatos\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_19.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e : ViewBaseDeDatos\u003c/div\u003e\u003c/br\u003e",
              "col2": "\u003cdiv title\u003d\"ViewBaseDeDatos\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_4_7c8024c_1608227786905_953485_5708\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_32.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_4_7c8024c_1608227786905_953485_5708\u0027);return false;\"\u003eViewBaseDeDatos\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col3": " \u003c/br\u003e",
              "col4": " \u003c/br\u003e",
              "col5": " \u003c/br\u003e"
            },
            {
              "col0": "8 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\": CtrPrincipal\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_19.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e : CtrPrincipal\u003c/div\u003e\u003c/br\u003e",
              "col2": "\u003cdiv title\u003d\"CtrPrincipal\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_3_59501f0_1608294284249_809723_8879\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_29.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_3_59501f0_1608294284249_809723_8879\u0027);return false;\"\u003eCtrPrincipal\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col3": " \u003c/br\u003e",
              "col4": " \u003c/br\u003e",
              "col5": " \u003c/br\u003e"
            },
            {
              "col0": "9 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\": viewMensaje\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_19.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e : viewMensaje\u003c/div\u003e\u003c/br\u003e",
              "col2": "\u003cdiv title\u003d\"viewMensaje\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_3_59501f0_1608294420136_269451_9002\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_32.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_3_59501f0_1608294420136_269451_9002\u0027);return false;\"\u003eviewMensaje\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col3": " \u003c/br\u003e",
              "col4": " \u003c/br\u003e",
              "col5": " \u003c/br\u003e"
            },
            {
              "col0": "10 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\": CtrMensaje\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_19.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e : CtrMensaje\u003c/div\u003e\u003c/br\u003e",
              "col2": "\u003cdiv title\u003d\"CtrMensaje\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_4_7c8024c_1608227626997_320282_5562\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_29.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_4_7c8024c_1608227626997_320282_5562\u0027);return false;\"\u003eCtrMensaje\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col3": " \u003c/br\u003e",
              "col4": " \u003c/br\u003e",
              "col5": " \u003c/br\u003e"
            },
            {
              "col0": "11 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\": Alumno\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_19.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e : Alumno\u003c/div\u003e\u003c/br\u003e",
              "col2": "\u003cdiv title\u003d\"Alumno\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1605993976012_184874_6364\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_5.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1605993976012_184874_6364\u0027);return false;\"\u003eAlumno\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col3": " \u003c/br\u003e",
              "col4": " \u003c/br\u003e",
              "col5": " \u003c/br\u003e"
            },
            {
              "col0": "12 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\": ViewPrincipal\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_19.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e : ViewPrincipal\u003c/div\u003e\u003c/br\u003e",
              "col2": "\u003cdiv title\u003d\"ViewPrincipal\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_4_7c8024c_1608464477466_272921_8710\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_32.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_4_7c8024c_1608464477466_272921_8710\u0027);return false;\"\u003eViewPrincipal\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col3": " \u003c/br\u003e",
              "col4": " \u003c/br\u003e",
              "col5": " \u003c/br\u003e"
            },
            {
              "col0": "13 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\": CtrPrincipal\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_19.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e : CtrPrincipal\u003c/div\u003e\u003c/br\u003e",
              "col2": "\u003cdiv title\u003d\"CtrPrincipal\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_3_59501f0_1608294284249_809723_8879\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_29.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_3_59501f0_1608294284249_809723_8879\u0027);return false;\"\u003eCtrPrincipal\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col3": " \u003c/br\u003e",
              "col4": " \u003c/br\u003e",
              "col5": " \u003c/br\u003e"
            },
            {
              "col0": "14 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\": viewMensaje\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_19.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e : viewMensaje\u003c/div\u003e\u003c/br\u003e",
              "col2": "\u003cdiv title\u003d\"viewMensaje\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_3_59501f0_1608294420136_269451_9002\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_32.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_3_59501f0_1608294420136_269451_9002\u0027);return false;\"\u003eviewMensaje\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col3": " \u003c/br\u003e",
              "col4": " \u003c/br\u003e",
              "col5": " \u003c/br\u003e"
            },
            {
              "col0": "15 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\": CtrMensaje\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_19.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e : CtrMensaje\u003c/div\u003e\u003c/br\u003e",
              "col2": "\u003cdiv title\u003d\"CtrMensaje\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_4_7c8024c_1608227626997_320282_5562\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_29.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_4_7c8024c_1608227626997_320282_5562\u0027);return false;\"\u003eCtrMensaje\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col3": " \u003c/br\u003e",
              "col4": " \u003c/br\u003e",
              "col5": " \u003c/br\u003e"
            },
            {
              "col0": "16 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\": Mensaje\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_19.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e : Mensaje\u003c/div\u003e\u003c/br\u003e",
              "col2": "\u003cdiv title\u003d\"Mensaje\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_4_7c8024c_1606753583146_496411_5610\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_33.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_4_7c8024c_1606753583146_496411_5610\u0027);return false;\"\u003eMensaje\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col3": " \u003c/br\u003e",
              "col4": " \u003c/br\u003e",
              "col5": " \u003c/br\u003e"
            }
          ]
        },
        "columns": [
          {
            "text": "# ",
            "dataIndex": "col0",
            "flex": 0,
            "width": 96
          },
          {
            "text": "Name ",
            "dataIndex": "col1",
            "flex": 0,
            "width": 300
          },
          {
            "text": "Type ",
            "dataIndex": "col2",
            "flex": 0,
            "width": 300
          },
          {
            "text": "Multiplicity ",
            "dataIndex": "col3",
            "flex": 0,
            "width": 156
          },
          {
            "text": "Default value ",
            "dataIndex": "col4",
            "flex": 0,
            "width": 168
          },
          {
            "text": "Documentation ",
            "dataIndex": "col5",
            "flex": 1,
            "width": -1
          }
        ],
        "collapsible": true
      }
    ],
    "image_panel": [
      {
        "title": "Enviar correo interno",
        "image": "diagrams/diagram_Architecture___19_0_3_59501f0_1608294205704_298336_8841.png",
        "width": 1221,
        "height": 812,
        "collapsible": true,
        "map": {}
      },
      {
        "title": "Enviar correo interno_imported",
        "image": "diagrams/diagram_Architecture___19_0_4_7c8024c_1608397300008_653326_10085.png",
        "width": 1221,
        "height": 812,
        "collapsible": true,
        "map": {}
      },
      {
        "title": "Enviar correo interno_imported1",
        "image": "diagrams/diagram_Architecture___19_0_4_7c8024c_1608464478623_343897_11950.png",
        "width": 1221,
        "height": 812,
        "collapsible": true,
        "map": {}
      }
    ]
  },
  "Package___19_0_4_7c8024c_1606752452637_33243_5229": {
    "title": "Estructura",
    "path": "\u003cdiv title\u003d\"Estructura\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1606752452637_33243_5229\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1606752452637_33243_5229\u0027);return false;\"\u003eEstructura\u003ca\u003e\u003c/div\u003e",
    "html_panel": [],
    "grid_panel": [],
    "image_panel": []
  },
  "Package___19_0_4_7c8024c_1608218581306_512639_5238": {
    "title": "Interfaz",
    "path": "\u003cdiv title\u003d\"Estructura\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1606752452637_33243_5229\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1606752452637_33243_5229\u0027);return false;\"\u003eEstructura\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Interfaz\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1608218581306_512639_5238\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1608218581306_512639_5238\u0027);return false;\"\u003eInterfaz\u003ca\u003e\u003c/div\u003e",
    "html_panel": [],
    "grid_panel": [],
    "image_panel": []
  },
  "Glossary___19_0_4_65b021b_1608503171947_946887_7466": {
    "title": "Mensaje",
    "path": "\u003cdiv title\u003d\"Documentacion del Proyecto Entrega 2\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1608491267549_161671_7569\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1608491267549_161671_7569\u0027);return false;\"\u003eDocumentacion del Proyecto Entrega 2\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"2. Glosario\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_65b021b_1608502989614_109664_7440\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_65b021b_1608502989614_109664_7440\u0027);return false;\"\u003e2. Glosario\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Mensaje\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Glossary___19_0_4_65b021b_1608503171947_946887_7466\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_31.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Glossary___19_0_4_65b021b_1608503171947_946887_7466\u0027);return false;\"\u003eMensaje\u003ca\u003e\u003c/div\u003e",
    "html_panel": [],
    "grid_panel": [
      {
        "title": "Characteristics ",
        "hideHeaders": true,
        "data_store": {
          "fields": [
            "col0",
            "col1"
          ],
          "data": [
            {
              "col0": "Term ",
              "col1": "\u003cdiv title\u003d\"Mensaje\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Glossary___19_0_4_65b021b_1608503171947_946887_7466\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_31.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Glossary___19_0_4_65b021b_1608503171947_946887_7466\u0027);return false;\"\u003eMensaje\u003ca\u003e\u003c/div\u003e"
            },
            {
              "col0": "Description ",
              "col1": "Estos pueden ser enviados entre participantes en la plataforma o en foros de dudas. "
            }
          ]
        },
        "columns": [
          {
            "text": "col0",
            "dataIndex": "col0",
            "flex": 0,
            "width": 192
          },
          {
            "text": "col1",
            "dataIndex": "col1",
            "flex": 1,
            "width": -1
          }
        ],
        "collapsible": false
      }
    ],
    "image_panel": []
  },
  "EmptyContent___19_0_3_5c401fe_1605962882995_512132_5475": {
    "title": "Mensajeria Interna",
    "path": "\u003cdiv title\u003d\"Casos de uso\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_3_59501f0_1605898693468_780946_4813\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_3_59501f0_1605898693468_780946_4813\u0027);return false;\"\u003eCasos de uso\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Subsistema Curso\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1606045080271_940524_6239\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1606045080271_940524_6239\u0027);return false;\"\u003eSubsistema Curso\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Mensajeria Interna\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_3_5c401fe_1605962882995_512132_5475\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_6.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_3_5c401fe_1605962882995_512132_5475\u0027);return false;\"\u003eMensajeria Interna\u003ca\u003e\u003c/div\u003e",
    "html_panel": [],
    "grid_panel": [],
    "image_panel": []
  },
  "EmptyContent___19_0_3_5c401fe_1605960673783_419218_5276": {
    "title": "Mirar POST",
    "path": "\u003cdiv title\u003d\"Casos de uso\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_3_59501f0_1605898693468_780946_4813\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_3_59501f0_1605898693468_780946_4813\u0027);return false;\"\u003eCasos de uso\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Subsistema Foro\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1605975887729_200757_5237\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1605975887729_200757_5237\u0027);return false;\"\u003eSubsistema Foro\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Mirar POST\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_3_5c401fe_1605959803088_991088_4871\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_6.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_3_5c401fe_1605959803088_991088_4871\u0027);return false;\"\u003eMirar POST\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Mirar POST\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_3_5c401fe_1605960673783_419218_5276\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_17.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_3_5c401fe_1605960673783_419218_5276\u0027);return false;\"\u003eMirar POST\u003ca\u003e\u003c/div\u003e",
    "html_panel": [],
    "grid_panel": [],
    "image_panel": []
  },
  "EmptyContent___19_0_3_5c401fe_1605959803088_991088_4871": {
    "title": "Mirar POST",
    "path": "\u003cdiv title\u003d\"Casos de uso\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_3_59501f0_1605898693468_780946_4813\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_3_59501f0_1605898693468_780946_4813\u0027);return false;\"\u003eCasos de uso\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Subsistema Foro\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1605975887729_200757_5237\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1605975887729_200757_5237\u0027);return false;\"\u003eSubsistema Foro\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Mirar POST\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_3_5c401fe_1605959803088_991088_4871\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_6.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_3_5c401fe_1605959803088_991088_4871\u0027);return false;\"\u003eMirar POST\u003ca\u003e\u003c/div\u003e",
    "html_panel": [],
    "grid_panel": [],
    "image_panel": []
  },
  "Diagrams___19_0_4_7c8024c_1608464477782_544977_9517": {
    "title": "Mirar POST_imported2",
    "path": "\u003cdiv title\u003d\"Casos de uso\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_3_59501f0_1605898693468_780946_4813\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_3_59501f0_1605898693468_780946_4813\u0027);return false;\"\u003eCasos de uso\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Subsistema Foro\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1605975887729_200757_5237\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1605975887729_200757_5237\u0027);return false;\"\u003eSubsistema Foro\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Mirar POST\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_3_5c401fe_1605959803088_991088_4871\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_6.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_3_5c401fe_1605959803088_991088_4871\u0027);return false;\"\u003eMirar POST\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Mirar POST\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_3_5c401fe_1605960673783_419218_5276\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_17.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_3_5c401fe_1605960673783_419218_5276\u0027);return false;\"\u003eMirar POST\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Mirar POST_imported2\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Diagrams___19_0_4_7c8024c_1608464477782_544977_9517\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_16.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Diagrams___19_0_4_7c8024c_1608464477782_544977_9517\u0027);return false;\"\u003eMirar POST_imported2\u003ca\u003e\u003c/div\u003e",
    "html_panel": [],
    "grid_panel": [],
    "image_panel": [
      {
        "title": "",
        "image": "diagrams/diagram_Diagrams___19_0_4_7c8024c_1608464477797_42055_9537.png",
        "width": 328,
        "height": 806,
        "collapsible": false,
        "map": {}
      }
    ]
  },
  "Package__eee_1045467100313_135436_1": {
    "title": "Model",
    "path": "\u003cdiv title\u003d\"Model\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package__eee_1045467100313_135436_1\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_14.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package__eee_1045467100313_135436_1\u0027);return false;\"\u003eModel\u003ca\u003e\u003c/div\u003e",
    "html_panel": [],
    "grid_panel": [],
    "image_panel": []
  },
  "Glossary___19_0_4_65b021b_1608502085567_68231_7406": {
    "title": "ONG",
    "path": "\u003cdiv title\u003d\"Documentacion del Proyecto Entrega 2\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1608491267549_161671_7569\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1608491267549_161671_7569\u0027);return false;\"\u003eDocumentacion del Proyecto Entrega 2\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"2. Glosario\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_65b021b_1608502989614_109664_7440\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_65b021b_1608502989614_109664_7440\u0027);return false;\"\u003e2. Glosario\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"ONG\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Glossary___19_0_4_65b021b_1608502085567_68231_7406\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_31.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Glossary___19_0_4_65b021b_1608502085567_68231_7406\u0027);return false;\"\u003eONG\u003ca\u003e\u003c/div\u003e",
    "html_panel": [],
    "grid_panel": [
      {
        "title": "Characteristics ",
        "hideHeaders": true,
        "data_store": {
          "fields": [
            "col0",
            "col1"
          ],
          "data": [
            {
              "col0": "Term ",
              "col1": "\u003cdiv title\u003d\"ONG\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Glossary___19_0_4_65b021b_1608502085567_68231_7406\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_31.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Glossary___19_0_4_65b021b_1608502085567_68231_7406\u0027);return false;\"\u003eONG\u003ca\u003e\u003c/div\u003e"
            },
            {
              "col0": "Description ",
              "col1": "Puede crear nuevos usuarios (estudiantes/personas con las que la ONG colabora les crea un usuario para poder acceder a sus cursos), crear/modificar cursos,\u003cbr/\u003eactividades y talleres. "
            }
          ]
        },
        "columns": [
          {
            "text": "col0",
            "dataIndex": "col0",
            "flex": 0,
            "width": 192
          },
          {
            "text": "col1",
            "dataIndex": "col1",
            "flex": 1,
            "width": -1
          }
        ],
        "collapsible": false
      }
    ],
    "image_panel": []
  },
  "Glossary___19_0_4_65b021b_1608502034739_934366_7401": {
    "title": "Profesor",
    "path": "\u003cdiv title\u003d\"Documentacion del Proyecto Entrega 2\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1608491267549_161671_7569\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1608491267549_161671_7569\u0027);return false;\"\u003eDocumentacion del Proyecto Entrega 2\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"2. Glosario\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_65b021b_1608502989614_109664_7440\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_65b021b_1608502989614_109664_7440\u0027);return false;\"\u003e2. Glosario\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Profesor\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Glossary___19_0_4_65b021b_1608502034739_934366_7401\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_31.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Glossary___19_0_4_65b021b_1608502034739_934366_7401\u0027);return false;\"\u003eProfesor\u003ca\u003e\u003c/div\u003e",
    "html_panel": [],
    "grid_panel": [
      {
        "title": "Characteristics ",
        "hideHeaders": true,
        "data_store": {
          "fields": [
            "col0",
            "col1"
          ],
          "data": [
            {
              "col0": "Term ",
              "col1": "\u003cdiv title\u003d\"Profesor\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Glossary___19_0_4_65b021b_1608502034739_934366_7401\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_31.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Glossary___19_0_4_65b021b_1608502034739_934366_7401\u0027);return false;\"\u003eProfesor\u003ca\u003e\u003c/div\u003e"
            },
            {
              "col0": "Description ",
              "col1": "Pueden crear/modificar cursos, actividades y tareas, invitar usuarios al curso y calificar los usuarios que participen en el curso. "
            }
          ]
        },
        "columns": [
          {
            "text": "col0",
            "dataIndex": "col0",
            "flex": 0,
            "width": 192
          },
          {
            "text": "col1",
            "dataIndex": "col1",
            "flex": 1,
            "width": -1
          }
        ],
        "collapsible": false
      }
    ],
    "image_panel": []
  },
  "Requirement___19_0_3_59501f0_1605900716718_322105_5130": {
    "title": "Recordar Contraseña",
    "path": "\u003cdiv title\u003d\"Casos de uso\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_3_59501f0_1605898693468_780946_4813\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_3_59501f0_1605898693468_780946_4813\u0027);return false;\"\u003eCasos de uso\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Subsistema Identificación\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1605991759147_968139_5028\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1605991759147_968139_5028\u0027);return false;\"\u003eSubsistema Identificación\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Recordar Contraseña\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_3_59501f0_1605900716718_322105_5130\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_6.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_3_59501f0_1605900716718_322105_5130\u0027);return false;\"\u003eRecordar Contraseña\u003ca\u003e\u003c/div\u003e",
    "html_panel": [],
    "grid_panel": [
      {
        "title": "Characteristics ",
        "hideHeaders": true,
        "data_store": {
          "fields": [
            "col0",
            "col1"
          ],
          "data": [
            {
              "col0": "Name ",
              "col1": "\u003cdiv title\u003d\"Recordar Contraseña\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_3_59501f0_1605900716718_322105_5130\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_6.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_3_59501f0_1605900716718_322105_5130\u0027);return false;\"\u003eRecordar Contraseña\u003ca\u003e\u003c/div\u003e"
            }
          ]
        },
        "columns": [
          {
            "text": "col0",
            "dataIndex": "col0",
            "flex": 0,
            "width": 192
          },
          {
            "text": "col1",
            "dataIndex": "col1",
            "flex": 1,
            "width": -1
          }
        ],
        "collapsible": true
      },
      {
        "title": "Actors",
        "hideHeaders": false,
        "data_store": {
          "fields": [
            "col0",
            "col1",
            "col2"
          ],
          "data": [
            {
              "col0": "1 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\"Administrador\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1606046179164_726532_6549\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_5.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1606046179164_726532_6549\u0027);return false;\"\u003eAdministrador\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col2": " \u003c/br\u003e"
            },
            {
              "col0": "2 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\"Organizacion\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1605993976012_561063_6365\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_5.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1605993976012_561063_6365\u0027);return false;\"\u003eOrganizacion\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col2": " \u003c/br\u003e"
            },
            {
              "col0": "3 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\"instructor\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1608378644060_454646_6215\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_5.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1608378644060_454646_6215\u0027);return false;\"\u003einstructor\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col2": " \u003c/br\u003e"
            },
            {
              "col0": "4 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\"Alumno\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1605993976012_184874_6364\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_5.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1605993976012_184874_6364\u0027);return false;\"\u003eAlumno\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col2": " \u003c/br\u003e"
            },
            {
              "col0": "5 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\"Instructor\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1605993976013_127053_6366\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_5.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1605993976013_127053_6366\u0027);return false;\"\u003eInstructor\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col2": " \u003c/br\u003e"
            },
            {
              "col0": "6 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\"UMA\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1605992040306_840570_5282\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_5.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1605992040306_840570_5282\u0027);return false;\"\u003eUMA\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col2": " \u003c/br\u003e"
            }
          ]
        },
        "columns": [
          {
            "text": "# ",
            "dataIndex": "col0",
            "flex": 0,
            "width": 84
          },
          {
            "text": "Name ",
            "dataIndex": "col1",
            "flex": 0,
            "width": 300
          },
          {
            "text": "Documentation ",
            "dataIndex": "col2",
            "flex": 1,
            "width": -1
          }
        ],
        "collapsible": true
      },
      {
        "title": "Owned Behaviors",
        "hideHeaders": false,
        "data_store": {
          "fields": [
            "col0",
            "col1",
            "col2"
          ],
          "data": [
            {
              "col0": "1 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\"Recordar Contraseña\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_3_59501f0_1605900735636_101014_5144\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_17.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_3_59501f0_1605900735636_101014_5144\u0027);return false;\"\u003eRecordar Contraseña\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col2": " \u003c/br\u003e"
            },
            {
              "col0": "2 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\"Recordar Contraseña\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_3_59501f0_1608289624419_295501_6582\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_7.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_3_59501f0_1608289624419_295501_6582\u0027);return false;\"\u003eRecordar Contraseña\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col2": " \u003c/br\u003e"
            },
            {
              "col0": "3 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\"Recordar Contraseña-ALTERNATIVO\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_3_59501f0_1608291630127_209026_7223\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_7.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_3_59501f0_1608291630127_209026_7223\u0027);return false;\"\u003eRecordar Contraseña-ALTERNATIVO\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col2": " \u003c/br\u003e"
            }
          ]
        },
        "columns": [
          {
            "text": "# ",
            "dataIndex": "col0",
            "flex": 0,
            "width": 84
          },
          {
            "text": "Name ",
            "dataIndex": "col1",
            "flex": 0,
            "width": 300
          },
          {
            "text": "Documentation ",
            "dataIndex": "col2",
            "flex": 1,
            "width": -1
          }
        ],
        "collapsible": true
      },
      {
        "title": "Scenario - Basic Flow ",
        "hideHeaders": true,
        "data_store": {
          "fields": [
            "col0"
          ],
          "data": [
            {
              "col0": "1. El usuario solicita recuperar su contraseña "
            },
            {
              "col0": "2. El sistema solicita el nombre de usuario o el email "
            },
            {
              "col0": "3. El usuario introduce su nombre de usuario o su email "
            }
          ]
        },
        "columns": [
          {
            "text": "col0",
            "dataIndex": "col0",
            "flex": 1,
            "width": -1
          }
        ],
        "collapsible": true
      }
    ],
    "image_panel": []
  },
  "Architecture___19_0_3_59501f0_1608289624419_295501_6582": {
    "title": "Recordar Contraseña",
    "path": "\u003cdiv title\u003d\"Casos de uso\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_3_59501f0_1605898693468_780946_4813\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_3_59501f0_1605898693468_780946_4813\u0027);return false;\"\u003eCasos de uso\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Subsistema Identificación\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1605991759147_968139_5028\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1605991759147_968139_5028\u0027);return false;\"\u003eSubsistema Identificación\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Recordar Contraseña\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_3_59501f0_1605900716718_322105_5130\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_6.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_3_59501f0_1605900716718_322105_5130\u0027);return false;\"\u003eRecordar Contraseña\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Recordar Contraseña\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_3_59501f0_1608289624419_295501_6582\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_7.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_3_59501f0_1608289624419_295501_6582\u0027);return false;\"\u003eRecordar Contraseña\u003ca\u003e\u003c/div\u003e",
    "html_panel": [],
    "grid_panel": [
      {
        "title": "Characteristics ",
        "hideHeaders": true,
        "data_store": {
          "fields": [
            "col0",
            "col1"
          ],
          "data": [
            {
              "col0": "Name ",
              "col1": "\u003cdiv title\u003d\"Recordar Contraseña\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_3_59501f0_1608289624419_295501_6582\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_7.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_3_59501f0_1608289624419_295501_6582\u0027);return false;\"\u003eRecordar Contraseña\u003ca\u003e\u003c/div\u003e"
            }
          ]
        },
        "columns": [
          {
            "text": "col0",
            "dataIndex": "col0",
            "flex": 0,
            "width": 192
          },
          {
            "text": "col1",
            "dataIndex": "col1",
            "flex": 1,
            "width": -1
          }
        ],
        "collapsible": true
      },
      {
        "title": "Attributes",
        "hideHeaders": false,
        "data_store": {
          "fields": [
            "col0",
            "col1",
            "col2",
            "col3",
            "col4",
            "col5"
          ],
          "data": [
            {
              "col0": "1 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\": viewLogin\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_19.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e : viewLogin\u003c/div\u003e\u003c/br\u003e",
              "col2": "\u003cdiv title\u003d\"viewLogin\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_3_59501f0_1608289477847_206130_6495\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_32.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_3_59501f0_1608289477847_206130_6495\u0027);return false;\"\u003eviewLogin\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col3": " \u003c/br\u003e",
              "col4": " \u003c/br\u003e",
              "col5": " \u003c/br\u003e"
            },
            {
              "col0": "2 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\": CtrLogin\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_19.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e : CtrLogin\u003c/div\u003e\u003c/br\u003e",
              "col2": "\u003cdiv title\u003d\"CtrLogin\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_3_59501f0_1608289515343_915789_6522\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_29.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_3_59501f0_1608289515343_915789_6522\u0027);return false;\"\u003eCtrLogin\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col3": " \u003c/br\u003e",
              "col4": " \u003c/br\u003e",
              "col5": " \u003c/br\u003e"
            },
            {
              "col0": "3 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\": viewRecordarContraseña\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_19.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e : viewRecordarContraseña\u003c/div\u003e\u003c/br\u003e",
              "col2": "\u003cdiv title\u003d\"viewRecordarContraseña\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_3_59501f0_1608290079487_174443_6756\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_32.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_3_59501f0_1608290079487_174443_6756\u0027);return false;\"\u003eviewRecordarContraseña\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col3": " \u003c/br\u003e",
              "col4": " \u003c/br\u003e",
              "col5": " \u003c/br\u003e"
            },
            {
              "col0": "4 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\": CtrRecordarContraseña\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_19.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e : CtrRecordarContraseña\u003c/div\u003e\u003c/br\u003e",
              "col2": "\u003cdiv title\u003d\"CtrRecordarContraseña\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_3_59501f0_1608290112646_914644_6783\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_29.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_3_59501f0_1608290112646_914644_6783\u0027);return false;\"\u003eCtrRecordarContraseña\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col3": " \u003c/br\u003e",
              "col4": " \u003c/br\u003e",
              "col5": " \u003c/br\u003e"
            },
            {
              "col0": "5 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\": CtrNuevaContraseña\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_19.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e : CtrNuevaContraseña\u003c/div\u003e\u003c/br\u003e",
              "col2": "\u003cdiv title\u003d\"CtrNuevaContraseña\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_3_59501f0_1608290931398_577538_7005\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_29.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_3_59501f0_1608290931398_577538_7005\u0027);return false;\"\u003eCtrNuevaContraseña\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col3": " \u003c/br\u003e",
              "col4": " \u003c/br\u003e",
              "col5": " \u003c/br\u003e"
            },
            {
              "col0": "6 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\": viewNuevaContraseña\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_19.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e : viewNuevaContraseña\u003c/div\u003e\u003c/br\u003e",
              "col2": "\u003cdiv title\u003d\"viewNuevaContraseña\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_3_59501f0_1608290893629_418155_6978\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_32.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_3_59501f0_1608290893629_418155_6978\u0027);return false;\"\u003eviewNuevaContraseña\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col3": " \u003c/br\u003e",
              "col4": " \u003c/br\u003e",
              "col5": " \u003c/br\u003e"
            },
            {
              "col0": "7 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\": Alumno\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_19.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e : Alumno\u003c/div\u003e\u003c/br\u003e",
              "col2": "\u003cdiv title\u003d\"Alumno\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_4_7c8024c_1606752667095_524856_5295\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_33.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_4_7c8024c_1606752667095_524856_5295\u0027);return false;\"\u003eAlumno\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col3": " \u003c/br\u003e",
              "col4": " \u003c/br\u003e",
              "col5": " \u003c/br\u003e"
            },
            {
              "col0": "8 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\": Alumno\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_19.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e : Alumno\u003c/div\u003e\u003c/br\u003e",
              "col2": "\u003cdiv title\u003d\"Alumno\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_4_7c8024c_1606752667095_524856_5295\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_33.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_4_7c8024c_1606752667095_524856_5295\u0027);return false;\"\u003eAlumno\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col3": " \u003c/br\u003e",
              "col4": " \u003c/br\u003e",
              "col5": " \u003c/br\u003e"
            },
            {
              "col0": "9 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\": viewLogin\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_19.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e : viewLogin\u003c/div\u003e\u003c/br\u003e",
              "col2": "\u003cdiv title\u003d\"viewLogin\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_3_59501f0_1608289477847_206130_6495\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_32.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_3_59501f0_1608289477847_206130_6495\u0027);return false;\"\u003eviewLogin\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col3": " \u003c/br\u003e",
              "col4": " \u003c/br\u003e",
              "col5": " \u003c/br\u003e"
            },
            {
              "col0": "10 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\": CtrLogin\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_19.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e : CtrLogin\u003c/div\u003e\u003c/br\u003e",
              "col2": "\u003cdiv title\u003d\"CtrLogin\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_3_59501f0_1608289515343_915789_6522\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_29.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_3_59501f0_1608289515343_915789_6522\u0027);return false;\"\u003eCtrLogin\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col3": " \u003c/br\u003e",
              "col4": " \u003c/br\u003e",
              "col5": " \u003c/br\u003e"
            },
            {
              "col0": "11 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\": viewRecordarContraseña\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_19.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e : viewRecordarContraseña\u003c/div\u003e\u003c/br\u003e",
              "col2": "\u003cdiv title\u003d\"viewRecordarContraseña\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_3_59501f0_1608290079487_174443_6756\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_32.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_3_59501f0_1608290079487_174443_6756\u0027);return false;\"\u003eviewRecordarContraseña\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col3": " \u003c/br\u003e",
              "col4": " \u003c/br\u003e",
              "col5": " \u003c/br\u003e"
            },
            {
              "col0": "12 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\": CtrRecordarContraseña\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_19.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e : CtrRecordarContraseña\u003c/div\u003e\u003c/br\u003e",
              "col2": "\u003cdiv title\u003d\"CtrRecordarContraseña\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_3_59501f0_1608290112646_914644_6783\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_29.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_3_59501f0_1608290112646_914644_6783\u0027);return false;\"\u003eCtrRecordarContraseña\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col3": " \u003c/br\u003e",
              "col4": " \u003c/br\u003e",
              "col5": " \u003c/br\u003e"
            },
            {
              "col0": "13 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\": CtrNuevaContraseña\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_19.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e : CtrNuevaContraseña\u003c/div\u003e\u003c/br\u003e",
              "col2": "\u003cdiv title\u003d\"CtrNuevaContraseña\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_3_59501f0_1608290931398_577538_7005\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_29.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_3_59501f0_1608290931398_577538_7005\u0027);return false;\"\u003eCtrNuevaContraseña\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col3": " \u003c/br\u003e",
              "col4": " \u003c/br\u003e",
              "col5": " \u003c/br\u003e"
            },
            {
              "col0": "14 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\": viewNuevaContraseña\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_19.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e : viewNuevaContraseña\u003c/div\u003e\u003c/br\u003e",
              "col2": "\u003cdiv title\u003d\"viewNuevaContraseña\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_3_59501f0_1608290893629_418155_6978\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_32.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_3_59501f0_1608290893629_418155_6978\u0027);return false;\"\u003eviewNuevaContraseña\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col3": " \u003c/br\u003e",
              "col4": " \u003c/br\u003e",
              "col5": " \u003c/br\u003e"
            },
            {
              "col0": "15 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\": Alumno\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_19.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e : Alumno\u003c/div\u003e\u003c/br\u003e",
              "col2": "\u003cdiv title\u003d\"Alumno\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_4_7c8024c_1606752667095_524856_5295\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_33.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_4_7c8024c_1606752667095_524856_5295\u0027);return false;\"\u003eAlumno\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col3": " \u003c/br\u003e",
              "col4": " \u003c/br\u003e",
              "col5": " \u003c/br\u003e"
            },
            {
              "col0": "16 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\": Alumno\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_19.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e : Alumno\u003c/div\u003e\u003c/br\u003e",
              "col2": "\u003cdiv title\u003d\"Alumno\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_4_7c8024c_1606752667095_524856_5295\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_33.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_4_7c8024c_1606752667095_524856_5295\u0027);return false;\"\u003eAlumno\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col3": " \u003c/br\u003e",
              "col4": " \u003c/br\u003e",
              "col5": " \u003c/br\u003e"
            },
            {
              "col0": "17 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\": viewLogin\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_19.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e : viewLogin\u003c/div\u003e\u003c/br\u003e",
              "col2": "\u003cdiv title\u003d\"viewLogin\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_3_59501f0_1608289477847_206130_6495\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_32.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_3_59501f0_1608289477847_206130_6495\u0027);return false;\"\u003eviewLogin\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col3": " \u003c/br\u003e",
              "col4": " \u003c/br\u003e",
              "col5": " \u003c/br\u003e"
            },
            {
              "col0": "18 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\": CtrLogin\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_19.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e : CtrLogin\u003c/div\u003e\u003c/br\u003e",
              "col2": "\u003cdiv title\u003d\"CtrLogin\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_3_59501f0_1608289515343_915789_6522\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_29.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_3_59501f0_1608289515343_915789_6522\u0027);return false;\"\u003eCtrLogin\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col3": " \u003c/br\u003e",
              "col4": " \u003c/br\u003e",
              "col5": " \u003c/br\u003e"
            },
            {
              "col0": "19 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\": viewRecordarContraseña\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_19.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e : viewRecordarContraseña\u003c/div\u003e\u003c/br\u003e",
              "col2": "\u003cdiv title\u003d\"viewRecordarContraseña\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_3_59501f0_1608290079487_174443_6756\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_32.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_3_59501f0_1608290079487_174443_6756\u0027);return false;\"\u003eviewRecordarContraseña\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col3": " \u003c/br\u003e",
              "col4": " \u003c/br\u003e",
              "col5": " \u003c/br\u003e"
            },
            {
              "col0": "20 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\": CtrRecordarContraseña\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_19.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e : CtrRecordarContraseña\u003c/div\u003e\u003c/br\u003e",
              "col2": "\u003cdiv title\u003d\"CtrRecordarContraseña\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_3_59501f0_1608290112646_914644_6783\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_29.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_3_59501f0_1608290112646_914644_6783\u0027);return false;\"\u003eCtrRecordarContraseña\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col3": " \u003c/br\u003e",
              "col4": " \u003c/br\u003e",
              "col5": " \u003c/br\u003e"
            },
            {
              "col0": "21 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\": CtrNuevaContraseña\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_19.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e : CtrNuevaContraseña\u003c/div\u003e\u003c/br\u003e",
              "col2": "\u003cdiv title\u003d\"CtrNuevaContraseña\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_3_59501f0_1608290931398_577538_7005\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_29.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_3_59501f0_1608290931398_577538_7005\u0027);return false;\"\u003eCtrNuevaContraseña\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col3": " \u003c/br\u003e",
              "col4": " \u003c/br\u003e",
              "col5": " \u003c/br\u003e"
            },
            {
              "col0": "22 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\": viewNuevaContraseña\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_19.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e : viewNuevaContraseña\u003c/div\u003e\u003c/br\u003e",
              "col2": "\u003cdiv title\u003d\"viewNuevaContraseña\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_3_59501f0_1608290893629_418155_6978\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_32.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_3_59501f0_1608290893629_418155_6978\u0027);return false;\"\u003eviewNuevaContraseña\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col3": " \u003c/br\u003e",
              "col4": " \u003c/br\u003e",
              "col5": " \u003c/br\u003e"
            },
            {
              "col0": "23 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\": Alumno\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_19.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e : Alumno\u003c/div\u003e\u003c/br\u003e",
              "col2": "\u003cdiv title\u003d\"Alumno\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_4_7c8024c_1606752667095_524856_5295\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_33.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_4_7c8024c_1606752667095_524856_5295\u0027);return false;\"\u003eAlumno\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col3": " \u003c/br\u003e",
              "col4": " \u003c/br\u003e",
              "col5": " \u003c/br\u003e"
            },
            {
              "col0": "24 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\": Alumno\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_19.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e : Alumno\u003c/div\u003e\u003c/br\u003e",
              "col2": "\u003cdiv title\u003d\"Alumno\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1605993976012_184874_6364\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_5.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1605993976012_184874_6364\u0027);return false;\"\u003eAlumno\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col3": " \u003c/br\u003e",
              "col4": " \u003c/br\u003e",
              "col5": " \u003c/br\u003e"
            }
          ]
        },
        "columns": [
          {
            "text": "# ",
            "dataIndex": "col0",
            "flex": 0,
            "width": 96
          },
          {
            "text": "Name ",
            "dataIndex": "col1",
            "flex": 0,
            "width": 300
          },
          {
            "text": "Type ",
            "dataIndex": "col2",
            "flex": 0,
            "width": 300
          },
          {
            "text": "Multiplicity ",
            "dataIndex": "col3",
            "flex": 0,
            "width": 156
          },
          {
            "text": "Default value ",
            "dataIndex": "col4",
            "flex": 0,
            "width": 168
          },
          {
            "text": "Documentation ",
            "dataIndex": "col5",
            "flex": 1,
            "width": -1
          }
        ],
        "collapsible": true
      }
    ],
    "image_panel": [
      {
        "title": "Recordar Contraseña",
        "image": "diagrams/diagram_Architecture___19_0_3_59501f0_1608289624423_916136_6603.png",
        "width": 1551,
        "height": 832,
        "collapsible": true,
        "map": {}
      },
      {
        "title": "Recordar Contraseña_imported",
        "image": "diagrams/diagram_Architecture___19_0_4_7c8024c_1608397299467_428093_8374.png",
        "width": 1551,
        "height": 832,
        "collapsible": true,
        "map": {}
      },
      {
        "title": "Recordar Contraseña_imported1",
        "image": "diagrams/diagram_Architecture___19_0_4_7c8024c_1608464477971_174220_10022.png",
        "width": 1551,
        "height": 832,
        "collapsible": true,
        "map": {}
      }
    ]
  },
  "EmptyContent___19_0_3_59501f0_1605900716718_322105_5130": {
    "title": "Recordar Contraseña",
    "path": "\u003cdiv title\u003d\"Casos de uso\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_3_59501f0_1605898693468_780946_4813\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_3_59501f0_1605898693468_780946_4813\u0027);return false;\"\u003eCasos de uso\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Subsistema Identificación\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1605991759147_968139_5028\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1605991759147_968139_5028\u0027);return false;\"\u003eSubsistema Identificación\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Recordar Contraseña\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_3_59501f0_1605900716718_322105_5130\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_6.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_3_59501f0_1605900716718_322105_5130\u0027);return false;\"\u003eRecordar Contraseña\u003ca\u003e\u003c/div\u003e",
    "html_panel": [],
    "grid_panel": [],
    "image_panel": []
  },
  "Architecture___19_0_3_59501f0_1608291630127_209026_7223": {
    "title": "Recordar Contraseña-ALTERNATIVO",
    "path": "\u003cdiv title\u003d\"Casos de uso\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_3_59501f0_1605898693468_780946_4813\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_3_59501f0_1605898693468_780946_4813\u0027);return false;\"\u003eCasos de uso\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Subsistema Identificación\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1605991759147_968139_5028\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1605991759147_968139_5028\u0027);return false;\"\u003eSubsistema Identificación\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Recordar Contraseña\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_3_59501f0_1605900716718_322105_5130\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_6.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_3_59501f0_1605900716718_322105_5130\u0027);return false;\"\u003eRecordar Contraseña\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Recordar Contraseña-ALTERNATIVO\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_3_59501f0_1608291630127_209026_7223\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_7.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_3_59501f0_1608291630127_209026_7223\u0027);return false;\"\u003eRecordar Contraseña-ALTERNATIVO\u003ca\u003e\u003c/div\u003e",
    "html_panel": [],
    "grid_panel": [
      {
        "title": "Characteristics ",
        "hideHeaders": true,
        "data_store": {
          "fields": [
            "col0",
            "col1"
          ],
          "data": [
            {
              "col0": "Name ",
              "col1": "\u003cdiv title\u003d\"Recordar Contraseña-ALTERNATIVO\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_3_59501f0_1608291630127_209026_7223\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_7.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_3_59501f0_1608291630127_209026_7223\u0027);return false;\"\u003eRecordar Contraseña-ALTERNATIVO\u003ca\u003e\u003c/div\u003e"
            }
          ]
        },
        "columns": [
          {
            "text": "col0",
            "dataIndex": "col0",
            "flex": 0,
            "width": 192
          },
          {
            "text": "col1",
            "dataIndex": "col1",
            "flex": 1,
            "width": -1
          }
        ],
        "collapsible": true
      },
      {
        "title": "Attributes",
        "hideHeaders": false,
        "data_store": {
          "fields": [
            "col0",
            "col1",
            "col2",
            "col3",
            "col4",
            "col5"
          ],
          "data": [
            {
              "col0": "1 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\": viewRecordarContraseña\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_19.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e : viewRecordarContraseña\u003c/div\u003e\u003c/br\u003e",
              "col2": "\u003cdiv title\u003d\"viewRecordarContraseña\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_3_59501f0_1608290079487_174443_6756\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_32.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_3_59501f0_1608290079487_174443_6756\u0027);return false;\"\u003eviewRecordarContraseña\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col3": " \u003c/br\u003e",
              "col4": " \u003c/br\u003e",
              "col5": " \u003c/br\u003e"
            },
            {
              "col0": "2 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\": CtrRecordarContraseña\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_19.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e : CtrRecordarContraseña\u003c/div\u003e\u003c/br\u003e",
              "col2": "\u003cdiv title\u003d\"CtrRecordarContraseña\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_3_59501f0_1608290112646_914644_6783\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_29.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_3_59501f0_1608290112646_914644_6783\u0027);return false;\"\u003eCtrRecordarContraseña\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col3": " \u003c/br\u003e",
              "col4": " \u003c/br\u003e",
              "col5": " \u003c/br\u003e"
            },
            {
              "col0": "3 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\": viewLogin\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_19.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e : viewLogin\u003c/div\u003e\u003c/br\u003e",
              "col2": "\u003cdiv title\u003d\"viewLogin\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_3_59501f0_1608289477847_206130_6495\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_32.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_3_59501f0_1608289477847_206130_6495\u0027);return false;\"\u003eviewLogin\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col3": " \u003c/br\u003e",
              "col4": " \u003c/br\u003e",
              "col5": " \u003c/br\u003e"
            },
            {
              "col0": "4 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\": CtrLogin\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_19.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e : CtrLogin\u003c/div\u003e\u003c/br\u003e",
              "col2": "\u003cdiv title\u003d\"CtrLogin\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_3_59501f0_1608289515343_915789_6522\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_29.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_3_59501f0_1608289515343_915789_6522\u0027);return false;\"\u003eCtrLogin\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col3": " \u003c/br\u003e",
              "col4": " \u003c/br\u003e",
              "col5": " \u003c/br\u003e"
            },
            {
              "col0": "5 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\": viewRecordarContraseña\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_19.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e : viewRecordarContraseña\u003c/div\u003e\u003c/br\u003e",
              "col2": "\u003cdiv title\u003d\"viewRecordarContraseña\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_3_59501f0_1608290079487_174443_6756\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_32.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_3_59501f0_1608290079487_174443_6756\u0027);return false;\"\u003eviewRecordarContraseña\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col3": " \u003c/br\u003e",
              "col4": " \u003c/br\u003e",
              "col5": " \u003c/br\u003e"
            },
            {
              "col0": "6 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\": CtrRecordarContraseña\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_19.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e : CtrRecordarContraseña\u003c/div\u003e\u003c/br\u003e",
              "col2": "\u003cdiv title\u003d\"CtrRecordarContraseña\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_3_59501f0_1608290112646_914644_6783\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_29.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_3_59501f0_1608290112646_914644_6783\u0027);return false;\"\u003eCtrRecordarContraseña\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col3": " \u003c/br\u003e",
              "col4": " \u003c/br\u003e",
              "col5": " \u003c/br\u003e"
            },
            {
              "col0": "7 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\": viewLogin\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_19.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e : viewLogin\u003c/div\u003e\u003c/br\u003e",
              "col2": "\u003cdiv title\u003d\"viewLogin\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_3_59501f0_1608289477847_206130_6495\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_32.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_3_59501f0_1608289477847_206130_6495\u0027);return false;\"\u003eviewLogin\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col3": " \u003c/br\u003e",
              "col4": " \u003c/br\u003e",
              "col5": " \u003c/br\u003e"
            },
            {
              "col0": "8 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\": CtrLogin\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_19.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e : CtrLogin\u003c/div\u003e\u003c/br\u003e",
              "col2": "\u003cdiv title\u003d\"CtrLogin\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_3_59501f0_1608289515343_915789_6522\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_29.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_3_59501f0_1608289515343_915789_6522\u0027);return false;\"\u003eCtrLogin\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col3": " \u003c/br\u003e",
              "col4": " \u003c/br\u003e",
              "col5": " \u003c/br\u003e"
            },
            {
              "col0": "9 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\": Alumno\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_19.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e : Alumno\u003c/div\u003e\u003c/br\u003e",
              "col2": "\u003cdiv title\u003d\"Alumno\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_4_7c8024c_1606752667095_524856_5295\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_33.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_4_7c8024c_1606752667095_524856_5295\u0027);return false;\"\u003eAlumno\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col3": " \u003c/br\u003e",
              "col4": " \u003c/br\u003e",
              "col5": " \u003c/br\u003e"
            },
            {
              "col0": "10 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\": viewRecordarContraseña\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_19.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e : viewRecordarContraseña\u003c/div\u003e\u003c/br\u003e",
              "col2": "\u003cdiv title\u003d\"viewRecordarContraseña\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_3_59501f0_1608290079487_174443_6756\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_32.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_3_59501f0_1608290079487_174443_6756\u0027);return false;\"\u003eviewRecordarContraseña\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col3": " \u003c/br\u003e",
              "col4": " \u003c/br\u003e",
              "col5": " \u003c/br\u003e"
            },
            {
              "col0": "11 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\": CtrRecordarContraseña\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_19.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e : CtrRecordarContraseña\u003c/div\u003e\u003c/br\u003e",
              "col2": "\u003cdiv title\u003d\"CtrRecordarContraseña\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_3_59501f0_1608290112646_914644_6783\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_29.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_3_59501f0_1608290112646_914644_6783\u0027);return false;\"\u003eCtrRecordarContraseña\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col3": " \u003c/br\u003e",
              "col4": " \u003c/br\u003e",
              "col5": " \u003c/br\u003e"
            },
            {
              "col0": "12 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\": viewLogin\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_19.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e : viewLogin\u003c/div\u003e\u003c/br\u003e",
              "col2": "\u003cdiv title\u003d\"viewLogin\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_3_59501f0_1608289477847_206130_6495\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_32.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_3_59501f0_1608289477847_206130_6495\u0027);return false;\"\u003eviewLogin\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col3": " \u003c/br\u003e",
              "col4": " \u003c/br\u003e",
              "col5": " \u003c/br\u003e"
            },
            {
              "col0": "13 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\": CtrLogin\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_19.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e : CtrLogin\u003c/div\u003e\u003c/br\u003e",
              "col2": "\u003cdiv title\u003d\"CtrLogin\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_3_59501f0_1608289515343_915789_6522\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_29.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_3_59501f0_1608289515343_915789_6522\u0027);return false;\"\u003eCtrLogin\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col3": " \u003c/br\u003e",
              "col4": " \u003c/br\u003e",
              "col5": " \u003c/br\u003e"
            },
            {
              "col0": "14 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\": Alumno\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_19.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e : Alumno\u003c/div\u003e\u003c/br\u003e",
              "col2": "\u003cdiv title\u003d\"Alumno\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_4_7c8024c_1606752667095_524856_5295\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_33.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_4_7c8024c_1606752667095_524856_5295\u0027);return false;\"\u003eAlumno\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col3": " \u003c/br\u003e",
              "col4": " \u003c/br\u003e",
              "col5": " \u003c/br\u003e"
            },
            {
              "col0": "15 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\": Alumno\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_19.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e : Alumno\u003c/div\u003e\u003c/br\u003e",
              "col2": "\u003cdiv title\u003d\"Alumno\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1605993976012_184874_6364\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_5.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1605993976012_184874_6364\u0027);return false;\"\u003eAlumno\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col3": " \u003c/br\u003e",
              "col4": " \u003c/br\u003e",
              "col5": " \u003c/br\u003e"
            }
          ]
        },
        "columns": [
          {
            "text": "# ",
            "dataIndex": "col0",
            "flex": 0,
            "width": 96
          },
          {
            "text": "Name ",
            "dataIndex": "col1",
            "flex": 0,
            "width": 300
          },
          {
            "text": "Type ",
            "dataIndex": "col2",
            "flex": 0,
            "width": 300
          },
          {
            "text": "Multiplicity ",
            "dataIndex": "col3",
            "flex": 0,
            "width": 156
          },
          {
            "text": "Default value ",
            "dataIndex": "col4",
            "flex": 0,
            "width": 168
          },
          {
            "text": "Documentation ",
            "dataIndex": "col5",
            "flex": 1,
            "width": -1
          }
        ],
        "collapsible": true
      }
    ],
    "image_panel": [
      {
        "title": "Recordar Contraseña-ALTERNATIVO",
        "image": "diagrams/diagram_Architecture___19_0_3_59501f0_1608291630131_963425_7244.png",
        "width": 1523,
        "height": 832,
        "collapsible": true,
        "map": {}
      },
      {
        "title": "Recordar Contraseña-ALTERNATIVO_imported",
        "image": "diagrams/diagram_Architecture___19_0_4_7c8024c_1608397299486_651743_8462.png",
        "width": 1523,
        "height": 832,
        "collapsible": true,
        "map": {}
      },
      {
        "title": "Recordar Contraseña-ALTERNATIVO_imported1",
        "image": "diagrams/diagram_Architecture___19_0_4_7c8024c_1608464477990_353083_10110.png",
        "width": 1523,
        "height": 832,
        "collapsible": true,
        "map": {}
      }
    ]
  },
  "EmptyContent___19_0_3_5c401fe_1605961577356_539243_4912": {
    "title": "Registro",
    "path": "\u003cdiv title\u003d\"Casos de uso\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_3_59501f0_1605898693468_780946_4813\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_3_59501f0_1605898693468_780946_4813\u0027);return false;\"\u003eCasos de uso\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Subsistema Identificación\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1605991759147_968139_5028\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1605991759147_968139_5028\u0027);return false;\"\u003eSubsistema Identificación\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Registro\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_3_5c401fe_1605961577356_539243_4912\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_6.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_3_5c401fe_1605961577356_539243_4912\u0027);return false;\"\u003eRegistro\u003ca\u003e\u003c/div\u003e",
    "html_panel": [],
    "grid_panel": [],
    "image_panel": []
  },
  "Architecture___19_0_3_5c401fe_1608572688415_5055_8478": {
    "title": "Registro usuarios Alter",
    "path": "\u003cdiv title\u003d\"Casos de uso\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_3_59501f0_1605898693468_780946_4813\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_3_59501f0_1605898693468_780946_4813\u0027);return false;\"\u003eCasos de uso\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Subsistema Identificación\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1605991759147_968139_5028\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1605991759147_968139_5028\u0027);return false;\"\u003eSubsistema Identificación\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Registro\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_3_5c401fe_1605961577356_539243_4912\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_6.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_3_5c401fe_1605961577356_539243_4912\u0027);return false;\"\u003eRegistro\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Registro usuarios Alter\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_3_5c401fe_1608572688415_5055_8478\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_7.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_3_5c401fe_1608572688415_5055_8478\u0027);return false;\"\u003eRegistro usuarios Alter\u003ca\u003e\u003c/div\u003e",
    "html_panel": [],
    "grid_panel": [
      {
        "title": "Characteristics ",
        "hideHeaders": true,
        "data_store": {
          "fields": [
            "col0",
            "col1"
          ],
          "data": [
            {
              "col0": "Name ",
              "col1": "\u003cdiv title\u003d\"Registro usuarios Alter\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_3_5c401fe_1608572688415_5055_8478\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_7.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_3_5c401fe_1608572688415_5055_8478\u0027);return false;\"\u003eRegistro usuarios Alter\u003ca\u003e\u003c/div\u003e"
            }
          ]
        },
        "columns": [
          {
            "text": "col0",
            "dataIndex": "col0",
            "flex": 0,
            "width": 192
          },
          {
            "text": "col1",
            "dataIndex": "col1",
            "flex": 1,
            "width": -1
          }
        ],
        "collapsible": true
      },
      {
        "title": "Attributes",
        "hideHeaders": false,
        "data_store": {
          "fields": [
            "col0",
            "col1",
            "col2",
            "col3",
            "col4",
            "col5"
          ],
          "data": [
            {
              "col0": "1 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\": Alumno\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_19.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e : Alumno\u003c/div\u003e\u003c/br\u003e",
              "col2": "\u003cdiv title\u003d\"Alumno\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1605993976012_184874_6364\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_5.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1605993976012_184874_6364\u0027);return false;\"\u003eAlumno\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col3": " \u003c/br\u003e",
              "col4": " \u003c/br\u003e",
              "col5": " \u003c/br\u003e"
            },
            {
              "col0": "2 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\": viewLogin\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_19.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e : viewLogin\u003c/div\u003e\u003c/br\u003e",
              "col2": "\u003cdiv title\u003d\"viewLogin\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_3_59501f0_1608289477847_206130_6495\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_32.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_3_59501f0_1608289477847_206130_6495\u0027);return false;\"\u003eviewLogin\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col3": " \u003c/br\u003e",
              "col4": " \u003c/br\u003e",
              "col5": " \u003c/br\u003e"
            },
            {
              "col0": "3 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\": CtrLogin\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_19.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e : CtrLogin\u003c/div\u003e\u003c/br\u003e",
              "col2": "\u003cdiv title\u003d\"CtrLogin\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_3_59501f0_1608289515343_915789_6522\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_29.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_3_59501f0_1608289515343_915789_6522\u0027);return false;\"\u003eCtrLogin\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col3": " \u003c/br\u003e",
              "col4": " \u003c/br\u003e",
              "col5": " \u003c/br\u003e"
            },
            {
              "col0": "4 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\": viewRegistroAlumno\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_19.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e : viewRegistroAlumno\u003c/div\u003e\u003c/br\u003e",
              "col2": "\u003cdiv title\u003d\"viewRegistroAlumno\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_3_59501f0_1608293372778_521191_8219\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_32.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_3_59501f0_1608293372778_521191_8219\u0027);return false;\"\u003eviewRegistroAlumno\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col3": " \u003c/br\u003e",
              "col4": " \u003c/br\u003e",
              "col5": " \u003c/br\u003e"
            },
            {
              "col0": "5 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\": CtrRegistroAlumno\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_19.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e : CtrRegistroAlumno\u003c/div\u003e\u003c/br\u003e",
              "col2": "\u003cdiv title\u003d\"CtrRegistroAlumno\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_3_59501f0_1608293473162_613833_8246\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_29.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_3_59501f0_1608293473162_613833_8246\u0027);return false;\"\u003eCtrRegistroAlumno\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col3": " \u003c/br\u003e",
              "col4": " \u003c/br\u003e",
              "col5": " \u003c/br\u003e"
            },
            {
              "col0": "6 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\": Alumno\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_19.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e : Alumno\u003c/div\u003e\u003c/br\u003e",
              "col2": "\u003cdiv title\u003d\"Alumno\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1605993976012_184874_6364\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_5.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1605993976012_184874_6364\u0027);return false;\"\u003eAlumno\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col3": " \u003c/br\u003e",
              "col4": " \u003c/br\u003e",
              "col5": " \u003c/br\u003e"
            },
            {
              "col0": "7 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\": viewLogin\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_19.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e : viewLogin\u003c/div\u003e\u003c/br\u003e",
              "col2": "\u003cdiv title\u003d\"viewLogin\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_3_59501f0_1608289477847_206130_6495\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_32.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_3_59501f0_1608289477847_206130_6495\u0027);return false;\"\u003eviewLogin\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col3": " \u003c/br\u003e",
              "col4": " \u003c/br\u003e",
              "col5": " \u003c/br\u003e"
            },
            {
              "col0": "8 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\": CtrLogin\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_19.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e : CtrLogin\u003c/div\u003e\u003c/br\u003e",
              "col2": "\u003cdiv title\u003d\"CtrLogin\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_3_59501f0_1608289515343_915789_6522\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_29.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_3_59501f0_1608289515343_915789_6522\u0027);return false;\"\u003eCtrLogin\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col3": " \u003c/br\u003e",
              "col4": " \u003c/br\u003e",
              "col5": " \u003c/br\u003e"
            },
            {
              "col0": "9 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\": viewRegistroAlumno\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_19.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e : viewRegistroAlumno\u003c/div\u003e\u003c/br\u003e",
              "col2": "\u003cdiv title\u003d\"viewRegistroAlumno\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_3_59501f0_1608293372778_521191_8219\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_32.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_3_59501f0_1608293372778_521191_8219\u0027);return false;\"\u003eviewRegistroAlumno\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col3": " \u003c/br\u003e",
              "col4": " \u003c/br\u003e",
              "col5": " \u003c/br\u003e"
            },
            {
              "col0": "10 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\": CtrRegistroAlumno\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_19.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e : CtrRegistroAlumno\u003c/div\u003e\u003c/br\u003e",
              "col2": "\u003cdiv title\u003d\"CtrRegistroAlumno\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_3_59501f0_1608293473162_613833_8246\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_29.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_3_59501f0_1608293473162_613833_8246\u0027);return false;\"\u003eCtrRegistroAlumno\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col3": " \u003c/br\u003e",
              "col4": " \u003c/br\u003e",
              "col5": " \u003c/br\u003e"
            },
            {
              "col0": "11 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\": viewFormularioAlumno\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_19.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e : viewFormularioAlumno\u003c/div\u003e\u003c/br\u003e",
              "col2": "\u003cdiv title\u003d\"viewFormularioAlumno\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_3_59501f0_1608293701904_601119_8368\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_32.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_3_59501f0_1608293701904_601119_8368\u0027);return false;\"\u003eviewFormularioAlumno\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col3": " \u003c/br\u003e",
              "col4": " \u003c/br\u003e",
              "col5": " \u003c/br\u003e"
            },
            {
              "col0": "12 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\": CtrFormularioAlumno\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_19.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e : CtrFormularioAlumno\u003c/div\u003e\u003c/br\u003e",
              "col2": "\u003cdiv title\u003d\"CtrFormularioAlumno\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_3_59501f0_1608293841281_13496_8480\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_29.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_3_59501f0_1608293841281_13496_8480\u0027);return false;\"\u003eCtrFormularioAlumno\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col3": " \u003c/br\u003e",
              "col4": " \u003c/br\u003e",
              "col5": " \u003c/br\u003e"
            },
            {
              "col0": "13 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\": Alumno\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_19.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e : Alumno\u003c/div\u003e\u003c/br\u003e",
              "col2": "\u003cdiv title\u003d\"Alumno\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1605993976012_184874_6364\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_5.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1605993976012_184874_6364\u0027);return false;\"\u003eAlumno\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col3": " \u003c/br\u003e",
              "col4": " \u003c/br\u003e",
              "col5": " \u003c/br\u003e"
            },
            {
              "col0": "14 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\": viewLogin\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_19.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e : viewLogin\u003c/div\u003e\u003c/br\u003e",
              "col2": "\u003cdiv title\u003d\"viewLogin\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_3_59501f0_1608289477847_206130_6495\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_32.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_3_59501f0_1608289477847_206130_6495\u0027);return false;\"\u003eviewLogin\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col3": " \u003c/br\u003e",
              "col4": " \u003c/br\u003e",
              "col5": " \u003c/br\u003e"
            },
            {
              "col0": "15 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\": CtrLogin\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_19.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e : CtrLogin\u003c/div\u003e\u003c/br\u003e",
              "col2": "\u003cdiv title\u003d\"CtrLogin\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_3_59501f0_1608289515343_915789_6522\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_29.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_3_59501f0_1608289515343_915789_6522\u0027);return false;\"\u003eCtrLogin\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col3": " \u003c/br\u003e",
              "col4": " \u003c/br\u003e",
              "col5": " \u003c/br\u003e"
            },
            {
              "col0": "16 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\": viewRegistroAlumno\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_19.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e : viewRegistroAlumno\u003c/div\u003e\u003c/br\u003e",
              "col2": "\u003cdiv title\u003d\"viewRegistroAlumno\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_3_59501f0_1608293372778_521191_8219\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_32.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_3_59501f0_1608293372778_521191_8219\u0027);return false;\"\u003eviewRegistroAlumno\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col3": " \u003c/br\u003e",
              "col4": " \u003c/br\u003e",
              "col5": " \u003c/br\u003e"
            },
            {
              "col0": "17 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\": CtrRegistroAlumno\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_19.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e : CtrRegistroAlumno\u003c/div\u003e\u003c/br\u003e",
              "col2": "\u003cdiv title\u003d\"CtrRegistroAlumno\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_3_59501f0_1608293473162_613833_8246\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_29.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_3_59501f0_1608293473162_613833_8246\u0027);return false;\"\u003eCtrRegistroAlumno\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col3": " \u003c/br\u003e",
              "col4": " \u003c/br\u003e",
              "col5": " \u003c/br\u003e"
            },
            {
              "col0": "18 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\": viewFormularioAlumno\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_19.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e : viewFormularioAlumno\u003c/div\u003e\u003c/br\u003e",
              "col2": "\u003cdiv title\u003d\"viewFormularioAlumno\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_3_59501f0_1608293701904_601119_8368\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_32.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_3_59501f0_1608293701904_601119_8368\u0027);return false;\"\u003eviewFormularioAlumno\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col3": " \u003c/br\u003e",
              "col4": " \u003c/br\u003e",
              "col5": " \u003c/br\u003e"
            },
            {
              "col0": "19 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\": CtrFormularioAlumno\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_19.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e : CtrFormularioAlumno\u003c/div\u003e\u003c/br\u003e",
              "col2": "\u003cdiv title\u003d\"CtrFormularioAlumno\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_3_59501f0_1608293841281_13496_8480\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_29.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_3_59501f0_1608293841281_13496_8480\u0027);return false;\"\u003eCtrFormularioAlumno\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col3": " \u003c/br\u003e",
              "col4": " \u003c/br\u003e",
              "col5": " \u003c/br\u003e"
            },
            {
              "col0": "20 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\"Base de datos\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_19.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e Base de datos\u003c/div\u003e\u003c/br\u003e",
              "col2": " \u003c/br\u003e",
              "col3": " \u003c/br\u003e",
              "col4": " \u003c/br\u003e",
              "col5": " \u003c/br\u003e"
            }
          ]
        },
        "columns": [
          {
            "text": "# ",
            "dataIndex": "col0",
            "flex": 0,
            "width": 96
          },
          {
            "text": "Name ",
            "dataIndex": "col1",
            "flex": 0,
            "width": 300
          },
          {
            "text": "Type ",
            "dataIndex": "col2",
            "flex": 0,
            "width": 300
          },
          {
            "text": "Multiplicity ",
            "dataIndex": "col3",
            "flex": 0,
            "width": 156
          },
          {
            "text": "Default value ",
            "dataIndex": "col4",
            "flex": 0,
            "width": 168
          },
          {
            "text": "Documentation ",
            "dataIndex": "col5",
            "flex": 1,
            "width": -1
          }
        ],
        "collapsible": true
      }
    ],
    "image_panel": [
      {
        "title": "Registro usuarios externos",
        "image": "diagrams/diagram_Architecture___19_0_3_5c401fe_1608572688423_955999_8499.png",
        "width": 1536,
        "height": 857,
        "collapsible": true,
        "map": {}
      },
      {
        "title": "Registro usuarios externos_imported",
        "image": "diagrams/diagram_Architecture___19_0_3_5c401fe_1608572688430_613157_8520.png",
        "width": 1393,
        "height": 812,
        "collapsible": true,
        "map": {}
      },
      {
        "title": "Registro usuarios externos_imported1",
        "image": "diagrams/diagram_Architecture___19_0_3_5c401fe_1608572688436_806593_8541.png",
        "width": 1393,
        "height": 812,
        "collapsible": true,
        "map": {}
      }
    ]
  },
  "Diagrams___19_0_3_59501f0_1608294026196_162693_8568": {
    "title": "Registro usuarios externos-ALTERNATIVO",
    "path": "\u003cdiv title\u003d\"Casos de uso\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_3_59501f0_1605898693468_780946_4813\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_3_59501f0_1605898693468_780946_4813\u0027);return false;\"\u003eCasos de uso\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Subsistema Identificación\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1605991759147_968139_5028\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1605991759147_968139_5028\u0027);return false;\"\u003eSubsistema Identificación\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Registro\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_3_5c401fe_1605961577356_539243_4912\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_6.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_3_5c401fe_1605961577356_539243_4912\u0027);return false;\"\u003eRegistro\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Registro usuarios externos-ALTERNATIVO\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_3_59501f0_1608294026196_663096_8569\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_7.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_3_59501f0_1608294026196_663096_8569\u0027);return false;\"\u003eRegistro usuarios externos-ALTERNATIVO\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Registro usuarios externos-ALTERNATIVO\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Diagrams___19_0_3_59501f0_1608294026196_162693_8568\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_18.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Diagrams___19_0_3_59501f0_1608294026196_162693_8568\u0027);return false;\"\u003eRegistro usuarios externos-ALTERNATIVO\u003ca\u003e\u003c/div\u003e",
    "html_panel": [],
    "grid_panel": [],
    "image_panel": [
      {
        "title": "",
        "image": "diagrams/diagram_Diagrams___19_0_3_59501f0_1608294026202_803459_8590.png",
        "width": 1316,
        "height": 812,
        "collapsible": false,
        "map": {}
      }
    ]
  },
  "EmptyContent___19_0_3_59501f0_1608294026196_663096_8569": {
    "title": "Registro usuarios externos-ALTERNATIVO",
    "path": "\u003cdiv title\u003d\"Casos de uso\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_3_59501f0_1605898693468_780946_4813\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_3_59501f0_1605898693468_780946_4813\u0027);return false;\"\u003eCasos de uso\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Subsistema Identificación\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1605991759147_968139_5028\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1605991759147_968139_5028\u0027);return false;\"\u003eSubsistema Identificación\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Registro\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_3_5c401fe_1605961577356_539243_4912\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_6.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_3_5c401fe_1605961577356_539243_4912\u0027);return false;\"\u003eRegistro\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Registro usuarios externos-ALTERNATIVO\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_3_59501f0_1608294026196_663096_8569\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_7.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_3_59501f0_1608294026196_663096_8569\u0027);return false;\"\u003eRegistro usuarios externos-ALTERNATIVO\u003ca\u003e\u003c/div\u003e",
    "html_panel": [],
    "grid_panel": [],
    "image_panel": []
  },
  "Diagrams___19_0_3_5c401fe_1605961280982_806754_5372": {
    "title": "Reportar",
    "path": "\u003cdiv title\u003d\"Casos de uso\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_3_59501f0_1605898693468_780946_4813\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_3_59501f0_1605898693468_780946_4813\u0027);return false;\"\u003eCasos de uso\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Subsistema Foro\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1605975887729_200757_5237\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1605975887729_200757_5237\u0027);return false;\"\u003eSubsistema Foro\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Reportar\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_3_5c401fe_1605960559088_714923_5217\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_6.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_3_5c401fe_1605960559088_714923_5217\u0027);return false;\"\u003eReportar\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Reportar\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_3_5c401fe_1605961280981_952124_5371\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_17.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_3_5c401fe_1605961280981_952124_5371\u0027);return false;\"\u003eReportar\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Reportar\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Diagrams___19_0_3_5c401fe_1605961280982_806754_5372\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_16.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Diagrams___19_0_3_5c401fe_1605961280982_806754_5372\u0027);return false;\"\u003eReportar\u003ca\u003e\u003c/div\u003e",
    "html_panel": [],
    "grid_panel": [],
    "image_panel": [
      {
        "title": "",
        "image": "diagrams/diagram_Diagrams___19_0_3_5c401fe_1605961280985_276681_5392.png",
        "width": 251,
        "height": 575,
        "collapsible": false,
        "map": {}
      }
    ]
  },
  "EmptyContent___19_0_3_5c401fe_1605960559088_714923_5217": {
    "title": "Reportar",
    "path": "\u003cdiv title\u003d\"Casos de uso\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_3_59501f0_1605898693468_780946_4813\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_3_59501f0_1605898693468_780946_4813\u0027);return false;\"\u003eCasos de uso\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Subsistema Foro\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1605975887729_200757_5237\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1605975887729_200757_5237\u0027);return false;\"\u003eSubsistema Foro\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Reportar\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_3_5c401fe_1605960559088_714923_5217\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_6.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_3_5c401fe_1605960559088_714923_5217\u0027);return false;\"\u003eReportar\u003ca\u003e\u003c/div\u003e",
    "html_panel": [],
    "grid_panel": [],
    "image_panel": []
  },
  "EmptyContent___19_0_3_5c401fe_1605961280981_952124_5371": {
    "title": "Reportar",
    "path": "\u003cdiv title\u003d\"Casos de uso\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_3_59501f0_1605898693468_780946_4813\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_3_59501f0_1605898693468_780946_4813\u0027);return false;\"\u003eCasos de uso\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Subsistema Foro\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1605975887729_200757_5237\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1605975887729_200757_5237\u0027);return false;\"\u003eSubsistema Foro\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Reportar\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_3_5c401fe_1605960559088_714923_5217\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_6.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_3_5c401fe_1605960559088_714923_5217\u0027);return false;\"\u003eReportar\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Reportar\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_3_5c401fe_1605961280981_952124_5371\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_17.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_3_5c401fe_1605961280981_952124_5371\u0027);return false;\"\u003eReportar\u003ca\u003e\u003c/div\u003e",
    "html_panel": [],
    "grid_panel": [],
    "image_panel": []
  },
  "Glossary___19_0_4_65b021b_1608503345921_285444_7481": {
    "title": "Seminario online",
    "path": "\u003cdiv title\u003d\"Documentacion del Proyecto Entrega 2\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1608491267549_161671_7569\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1608491267549_161671_7569\u0027);return false;\"\u003eDocumentacion del Proyecto Entrega 2\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"2. Glosario\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_65b021b_1608502989614_109664_7440\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_65b021b_1608502989614_109664_7440\u0027);return false;\"\u003e2. Glosario\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Seminario online\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Glossary___19_0_4_65b021b_1608503345921_285444_7481\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_31.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Glossary___19_0_4_65b021b_1608503345921_285444_7481\u0027);return false;\"\u003eSeminario online\u003ca\u003e\u003c/div\u003e",
    "html_panel": [],
    "grid_panel": [
      {
        "title": "Characteristics ",
        "hideHeaders": true,
        "data_store": {
          "fields": [
            "col0",
            "col1"
          ],
          "data": [
            {
              "col0": "Term ",
              "col1": "\u003cdiv title\u003d\"Seminario online\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Glossary___19_0_4_65b021b_1608503345921_285444_7481\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_31.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Glossary___19_0_4_65b021b_1608503345921_285444_7481\u0027);return false;\"\u003eSeminario online\u003ca\u003e\u003c/div\u003e"
            },
            {
              "col0": "Description ",
              "col1": "Son eventos en los que los participantes se unen para poder obtener informacion y/o participar. Este es organizado por un profesor u ONG. "
            }
          ]
        },
        "columns": [
          {
            "text": "col0",
            "dataIndex": "col0",
            "flex": 0,
            "width": 192
          },
          {
            "text": "col1",
            "dataIndex": "col1",
            "flex": 1,
            "width": -1
          }
        ],
        "collapsible": false
      }
    ],
    "image_panel": []
  },
  "EmptyContent___19_0_4_7c8024c_1605979033648_450401_5796": {
    "title": "Subir Documento",
    "path": "\u003cdiv title\u003d\"Casos de uso\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_3_59501f0_1605898693468_780946_4813\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_3_59501f0_1605898693468_780946_4813\u0027);return false;\"\u003eCasos de uso\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Subsistema Actividades\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1605993744465_299768_6146\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1605993744465_299768_6146\u0027);return false;\"\u003eSubsistema Actividades\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Subir Documento\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1605979033648_450401_5796\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_6.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1605979033648_450401_5796\u0027);return false;\"\u003eSubir Documento\u003ca\u003e\u003c/div\u003e",
    "html_panel": [],
    "grid_panel": [],
    "image_panel": []
  },
  "Package___19_0_4_7c8024c_1605993744465_299768_6146": {
    "title": "Subsistema Actividades",
    "path": "\u003cdiv title\u003d\"Casos de uso\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_3_59501f0_1605898693468_780946_4813\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_3_59501f0_1605898693468_780946_4813\u0027);return false;\"\u003eCasos de uso\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Subsistema Actividades\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1605993744465_299768_6146\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1605993744465_299768_6146\u0027);return false;\"\u003eSubsistema Actividades\u003ca\u003e\u003c/div\u003e",
    "html_panel": [],
    "grid_panel": [],
    "image_panel": []
  },
  "Package___19_0_4_7c8024c_1606045080271_940524_6239": {
    "title": "Subsistema Curso",
    "path": "\u003cdiv title\u003d\"Casos de uso\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_3_59501f0_1605898693468_780946_4813\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_3_59501f0_1605898693468_780946_4813\u0027);return false;\"\u003eCasos de uso\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Subsistema Curso\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1606045080271_940524_6239\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1606045080271_940524_6239\u0027);return false;\"\u003eSubsistema Curso\u003ca\u003e\u003c/div\u003e",
    "html_panel": [],
    "grid_panel": [],
    "image_panel": []
  },
  "Package___19_0_4_7c8024c_1605975887729_200757_5237": {
    "title": "Subsistema Foro",
    "path": "\u003cdiv title\u003d\"Casos de uso\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_3_59501f0_1605898693468_780946_4813\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_3_59501f0_1605898693468_780946_4813\u0027);return false;\"\u003eCasos de uso\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Subsistema Foro\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1605975887729_200757_5237\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1605975887729_200757_5237\u0027);return false;\"\u003eSubsistema Foro\u003ca\u003e\u003c/div\u003e",
    "html_panel": [],
    "grid_panel": [],
    "image_panel": []
  },
  "Package___19_0_4_7c8024c_1605991759147_968139_5028": {
    "title": "Subsistema Identificación",
    "path": "\u003cdiv title\u003d\"Casos de uso\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_3_59501f0_1605898693468_780946_4813\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_3_59501f0_1605898693468_780946_4813\u0027);return false;\"\u003eCasos de uso\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Subsistema Identificación\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1605991759147_968139_5028\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1605991759147_968139_5028\u0027);return false;\"\u003eSubsistema Identificación\u003ca\u003e\u003c/div\u003e",
    "html_panel": [],
    "grid_panel": [],
    "image_panel": []
  },
  "Package___19_0_4_7c8024c_1608419403729_110276_7054": {
    "title": "Subsistema Tareas",
    "path": "\u003cdiv title\u003d\"Casos de uso\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_3_59501f0_1605898693468_780946_4813\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_3_59501f0_1605898693468_780946_4813\u0027);return false;\"\u003eCasos de uso\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Subsistema Tareas\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1608419403729_110276_7054\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1608419403729_110276_7054\u0027);return false;\"\u003eSubsistema Tareas\u003ca\u003e\u003c/div\u003e",
    "html_panel": [],
    "grid_panel": [],
    "image_panel": []
  },
  "Glossary___19_0_4_65b021b_1608503285310_207417_7476": {
    "title": "Tema",
    "path": "\u003cdiv title\u003d\"Documentacion del Proyecto Entrega 2\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1608491267549_161671_7569\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1608491267549_161671_7569\u0027);return false;\"\u003eDocumentacion del Proyecto Entrega 2\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"2. Glosario\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_65b021b_1608502989614_109664_7440\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_65b021b_1608502989614_109664_7440\u0027);return false;\"\u003e2. Glosario\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Tema\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Glossary___19_0_4_65b021b_1608503285310_207417_7476\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_31.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Glossary___19_0_4_65b021b_1608503285310_207417_7476\u0027);return false;\"\u003eTema\u003ca\u003e\u003c/div\u003e",
    "html_panel": [],
    "grid_panel": [
      {
        "title": "Characteristics ",
        "hideHeaders": true,
        "data_store": {
          "fields": [
            "col0",
            "col1"
          ],
          "data": [
            {
              "col0": "Term ",
              "col1": "\u003cdiv title\u003d\"Tema\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Glossary___19_0_4_65b021b_1608503285310_207417_7476\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_31.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Glossary___19_0_4_65b021b_1608503285310_207417_7476\u0027);return false;\"\u003eTema\u003ca\u003e\u003c/div\u003e"
            },
            {
              "col0": "Description ",
              "col1": "Son cada uno de los nuevos grupos de mensajes que se incluyen en el foro "
            }
          ]
        },
        "columns": [
          {
            "text": "col0",
            "dataIndex": "col0",
            "flex": 0,
            "width": 192
          },
          {
            "text": "col1",
            "dataIndex": "col1",
            "flex": 1,
            "width": -1
          }
        ],
        "collapsible": false
      }
    ],
    "image_panel": []
  },
  "Requirement___19_0_4_7c8024c_1605992040306_840570_5282": {
    "title": "UMA",
    "path": "\u003cdiv title\u003d\"Casos de uso\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_3_59501f0_1605898693468_780946_4813\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_3_59501f0_1605898693468_780946_4813\u0027);return false;\"\u003eCasos de uso\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Actores\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1606045670559_892273_6448\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1606045670559_892273_6448\u0027);return false;\"\u003eActores\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"UMA\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1605992040306_840570_5282\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_5.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1605992040306_840570_5282\u0027);return false;\"\u003eUMA\u003ca\u003e\u003c/div\u003e",
    "html_panel": [],
    "grid_panel": [
      {
        "title": "Characteristics ",
        "hideHeaders": true,
        "data_store": {
          "fields": [
            "col0",
            "col1"
          ],
          "data": [
            {
              "col0": "Name ",
              "col1": "\u003cdiv title\u003d\"UMA\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1605992040306_840570_5282\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_5.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1605992040306_840570_5282\u0027);return false;\"\u003eUMA\u003ca\u003e\u003c/div\u003e"
            }
          ]
        },
        "columns": [
          {
            "text": "col0",
            "dataIndex": "col0",
            "flex": 0,
            "width": 192
          },
          {
            "text": "col1",
            "dataIndex": "col1",
            "flex": 1,
            "width": -1
          }
        ],
        "collapsible": true
      },
      {
        "title": "Use Cases",
        "hideHeaders": false,
        "data_store": {
          "fields": [
            "col0",
            "col1",
            "col2"
          ],
          "data": [
            {
              "col0": "1 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\"Registro UMA\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_3_59501f0_1605902127572_774616_5723\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_6.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_3_59501f0_1605902127572_774616_5723\u0027);return false;\"\u003eRegistro UMA\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col2": " \u003c/br\u003e"
            }
          ]
        },
        "columns": [
          {
            "text": "# ",
            "dataIndex": "col0",
            "flex": 0,
            "width": 84
          },
          {
            "text": "Name ",
            "dataIndex": "col1",
            "flex": 0,
            "width": 300
          },
          {
            "text": "Documentation ",
            "dataIndex": "col2",
            "flex": 1,
            "width": -1
          }
        ],
        "collapsible": true
      }
    ],
    "image_panel": []
  },
  "Glossary___19_0_4_65b021b_1608501577265_885294_7386": {
    "title": "Usuario",
    "path": "\u003cdiv title\u003d\"Documentacion del Proyecto Entrega 2\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1608491267549_161671_7569\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1608491267549_161671_7569\u0027);return false;\"\u003eDocumentacion del Proyecto Entrega 2\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"2. Glosario\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_65b021b_1608502989614_109664_7440\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_65b021b_1608502989614_109664_7440\u0027);return false;\"\u003e2. Glosario\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Usuario\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Glossary___19_0_4_65b021b_1608501577265_885294_7386\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_31.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Glossary___19_0_4_65b021b_1608501577265_885294_7386\u0027);return false;\"\u003eUsuario\u003ca\u003e\u003c/div\u003e",
    "html_panel": [],
    "grid_panel": [
      {
        "title": "Characteristics ",
        "hideHeaders": true,
        "data_store": {
          "fields": [
            "col0",
            "col1"
          ],
          "data": [
            {
              "col0": "Term ",
              "col1": "\u003cdiv title\u003d\"Usuario\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Glossary___19_0_4_65b021b_1608501577265_885294_7386\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_31.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Glossary___19_0_4_65b021b_1608501577265_885294_7386\u0027);return false;\"\u003eUsuario\u003ca\u003e\u003c/div\u003e"
            },
            {
              "col0": "Description ",
              "col1": "Son los distintos perfiles que pueden usar la plataforma. Los tipos de usuario son: Administrador, ONG, Profesor, Alumno y usuario externo. "
            }
          ]
        },
        "columns": [
          {
            "text": "col0",
            "dataIndex": "col0",
            "flex": 0,
            "width": 192
          },
          {
            "text": "col1",
            "dataIndex": "col1",
            "flex": 1,
            "width": -1
          }
        ],
        "collapsible": false
      }
    ],
    "image_panel": []
  },
  "Requirement___19_0_3_59501f0_1605899611767_786078_4829": {
    "title": "Validar Acceso",
    "path": "\u003cdiv title\u003d\"Casos de uso\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_3_59501f0_1605898693468_780946_4813\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_3_59501f0_1605898693468_780946_4813\u0027);return false;\"\u003eCasos de uso\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Subsistema Identificación\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1605991759147_968139_5028\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1605991759147_968139_5028\u0027);return false;\"\u003eSubsistema Identificación\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Validar Acceso\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_3_59501f0_1605899611767_786078_4829\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_6.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_3_59501f0_1605899611767_786078_4829\u0027);return false;\"\u003eValidar Acceso\u003ca\u003e\u003c/div\u003e",
    "html_panel": [],
    "grid_panel": [
      {
        "title": "Characteristics ",
        "hideHeaders": true,
        "data_store": {
          "fields": [
            "col0",
            "col1"
          ],
          "data": [
            {
              "col0": "Name ",
              "col1": "\u003cdiv title\u003d\"Validar Acceso\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_3_59501f0_1605899611767_786078_4829\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_6.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_3_59501f0_1605899611767_786078_4829\u0027);return false;\"\u003eValidar Acceso\u003ca\u003e\u003c/div\u003e"
            }
          ]
        },
        "columns": [
          {
            "text": "col0",
            "dataIndex": "col0",
            "flex": 0,
            "width": 192
          },
          {
            "text": "col1",
            "dataIndex": "col1",
            "flex": 1,
            "width": -1
          }
        ],
        "collapsible": true
      },
      {
        "title": "Actors",
        "hideHeaders": false,
        "data_store": {
          "fields": [
            "col0",
            "col1",
            "col2"
          ],
          "data": [
            {
              "col0": "1 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\"Administrador\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1606046179164_726532_6549\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_5.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1606046179164_726532_6549\u0027);return false;\"\u003eAdministrador\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col2": " \u003c/br\u003e"
            },
            {
              "col0": "2 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\"Organizacion\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1605993976012_561063_6365\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_5.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1605993976012_561063_6365\u0027);return false;\"\u003eOrganizacion\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col2": " \u003c/br\u003e"
            },
            {
              "col0": "3 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\"instructor\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1608378644060_454646_6215\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_5.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1608378644060_454646_6215\u0027);return false;\"\u003einstructor\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col2": " \u003c/br\u003e"
            },
            {
              "col0": "4 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\"Alumno\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1605993976012_184874_6364\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_5.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1605993976012_184874_6364\u0027);return false;\"\u003eAlumno\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col2": " \u003c/br\u003e"
            },
            {
              "col0": "5 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\"Instructor\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1605993976013_127053_6366\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_5.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1605993976013_127053_6366\u0027);return false;\"\u003eInstructor\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col2": " \u003c/br\u003e"
            },
            {
              "col0": "6 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\"UMA\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1605992040306_840570_5282\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_5.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1605992040306_840570_5282\u0027);return false;\"\u003eUMA\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col2": " \u003c/br\u003e"
            }
          ]
        },
        "columns": [
          {
            "text": "# ",
            "dataIndex": "col0",
            "flex": 0,
            "width": 84
          },
          {
            "text": "Name ",
            "dataIndex": "col1",
            "flex": 0,
            "width": 300
          },
          {
            "text": "Documentation ",
            "dataIndex": "col2",
            "flex": 1,
            "width": -1
          }
        ],
        "collapsible": true
      },
      {
        "title": "Owned Behaviors",
        "hideHeaders": false,
        "data_store": {
          "fields": [
            "col0",
            "col1",
            "col2"
          ],
          "data": [
            {
              "col0": "1 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\"Validar Acceso\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_3_59501f0_1605899632676_796119_4843\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_17.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_3_59501f0_1605899632676_796119_4843\u0027);return false;\"\u003eValidar Acceso\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col2": " \u003c/br\u003e"
            },
            {
              "col0": "2 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\"Sec. validar acceso\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_5b201fd_1608465754773_719055_7322\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_7.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_5b201fd_1608465754773_719055_7322\u0027);return false;\"\u003eSec. validar acceso\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col2": " \u003c/br\u003e"
            },
            {
              "col0": "3 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\"Sec. validar acceso alternativo\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_5b201fd_1608467797407_155218_7907\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_7.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_5b201fd_1608467797407_155218_7907\u0027);return false;\"\u003eSec. validar acceso alternativo\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col2": " \u003c/br\u003e"
            }
          ]
        },
        "columns": [
          {
            "text": "# ",
            "dataIndex": "col0",
            "flex": 0,
            "width": 84
          },
          {
            "text": "Name ",
            "dataIndex": "col1",
            "flex": 0,
            "width": 300
          },
          {
            "text": "Documentation ",
            "dataIndex": "col2",
            "flex": 1,
            "width": -1
          }
        ],
        "collapsible": true
      },
      {
        "title": "Scenario - Basic Flow ",
        "hideHeaders": true,
        "data_store": {
          "fields": [
            "col0"
          ],
          "data": [
            {
              "col0": "1. El usuario solicita conectar a la aplicacion con su cuenta de usuario "
            },
            {
              "col0": "2. El sistema solicita datos de usuario "
            }
          ]
        },
        "columns": [
          {
            "text": "col0",
            "dataIndex": "col0",
            "flex": 1,
            "width": -1
          }
        ],
        "collapsible": true
      }
    ],
    "image_panel": []
  },
  "Requirement___19_0_4_8cb0287_1606043062428_844297_5553": {
    "title": "Ver actividad",
    "path": "\u003cdiv title\u003d\"Casos de uso\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_3_59501f0_1605898693468_780946_4813\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_3_59501f0_1605898693468_780946_4813\u0027);return false;\"\u003eCasos de uso\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Subsistema Actividades\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1605993744465_299768_6146\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1605993744465_299768_6146\u0027);return false;\"\u003eSubsistema Actividades\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Ver actividad\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_8cb0287_1606043062428_844297_5553\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_6.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_8cb0287_1606043062428_844297_5553\u0027);return false;\"\u003eVer actividad\u003ca\u003e\u003c/div\u003e",
    "html_panel": [],
    "grid_panel": [
      {
        "title": "Characteristics ",
        "hideHeaders": true,
        "data_store": {
          "fields": [
            "col0",
            "col1"
          ],
          "data": [
            {
              "col0": "Name ",
              "col1": "\u003cdiv title\u003d\"Ver actividad\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_8cb0287_1606043062428_844297_5553\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_6.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_8cb0287_1606043062428_844297_5553\u0027);return false;\"\u003eVer actividad\u003ca\u003e\u003c/div\u003e"
            }
          ]
        },
        "columns": [
          {
            "text": "col0",
            "dataIndex": "col0",
            "flex": 0,
            "width": 192
          },
          {
            "text": "col1",
            "dataIndex": "col1",
            "flex": 1,
            "width": -1
          }
        ],
        "collapsible": true
      },
      {
        "title": "Actors",
        "hideHeaders": false,
        "data_store": {
          "fields": [
            "col0",
            "col1",
            "col2"
          ],
          "data": [
            {
              "col0": "1 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\"Administrador\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1606046179164_726532_6549\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_5.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1606046179164_726532_6549\u0027);return false;\"\u003eAdministrador\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col2": " \u003c/br\u003e"
            },
            {
              "col0": "2 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\"Organizacion\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1605993976012_561063_6365\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_5.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1605993976012_561063_6365\u0027);return false;\"\u003eOrganizacion\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col2": " \u003c/br\u003e"
            },
            {
              "col0": "3 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\"instructor\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1608378644060_454646_6215\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_5.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1608378644060_454646_6215\u0027);return false;\"\u003einstructor\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col2": " \u003c/br\u003e"
            },
            {
              "col0": "4 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\"Alumno\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1605993976012_184874_6364\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_5.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1605993976012_184874_6364\u0027);return false;\"\u003eAlumno\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col2": " \u003c/br\u003e"
            },
            {
              "col0": "5 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\"Instructor\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1605993976013_127053_6366\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_5.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1605993976013_127053_6366\u0027);return false;\"\u003eInstructor\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col2": " \u003c/br\u003e"
            },
            {
              "col0": "6 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\"UMA\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1605992040306_840570_5282\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_5.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1605992040306_840570_5282\u0027);return false;\"\u003eUMA\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col2": " \u003c/br\u003e"
            }
          ]
        },
        "columns": [
          {
            "text": "# ",
            "dataIndex": "col0",
            "flex": 0,
            "width": 84
          },
          {
            "text": "Name ",
            "dataIndex": "col1",
            "flex": 0,
            "width": 300
          },
          {
            "text": "Documentation ",
            "dataIndex": "col2",
            "flex": 1,
            "width": -1
          }
        ],
        "collapsible": true
      },
      {
        "title": "Owned Behaviors",
        "hideHeaders": false,
        "data_store": {
          "fields": [
            "col0",
            "col1",
            "col2"
          ],
          "data": [
            {
              "col0": "1 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\"Ver actividad\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_8cb0287_1606043074829_146602_5567\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_17.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_8cb0287_1606043074829_146602_5567\u0027);return false;\"\u003eVer actividad\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col2": " \u003c/br\u003e"
            }
          ]
        },
        "columns": [
          {
            "text": "# ",
            "dataIndex": "col0",
            "flex": 0,
            "width": 84
          },
          {
            "text": "Name ",
            "dataIndex": "col1",
            "flex": 0,
            "width": 300
          },
          {
            "text": "Documentation ",
            "dataIndex": "col2",
            "flex": 1,
            "width": -1
          }
        ],
        "collapsible": true
      },
      {
        "title": "Scenario - Basic Flow ",
        "hideHeaders": true,
        "data_store": {
          "fields": [
            "col0"
          ],
          "data": [
            {
              "col0": "1. El usuario selecciona una actividad "
            },
            {
              "col0": "2. El sistema muestra al usuario la información de la actividad "
            }
          ]
        },
        "columns": [
          {
            "text": "col0",
            "dataIndex": "col0",
            "flex": 1,
            "width": -1
          }
        ],
        "collapsible": true
      }
    ],
    "image_panel": []
  },
  "Architecture___19_0_4_5b201fd_1608472146728_379966_9598": {
    "title": "ViewCalendario",
    "path": "\u003cdiv title\u003d\"Estructura\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1606752452637_33243_5229\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1606752452637_33243_5229\u0027);return false;\"\u003eEstructura\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Interfaz\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1608218581306_512639_5238\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1608218581306_512639_5238\u0027);return false;\"\u003eInterfaz\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"ViewCalendario\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_4_5b201fd_1608472146728_379966_9598\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_32.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_4_5b201fd_1608472146728_379966_9598\u0027);return false;\"\u003eViewCalendario\u003ca\u003e\u003c/div\u003e",
    "html_panel": [],
    "grid_panel": [
      {
        "title": "Characteristics ",
        "hideHeaders": true,
        "data_store": {
          "fields": [
            "col0",
            "col1"
          ],
          "data": [
            {
              "col0": "Name ",
              "col1": "\u003cdiv title\u003d\"ViewCalendario\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_4_5b201fd_1608472146728_379966_9598\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_32.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Architecture___19_0_4_5b201fd_1608472146728_379966_9598\u0027);return false;\"\u003eViewCalendario\u003ca\u003e\u003c/div\u003e"
            }
          ]
        },
        "columns": [
          {
            "text": "col0",
            "dataIndex": "col0",
            "flex": 0,
            "width": 192
          },
          {
            "text": "col1",
            "dataIndex": "col1",
            "flex": 1,
            "width": -1
          }
        ],
        "collapsible": false
      }
    ],
    "image_panel": []
  },
  "Requirement___19_0_4_7c8024c_1606044881557_892467_5370": {
    "title": "Visualizar clases grabadas",
    "path": "\u003cdiv title\u003d\"Casos de uso\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_3_59501f0_1605898693468_780946_4813\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_3_59501f0_1605898693468_780946_4813\u0027);return false;\"\u003eCasos de uso\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Subsistema Curso\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1606045080271_940524_6239\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_4.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Package___19_0_4_7c8024c_1606045080271_940524_6239\u0027);return false;\"\u003eSubsistema Curso\u003ca\u003e\u003c/div\u003e / \u003cdiv title\u003d\"Visualizar clases grabadas\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1606044881557_892467_5370\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_6.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1606044881557_892467_5370\u0027);return false;\"\u003eVisualizar clases grabadas\u003ca\u003e\u003c/div\u003e",
    "html_panel": [],
    "grid_panel": [
      {
        "title": "Characteristics ",
        "hideHeaders": true,
        "data_store": {
          "fields": [
            "col0",
            "col1"
          ],
          "data": [
            {
              "col0": "Name ",
              "col1": "\u003cdiv title\u003d\"Visualizar clases grabadas\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1606044881557_892467_5370\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_6.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1606044881557_892467_5370\u0027);return false;\"\u003eVisualizar clases grabadas\u003ca\u003e\u003c/div\u003e"
            }
          ]
        },
        "columns": [
          {
            "text": "col0",
            "dataIndex": "col0",
            "flex": 0,
            "width": 192
          },
          {
            "text": "col1",
            "dataIndex": "col1",
            "flex": 1,
            "width": -1
          }
        ],
        "collapsible": true
      },
      {
        "title": "Actors",
        "hideHeaders": false,
        "data_store": {
          "fields": [
            "col0",
            "col1",
            "col2"
          ],
          "data": [
            {
              "col0": "1 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\"Administrador\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1606046179164_726532_6549\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_5.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1606046179164_726532_6549\u0027);return false;\"\u003eAdministrador\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col2": " \u003c/br\u003e"
            },
            {
              "col0": "2 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\"Organizacion\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1605993976012_561063_6365\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_5.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1605993976012_561063_6365\u0027);return false;\"\u003eOrganizacion\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col2": " \u003c/br\u003e"
            },
            {
              "col0": "3 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\"instructor\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1608378644060_454646_6215\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_5.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1608378644060_454646_6215\u0027);return false;\"\u003einstructor\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col2": " \u003c/br\u003e"
            },
            {
              "col0": "4 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\"Alumno\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1605993976012_184874_6364\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_5.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1605993976012_184874_6364\u0027);return false;\"\u003eAlumno\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col2": " \u003c/br\u003e"
            },
            {
              "col0": "5 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\"Instructor\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1605993976013_127053_6366\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_5.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1605993976013_127053_6366\u0027);return false;\"\u003eInstructor\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col2": " \u003c/br\u003e"
            },
            {
              "col0": "6 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\"UMA\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1605992040306_840570_5282\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_5.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1605992040306_840570_5282\u0027);return false;\"\u003eUMA\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col2": " \u003c/br\u003e"
            }
          ]
        },
        "columns": [
          {
            "text": "# ",
            "dataIndex": "col0",
            "flex": 0,
            "width": 84
          },
          {
            "text": "Name ",
            "dataIndex": "col1",
            "flex": 0,
            "width": 300
          },
          {
            "text": "Documentation ",
            "dataIndex": "col2",
            "flex": 1,
            "width": -1
          }
        ],
        "collapsible": true
      },
      {
        "title": "Owned Behaviors",
        "hideHeaders": false,
        "data_store": {
          "fields": [
            "col0",
            "col1",
            "col2"
          ],
          "data": [
            {
              "col0": "1 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\"Visualizar clases grabadas\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1606044881586_229270_5386\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_17.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1606044881586_229270_5386\u0027);return false;\"\u003eVisualizar clases grabadas\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col2": " \u003c/br\u003e"
            },
            {
              "col0": "2 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\"Visualizar clases grabadas\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1608378644159_615997_6404\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_7.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1608378644159_615997_6404\u0027);return false;\"\u003eVisualizar clases grabadas\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col2": " \u003c/br\u003e"
            },
            {
              "col0": "3 \u003c/br\u003e",
              "col1": "\u003cdiv title\u003d\"Visualizar clases grabadasAlter\" style\u003d\"display: inline !important; white-space: nowrap !important; height: 20px;\"\u003e\u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1608397299094_279549_7274\u0027);return false;\"\u003e\u003cspan style\u003d\"vertical-align: middle;\"\u003e\u003cimg src\u003d\u0027images/icon_7.png\u0027 width\u003d\u002716\u0027 height\u003d\u002716\u0027 title\u003d\u0027\u0027 style\u003d\"vertical-align: bottom;\"\u003e\u003c/span\u003e\u003ca\u003e \u003ca href\u003d\"\" target\u003d\"_blank\" onclick\u003d\"navigate(\u0027Requirement___19_0_4_7c8024c_1608397299094_279549_7274\u0027);return false;\"\u003eVisualizar clases grabadasAlter\u003ca\u003e\u003c/div\u003e\u003c/br\u003e",
              "col2": " \u003c/br\u003e"
            }
          ]
        },
        "columns": [
          {
            "text": "# ",
            "dataIndex": "col0",
            "flex": 0,
            "width": 84
          },
          {
            "text": "Name ",
            "dataIndex": "col1",
            "flex": 0,
            "width": 300
          },
          {
            "text": "Documentation ",
            "dataIndex": "col2",
            "flex": 1,
            "width": -1
          }
        ],
        "collapsible": true
      },
      {
        "title": "Scenario - Basic Flow ",
        "hideHeaders": true,
        "data_store": {
          "fields": [
            "col0"
          ],
          "data": [
            {
              "col0": "1. El sistema muestra una lista de clases grabadas en una asignatura "
            },
            {
              "col0": "2. El usuario selecciona una grabación "
            },
            {
              "col0": "3. El sistema carga el video (A1) "
            },
            {
              "col0": "4. El usuario inicia el video "
            }
          ]
        },
        "columns": [
          {
            "text": "col0",
            "dataIndex": "col0",
            "flex": 1,
            "width": -1
          }
        ],
        "collapsible": true
      },
      {
        "title": "Scenario - Alternative Flow ",
        "hideHeaders": true,
        "data_store": {
          "fields": [
            "col0"
          ],
          "data": [
            {
              "col0": "3.1. Error al cargar el video "
            },
            {
              "col0": "    3.1.1. El sistema devuelve al usuario a la lista de seleccion "
            }
          ]
        },
        "columns": [
          {
            "text": "col0",
            "dataIndex": "col0",
            "flex": 1,
            "width": -1
          }
        ],
        "collapsible": true
      }
    ],
    "image_panel": []
  }
};
window.search_data_json = {
  "glossary": [
    {
      "id": "Glossary___19_0_4_65b021b_1608501810045_588967_7396",
      "name": "Alumno : \u003ci\u003eTerm\u003c/i\u003e",
      "type": "glossary"
    },
    {
      "id": "Glossary___19_0_4_65b021b_1608503037273_207154_7461",
      "name": "Calendario : \u003ci\u003eTerm\u003c/i\u003e",
      "type": "glossary"
    },
    {
      "id": "Glossary___19_0_4_65b021b_1608503622712_178899_7486",
      "name": "Clase grabada : \u003ci\u003eTerm\u003c/i\u003e",
      "type": "glossary"
    },
    {
      "id": "Glossary___19_0_4_65b021b_1608502518889_106459_7435",
      "name": "Curso : \u003ci\u003eTerm\u003c/i\u003e",
      "type": "glossary"
    },
    {
      "id": "Glossary___19_0_4_65b021b_1608503171947_946887_7466",
      "name": "Mensaje : \u003ci\u003eTerm\u003c/i\u003e",
      "type": "glossary"
    },
    {
      "id": "Glossary___19_0_4_65b021b_1608502085567_68231_7406",
      "name": "ONG : \u003ci\u003eTerm\u003c/i\u003e",
      "type": "glossary"
    },
    {
      "id": "Glossary___19_0_4_65b021b_1608502034739_934366_7401",
      "name": "Profesor : \u003ci\u003eTerm\u003c/i\u003e",
      "type": "glossary"
    },
    {
      "id": "Glossary___19_0_4_65b021b_1608503345921_285444_7481",
      "name": "Seminario online : \u003ci\u003eTerm\u003c/i\u003e",
      "type": "glossary"
    },
    {
      "id": "Glossary___19_0_4_65b021b_1608503285310_207417_7476",
      "name": "Tema : \u003ci\u003eTerm\u003c/i\u003e",
      "type": "glossary"
    },
    {
      "id": "Glossary___19_0_4_65b021b_1608501577265_885294_7386",
      "name": "Usuario : \u003ci\u003eTerm\u003c/i\u003e",
      "type": "glossary"
    }
  ],
  "all": [
    {
      "id": "Glossary___19_0_4_65b021b_1608501810045_588967_7396",
      "name": "Alumno : \u003ci\u003eTerm\u003c/i\u003e",
      "type": "glossary"
    },
    {
      "id": "Glossary___19_0_4_65b021b_1608503037273_207154_7461",
      "name": "Calendario : \u003ci\u003eTerm\u003c/i\u003e",
      "type": "glossary"
    },
    {
      "id": "Glossary___19_0_4_65b021b_1608503622712_178899_7486",
      "name": "Clase grabada : \u003ci\u003eTerm\u003c/i\u003e",
      "type": "glossary"
    },
    {
      "id": "Glossary___19_0_4_65b021b_1608502518889_106459_7435",
      "name": "Curso : \u003ci\u003eTerm\u003c/i\u003e",
      "type": "glossary"
    },
    {
      "id": "Glossary___19_0_4_65b021b_1608503171947_946887_7466",
      "name": "Mensaje : \u003ci\u003eTerm\u003c/i\u003e",
      "type": "glossary"
    },
    {
      "id": "Glossary___19_0_4_65b021b_1608502085567_68231_7406",
      "name": "ONG : \u003ci\u003eTerm\u003c/i\u003e",
      "type": "glossary"
    },
    {
      "id": "Glossary___19_0_4_65b021b_1608502034739_934366_7401",
      "name": "Profesor : \u003ci\u003eTerm\u003c/i\u003e",
      "type": "glossary"
    },
    {
      "id": "Glossary___19_0_4_65b021b_1608503345921_285444_7481",
      "name": "Seminario online : \u003ci\u003eTerm\u003c/i\u003e",
      "type": "glossary"
    },
    {
      "id": "Glossary___19_0_4_65b021b_1608503285310_207417_7476",
      "name": "Tema : \u003ci\u003eTerm\u003c/i\u003e",
      "type": "glossary"
    },
    {
      "id": "Glossary___19_0_4_65b021b_1608501577265_885294_7386",
      "name": "Usuario : \u003ci\u003eTerm\u003c/i\u003e",
      "type": "glossary"
    },
    {
      "id": "Requirement___19_0_4_7c8024c_1606044881570_420167_5379",
      "name": " : \u003ci\u003eActor\u003c/i\u003e",
      "type": "requirement"
    },
    {
      "id": "Requirement___19_0_4_7c8024c_1606044881556_666481_5369",
      "name": "CUD calificaciones opcionales : \u003ci\u003eUseCase\u003c/i\u003e",
      "type": "requirement"
    },
    {
      "id": "Requirement___19_0_3_5c401fe_1605960554152_674012_5202",
      "name": "Crear POST : \u003ci\u003eUseCase\u003c/i\u003e",
      "type": "requirement"
    },
    {
      "id": "Requirement___19_0_4_7c8024c_1605544934734_89990_5051",
      "name": "Crud de ONG : \u003ci\u003eUseCase\u003c/i\u003e",
      "type": "requirement"
    },
    {
      "id": "Requirement___19_0_3_59501f0_1605901657237_602297_5524",
      "name": "Descargar Archivos : \u003ci\u003eUseCase\u003c/i\u003e",
      "type": "requirement"
    },
    {
      "id": "Requirement___19_0_3_59501f0_1605900716718_322105_5130",
      "name": "Recordar Contraseña : \u003ci\u003eUseCase\u003c/i\u003e",
      "type": "requirement"
    },
    {
      "id": "Requirement___19_0_4_7c8024c_1605992040306_840570_5282",
      "name": "UMA : \u003ci\u003eActor\u003c/i\u003e",
      "type": "requirement"
    },
    {
      "id": "Requirement___19_0_3_59501f0_1605899611767_786078_4829",
      "name": "Validar Acceso : \u003ci\u003eUseCase\u003c/i\u003e",
      "type": "requirement"
    },
    {
      "id": "Requirement___19_0_4_8cb0287_1606043062428_844297_5553",
      "name": "Ver actividad : \u003ci\u003eUseCase\u003c/i\u003e",
      "type": "requirement"
    },
    {
      "id": "Requirement___19_0_4_7c8024c_1606044881557_892467_5370",
      "name": "Visualizar clases grabadas : \u003ci\u003eUseCase\u003c/i\u003e",
      "type": "requirement"
    },
    {
      "id": "Architecture___19_0_4_7c8024c_1608233830258_399547_6406",
      "name": "Crud Alumnos-CREAR-ALTERNATIVO-2 : \u003ci\u003eInteraction\u003c/i\u003e",
      "type": "architecture"
    },
    {
      "id": "Architecture___19_0_4_7c8024c_1608378644162_795769_6414",
      "name": "Crud de ONG : \u003ci\u003eInteraction\u003c/i\u003e",
      "type": "architecture"
    },
    {
      "id": "Architecture___19_0_4_7c8024c_1608227601648_553345_5484",
      "name": "CtrCurso : \u003ci\u003eClass\u003c/i\u003e",
      "type": "architecture"
    },
    {
      "id": "Architecture___19_0_4_7c8024c_1608227611466_747776_5510",
      "name": "CtrForo : \u003ci\u003eClass\u003c/i\u003e",
      "type": "architecture"
    },
    {
      "id": "Architecture___19_0_4_7c8024c_1608227664966_121960_5640",
      "name": "CtrTarea : \u003ci\u003eClass\u003c/i\u003e",
      "type": "architecture"
    },
    {
      "id": "Architecture___19_0_3_59501f0_1608294205699_944159_8820",
      "name": "Enviar correo interno : \u003ci\u003eInteraction\u003c/i\u003e",
      "type": "architecture"
    },
    {
      "id": "Architecture___19_0_3_59501f0_1608289624419_295501_6582",
      "name": "Recordar Contraseña : \u003ci\u003eInteraction\u003c/i\u003e",
      "type": "architecture"
    },
    {
      "id": "Architecture___19_0_3_59501f0_1608291630127_209026_7223",
      "name": "Recordar Contraseña-ALTERNATIVO : \u003ci\u003eInteraction\u003c/i\u003e",
      "type": "architecture"
    },
    {
      "id": "Architecture___19_0_3_5c401fe_1608572688415_5055_8478",
      "name": "Registro usuarios Alter : \u003ci\u003eInteraction\u003c/i\u003e",
      "type": "architecture"
    },
    {
      "id": "Architecture___19_0_4_5b201fd_1608472146728_379966_9598",
      "name": "ViewCalendario : \u003ci\u003eClass\u003c/i\u003e",
      "type": "architecture"
    },
    {
      "id": "Implementation___19_0_4_7c8024c_1606060622302_113766_5116",
      "name": "1.Introduccion : \u003ci\u003eArtifact\u003c/i\u003e",
      "type": "implementation"
    },
    {
      "id": "Implementation___19_0_4_7c8024c_1608491329083_791211_7570",
      "name": "1.Introducción : \u003ci\u003eArtifact\u003c/i\u003e",
      "type": "implementation"
    },
    {
      "id": "Implementation___19_0_4_7c8024c_1606060528605_322680_5112",
      "name": "10.Entorno Tecnológico : \u003ci\u003eArtifact\u003c/i\u003e",
      "type": "implementation"
    },
    {
      "id": "Implementation___19_0_4_7c8024c_1608491706642_526918_7610",
      "name": "11.Descripcion de Integración de subsistemas : \u003ci\u003eArtifact\u003c/i\u003e",
      "type": "implementation"
    },
    {
      "id": "Implementation___19_0_4_7c8024c_1606060584140_87899_5113",
      "name": "11.Estrategia de Implantación : \u003ci\u003eArtifact\u003c/i\u003e",
      "type": "implementation"
    },
    {
      "id": "Implementation___19_0_4_7c8024c_1608540241429_745140_8986",
      "name": "14.Formatos de Pantalla : \u003ci\u003eArtifact\u003c/i\u003e",
      "type": "implementation"
    },
    {
      "id": "Implementation___19_0_4_7c8024c_1606060419638_663731_5107",
      "name": "4.Catálogo de Requisitos : \u003ci\u003eArtifact\u003c/i\u003e",
      "type": "implementation"
    },
    {
      "id": "Implementation___19_0_4_7c8024c_1608491390629_320446_7573",
      "name": "5.Catalogo de Requisitos : \u003ci\u003eArtifact\u003c/i\u003e",
      "type": "implementation"
    },
    {
      "id": "Implementation___19_0_4_7c8024c_1608491599000_508114_7604",
      "name": "7.Catalogo de Usuarios : \u003ci\u003eArtifact\u003c/i\u003e",
      "type": "implementation"
    },
    {
      "id": "Implementation___19_0_4_7c8024c_1606060493989_308786_5110",
      "name": "7.Descomposicion en Subsistemas : \u003ci\u003eArtifact\u003c/i\u003e",
      "type": "implementation"
    },
    {
      "id": "Diagrams___19_0_4_7c8024c_1608464479043_18374_13440",
      "name": "Aceptar Invitacion  Curso_imported : \u003ci\u003eActivity Diagram\u003c/i\u003e",
      "type": "diagrams"
    },
    {
      "id": "Diagrams___19_0_4_7c8024c_1608397299611_104126_8854",
      "name": "AutoregistroAlter : \u003ci\u003eSequence Diagram\u003c/i\u003e",
      "type": "diagrams"
    },
    {
      "id": "Diagrams___19_0_4_7c8024c_1608378644436_339003_7256",
      "name": "Descargar Archivos_imported : \u003ci\u003eActivity Diagram\u003c/i\u003e",
      "type": "diagrams"
    },
    {
      "id": "Diagrams___19_0_4_7c8024c_1608397299659_722793_8955",
      "name": "Descargar Archivos_imported_imported : \u003ci\u003eActivity Diagram\u003c/i\u003e",
      "type": "diagrams"
    },
    {
      "id": "Diagrams___19_0_4_7c8024c_1608378644466_1178_7326",
      "name": "Entregar Actividad_imported : \u003ci\u003eActivity Diagram\u003c/i\u003e",
      "type": "diagrams"
    },
    {
      "id": "Diagrams___19_0_4_7c8024c_1608399403661_45434_6686",
      "name": "Entregar Tarea : \u003ci\u003eActivity Diagram\u003c/i\u003e",
      "type": "diagrams"
    },
    {
      "id": "Diagrams___19_0_4_7c8024c_1608241970816_286440_8997",
      "name": "Entregar tarea : \u003ci\u003eSequence Diagram\u003c/i\u003e",
      "type": "diagrams"
    },
    {
      "id": "Diagrams___19_0_4_7c8024c_1608464477782_544977_9517",
      "name": "Mirar POST_imported2 : \u003ci\u003eActivity Diagram\u003c/i\u003e",
      "type": "diagrams"
    },
    {
      "id": "Diagrams___19_0_3_59501f0_1608294026196_162693_8568",
      "name": "Registro usuarios externos-ALTERNATIVO : \u003ci\u003eSequence Diagram\u003c/i\u003e",
      "type": "diagrams"
    },
    {
      "id": "Diagrams___19_0_3_5c401fe_1605961280982_806754_5372",
      "name": "Reportar : \u003ci\u003eActivity Diagram\u003c/i\u003e",
      "type": "diagrams"
    }
  ],
  "req_architecture": [],
  "implementation": [
    {
      "id": "Implementation___19_0_4_7c8024c_1606060622302_113766_5116",
      "name": "1.Introduccion : \u003ci\u003eArtifact\u003c/i\u003e",
      "type": "implementation"
    },
    {
      "id": "Implementation___19_0_4_7c8024c_1608491329083_791211_7570",
      "name": "1.Introducción : \u003ci\u003eArtifact\u003c/i\u003e",
      "type": "implementation"
    },
    {
      "id": "Implementation___19_0_4_7c8024c_1606060528605_322680_5112",
      "name": "10.Entorno Tecnológico : \u003ci\u003eArtifact\u003c/i\u003e",
      "type": "implementation"
    },
    {
      "id": "Implementation___19_0_4_7c8024c_1608491706642_526918_7610",
      "name": "11.Descripcion de Integración de subsistemas : \u003ci\u003eArtifact\u003c/i\u003e",
      "type": "implementation"
    },
    {
      "id": "Implementation___19_0_4_7c8024c_1606060584140_87899_5113",
      "name": "11.Estrategia de Implantación : \u003ci\u003eArtifact\u003c/i\u003e",
      "type": "implementation"
    },
    {
      "id": "Implementation___19_0_4_7c8024c_1608540241429_745140_8986",
      "name": "14.Formatos de Pantalla : \u003ci\u003eArtifact\u003c/i\u003e",
      "type": "implementation"
    },
    {
      "id": "Implementation___19_0_4_7c8024c_1606060419638_663731_5107",
      "name": "4.Catálogo de Requisitos : \u003ci\u003eArtifact\u003c/i\u003e",
      "type": "implementation"
    },
    {
      "id": "Implementation___19_0_4_7c8024c_1608491390629_320446_7573",
      "name": "5.Catalogo de Requisitos : \u003ci\u003eArtifact\u003c/i\u003e",
      "type": "implementation"
    },
    {
      "id": "Implementation___19_0_4_7c8024c_1608491599000_508114_7604",
      "name": "7.Catalogo de Usuarios : \u003ci\u003eArtifact\u003c/i\u003e",
      "type": "implementation"
    },
    {
      "id": "Implementation___19_0_4_7c8024c_1606060493989_308786_5110",
      "name": "7.Descomposicion en Subsistemas : \u003ci\u003eArtifact\u003c/i\u003e",
      "type": "implementation"
    }
  ],
  "test_cases": [],
  "diagrams": [
    {
      "id": "Diagrams___19_0_4_7c8024c_1608464479043_18374_13440",
      "name": "Aceptar Invitacion  Curso_imported : \u003ci\u003eActivity Diagram\u003c/i\u003e",
      "type": "diagrams"
    },
    {
      "id": "Diagrams___19_0_4_7c8024c_1608397299611_104126_8854",
      "name": "AutoregistroAlter : \u003ci\u003eSequence Diagram\u003c/i\u003e",
      "type": "diagrams"
    },
    {
      "id": "Diagrams___19_0_4_7c8024c_1608378644436_339003_7256",
      "name": "Descargar Archivos_imported : \u003ci\u003eActivity Diagram\u003c/i\u003e",
      "type": "diagrams"
    },
    {
      "id": "Diagrams___19_0_4_7c8024c_1608397299659_722793_8955",
      "name": "Descargar Archivos_imported_imported : \u003ci\u003eActivity Diagram\u003c/i\u003e",
      "type": "diagrams"
    },
    {
      "id": "Diagrams___19_0_4_7c8024c_1608378644466_1178_7326",
      "name": "Entregar Actividad_imported : \u003ci\u003eActivity Diagram\u003c/i\u003e",
      "type": "diagrams"
    },
    {
      "id": "Diagrams___19_0_4_7c8024c_1608399403661_45434_6686",
      "name": "Entregar Tarea : \u003ci\u003eActivity Diagram\u003c/i\u003e",
      "type": "diagrams"
    },
    {
      "id": "Diagrams___19_0_4_7c8024c_1608241970816_286440_8997",
      "name": "Entregar tarea : \u003ci\u003eSequence Diagram\u003c/i\u003e",
      "type": "diagrams"
    },
    {
      "id": "Diagrams___19_0_4_7c8024c_1608464477782_544977_9517",
      "name": "Mirar POST_imported2 : \u003ci\u003eActivity Diagram\u003c/i\u003e",
      "type": "diagrams"
    },
    {
      "id": "Diagrams___19_0_3_59501f0_1608294026196_162693_8568",
      "name": "Registro usuarios externos-ALTERNATIVO : \u003ci\u003eSequence Diagram\u003c/i\u003e",
      "type": "diagrams"
    },
    {
      "id": "Diagrams___19_0_3_5c401fe_1605961280982_806754_5372",
      "name": "Reportar : \u003ci\u003eActivity Diagram\u003c/i\u003e",
      "type": "diagrams"
    }
  ],
  "requirement": [
    {
      "id": "Requirement___19_0_4_7c8024c_1606044881570_420167_5379",
      "name": " : \u003ci\u003eActor\u003c/i\u003e",
      "type": "requirement"
    },
    {
      "id": "Requirement___19_0_4_7c8024c_1606044881556_666481_5369",
      "name": "CUD calificaciones opcionales : \u003ci\u003eUseCase\u003c/i\u003e",
      "type": "requirement"
    },
    {
      "id": "Requirement___19_0_3_5c401fe_1605960554152_674012_5202",
      "name": "Crear POST : \u003ci\u003eUseCase\u003c/i\u003e",
      "type": "requirement"
    },
    {
      "id": "Requirement___19_0_4_7c8024c_1605544934734_89990_5051",
      "name": "Crud de ONG : \u003ci\u003eUseCase\u003c/i\u003e",
      "type": "requirement"
    },
    {
      "id": "Requirement___19_0_3_59501f0_1605901657237_602297_5524",
      "name": "Descargar Archivos : \u003ci\u003eUseCase\u003c/i\u003e",
      "type": "requirement"
    },
    {
      "id": "Requirement___19_0_3_59501f0_1605900716718_322105_5130",
      "name": "Recordar Contraseña : \u003ci\u003eUseCase\u003c/i\u003e",
      "type": "requirement"
    },
    {
      "id": "Requirement___19_0_4_7c8024c_1605992040306_840570_5282",
      "name": "UMA : \u003ci\u003eActor\u003c/i\u003e",
      "type": "requirement"
    },
    {
      "id": "Requirement___19_0_3_59501f0_1605899611767_786078_4829",
      "name": "Validar Acceso : \u003ci\u003eUseCase\u003c/i\u003e",
      "type": "requirement"
    },
    {
      "id": "Requirement___19_0_4_8cb0287_1606043062428_844297_5553",
      "name": "Ver actividad : \u003ci\u003eUseCase\u003c/i\u003e",
      "type": "requirement"
    },
    {
      "id": "Requirement___19_0_4_7c8024c_1606044881557_892467_5370",
      "name": "Visualizar clases grabadas : \u003ci\u003eUseCase\u003c/i\u003e",
      "type": "requirement"
    }
  ],
  "req_test": [],
  "architecture": [
    {
      "id": "Architecture___19_0_4_7c8024c_1608233830258_399547_6406",
      "name": "Crud Alumnos-CREAR-ALTERNATIVO-2 : \u003ci\u003eInteraction\u003c/i\u003e",
      "type": "architecture"
    },
    {
      "id": "Architecture___19_0_4_7c8024c_1608378644162_795769_6414",
      "name": "Crud de ONG : \u003ci\u003eInteraction\u003c/i\u003e",
      "type": "architecture"
    },
    {
      "id": "Architecture___19_0_4_7c8024c_1608227601648_553345_5484",
      "name": "CtrCurso : \u003ci\u003eClass\u003c/i\u003e",
      "type": "architecture"
    },
    {
      "id": "Architecture___19_0_4_7c8024c_1608227611466_747776_5510",
      "name": "CtrForo : \u003ci\u003eClass\u003c/i\u003e",
      "type": "architecture"
    },
    {
      "id": "Architecture___19_0_4_7c8024c_1608227664966_121960_5640",
      "name": "CtrTarea : \u003ci\u003eClass\u003c/i\u003e",
      "type": "architecture"
    },
    {
      "id": "Architecture___19_0_3_59501f0_1608294205699_944159_8820",
      "name": "Enviar correo interno : \u003ci\u003eInteraction\u003c/i\u003e",
      "type": "architecture"
    },
    {
      "id": "Architecture___19_0_3_59501f0_1608289624419_295501_6582",
      "name": "Recordar Contraseña : \u003ci\u003eInteraction\u003c/i\u003e",
      "type": "architecture"
    },
    {
      "id": "Architecture___19_0_3_59501f0_1608291630127_209026_7223",
      "name": "Recordar Contraseña-ALTERNATIVO : \u003ci\u003eInteraction\u003c/i\u003e",
      "type": "architecture"
    },
    {
      "id": "Architecture___19_0_3_5c401fe_1608572688415_5055_8478",
      "name": "Registro usuarios Alter : \u003ci\u003eInteraction\u003c/i\u003e",
      "type": "architecture"
    },
    {
      "id": "Architecture___19_0_4_5b201fd_1608472146728_379966_9598",
      "name": "ViewCalendario : \u003ci\u003eClass\u003c/i\u003e",
      "type": "architecture"
    }
  ]
};