window.tips_data = [
{
    title: window.resource.help_tip.tip1.title,
    posX: 42,
    posY: 65,
    width: 500,
    height: 300,
    html: window.resource.help_tip.tip1.text
},
{
    title: window.resource.help_tip.tip2.title,
    posX: 400,
    posY: 60,
    width: 500,
    height: 300,
    html: window.resource.help_tip.tip2.text
},
{
    title: window.resource.help_tip.tip3.title,
    posX: 180,
    posY: 10,
    width: 500,
    height: 300,
    html: window.resource.help_tip.tip3.text
}
];

window.help_screen_data = [
{
    title: window.resource.quick_help.title,
    posX: 125,
    posY: 30,
    width: 850,
    height: 600,
    html: window.resource.quick_help.text           
}
];