Ext.define('CustomsReport.view.Viewport', {
    extend: 'CustomsReport.view.MyViewport',
    renderTo: Ext.getBody()
});